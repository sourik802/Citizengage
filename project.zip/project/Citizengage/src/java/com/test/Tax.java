/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import java.util.Date;

/**
 *
 * @author 258290
 */
public class Tax {

    private Double taxAmt;
    private Double fine;
    private Date assessStartDt;
    private Date assessEndDt;
    private Date dueDt;
    private String paymentStatus;

    public Double getTaxAmt() {
        return taxAmt;
    }

    public void setTaxAmt(Double taxAmt) {
        this.taxAmt = taxAmt;
    }

    public Date getAssessStartDt() {
        return assessStartDt;
    }

    public void setAssessStartDt(Date assessStartDt) {
        this.assessStartDt = assessStartDt;
    }

    public Date getAssessEndDt() {
        return assessEndDt;
    }

    public void setAssessEndDt(Date assessEndDt) {
        this.assessEndDt = assessEndDt;
    }

    public Date getDueDt() {
        return dueDt;
    }

    public void setDueDt(Date dueDt) {
        this.dueDt = dueDt;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Double getFine() {
        return fine;
    }

    public void setFine(Double fine) {
        this.fine = fine;
    }

}
