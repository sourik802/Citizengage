/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import org.primefaces.component.accordionpanel.AccordionPanel;
import org.primefaces.component.tabview.Tab;

/**
 *
 * @author Sourik
 */
//@Named(value = "testManagedBean")
@ManagedBean(name = "testManagedBean1")
public class TestManagedBean_1 {

    private String name;

    /**
     * Creates a new instance of TestManagedBean
     */
    public TestManagedBean_1() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String testAction() {
        System.out.println("name is " + getName());
        return "test";
    }

    private String srchHospOpt;
    private boolean displaySrchFld;
    private String srchPlcHldr;
    private String selectdHosp;
    private boolean displayHosp;
    private Hospital hospitalSelectd;

    public String getSrchHospOpt() {
        return srchHospOpt;
    }

    public void setSrchHospOpt(String srchHospOpt) {
        this.srchHospOpt = srchHospOpt;
    }

    public void selectedSearchOpt() {
        System.out.println("within selectedSearchOpt");
        System.out.println("option selected " + getSrchHospOpt());
        if (getSrchHospOpt() != null && (getSrchHospOpt().equals("h") || getSrchHospOpt().equals("s"))) {
            System.out.println("setting DisplaySrchFld to true");
            setDisplaySrchFld(true);
            if (getSrchHospOpt().equals("h")) {
                setSrchPlcHldr("Search Hospital, Clinic");
            } else if (getSrchHospOpt().equals("s")) {
                setSrchPlcHldr("Search by Speciality");
            }
        } else if (getSrchHospOpt().equals("l")) {
            System.out.println("setting displayHosp to true");
            populateHospitals();
            setDisplayHosp(true);
        }
    }

    public boolean isDisplaySrchFld() {
        return displaySrchFld;
    }

    public void setDisplaySrchFld(boolean displaySrchFld) {
        this.displaySrchFld = displaySrchFld;
    }

    public String getSrchPlcHldr() {
        return srchPlcHldr;
    }

    public void setSrchPlcHldr(String srchPlcHldr) {
        this.srchPlcHldr = srchPlcHldr;
    }

    public String getSelectdHosp() {
        return selectdHosp;
    }

    public void setSelectdHosp(String selectdHosp) {
        this.selectdHosp = selectdHosp;
    }

    public List<String> compltHospRslt(String query) {
        List<String> results = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            results.add(query + i);
        }
        return results;
    }

    public void populateHospReslts() {

    }

    @ManagedProperty(value = "#{hospital}")
    private Hospital hosp;
    private List<Hospital> hospList = new ArrayList<>();

    public Hospital getHosp() {
        return hosp;
    }

    public void setHosp(Hospital hosp) {
        this.hosp = hosp;
    }

    public List<Hospital> getHospList() {
        return hospList;
    }

    public void setHospList(List<Hospital> hospList) {
        this.hospList = hospList;
    }

    public void addHospital(Hospital h) {
        if (getHospList() == null) {
            setHospList(new ArrayList<>());
        }
        boolean add = getHospList().add(h);
    }

    public boolean isDisplayHosp() {
        return displayHosp;
    }

    public void setDisplayHosp(boolean displayHosp) {
        this.displayHosp = displayHosp;
    }

    public void populateHospitals() {
        Hospital h1 = new Hospital();
        h1.setName("Apollo");
        h1.setAddress("Bypass");
        h1.setAmbulanceAvailable(true);
        h1.setEmergencyAvailable(true);
        h1.setTimings("10 AM - 9 PM");
        h1.setType("Private");
        h1.setPhone("1111111");
        Map<String, List> m1 = new HashMap();
        List<String> l1 = new ArrayList();
        l1.add("Dr. A B, MBBS");
        l1.add("Dr. Bhatta, AAAA");
        m1.put("ENT", l1);
        h1.setSpecialisation(m1);
        Hospital h2 = new Hospital();
        h2.setName("AMRI");
        h2.setAddress("Gariahat");
        h2.setAmbulanceAvailable(true);
        h2.setEmergencyAvailable(true);
        h2.setTimings("9 AM - 9 PM");
        h2.setType("Private");
        h2.setPhone("1111111");
        Map<String, List> m2 = new HashMap();
        List<String> l21 = new ArrayList();
        List<String> l22 = new ArrayList();
        l21.add("Dr. B, MBBS");
        l22.add("Dr. PP, AAAA");
        m2.put("Dentist", l21);
        m2.put("Ortho", l22);
        h2.setSpecialisation(m2);
        Hospital h3 = new Hospital();
        h3.setName("Medico");
        h3.setAddress("Salt Lake");
        h3.setAmbulanceAvailable(false);
        h3.setEmergencyAvailable(true);
        h3.setTimings("10 AM - 8 PM");
        h3.setType("Private");
        h3.setPhone("1111111");
        Hospital h4 = new Hospital();
        h4.setName("Beliaghata ESI");
        h4.setAddress("B M Road");
        h4.setAmbulanceAvailable(true);
        h4.setEmergencyAvailable(true);
        h4.setTimings("10 AM - 6 PM");
        h4.setType("Gov ESI");
        h4.setPhone("1111111");
        Map<String, List> m4 = new HashMap();
        List<String> l41 = new ArrayList();
        List<String> l42 = new ArrayList();
        l41.add("Dr. B, MBBS");
        l42.add("Dr. PP, AAAA");
        m4.put("Cardio", l41);
        m4.put("Ortho", l42);
        h4.setSpecialisation(m4);
        addHospital(h1);
        addHospital(h2);
        addHospital(h3);
        addHospital(h4);
    }

    public Hospital getHospitalSelectd() {
        return hospitalSelectd;
    }

    public void setHospitalSelectd(Hospital hospitalSelectd) {
        this.hospitalSelectd = hospitalSelectd;
    }

    //skills
    private SkillBean skill;
    private List<SkillBean> skillList;
    @ManagedProperty("#{skillService}")
    private SkillService service;
    private String lat;

    public SkillBean getSkill() {
        return skill;
    }

    public void setSkill(SkillBean skill) {
        this.skill = skill;
    }

    public List<SkillBean> getSkillList() {
        return skillList;
    }

    public void setSkillList(List<SkillBean> skillList) {
        this.skillList = skillList;
    }

    public SkillService getService() {
        return service;
    }

    public void setService(SkillService service) {
        this.service = service;
    }
        
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    @PostConstruct
    public void init(){
        skillList = service.getSkills();
    }
        
    public void searchSkill() {
        System.out.println("within searchSkill()");
        System.out.println("latitude " + getLat());
        String value = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("hidden2");
        System.out.println("value " + value);
    }
    
    //recruitment
    private AccordionPanel panel;
    private Tab tab;
    private List tabList = new ArrayList();

    public AccordionPanel getPanel() {
        return panel;
    }

    public void setPanel(AccordionPanel panel) {
        this.panel = panel;
    }

    public Tab getTab() {
        return tab;
    }

    public void setTab(Tab tab) {
        this.tab = tab;
    }
    
    public void loadPanel(){
        
        Tab t1 = new Tab();
        t1.setId("1");
        t1.setTitle("t1");
        Tab t2 = new Tab();
        t2.setId("2");
        t2.setTitle("t2");
        getTabList().add(t1);
        getTabList().add(t2);
        
    }

    public List getTabList() {
        return tabList;
    }

    public void setTabList(List tabList) {
        this.tabList = tabList;
    }
    
    
}
