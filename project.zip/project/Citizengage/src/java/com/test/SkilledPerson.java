/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import org.primefaces.model.StreamedContent;

/**
 *
 * @author 258290
 */
public class SkilledPerson {

    private Integer id;
    private String name;
    private String address;
    private Integer pin;
    private String skillType;
    private Integer rate;
    private StreamedContent photo;
    private StreamedContent identityDoc;
    private String phone;

    /**
     * Creates a new instance of SkilledPerson
     */
    public SkilledPerson() {
    }

    public SkilledPerson(Integer id, String name, String address, Integer rate, String phone) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.rate = rate;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getPin() {
        return pin;
    }

    public void setPin(Integer pin) {
        this.pin = pin;
    }

    public String getSkillType() {
        return skillType;
    }

    public void setSkillType(String skillType) {
        this.skillType = skillType;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public StreamedContent getPhoto() {
        return photo;
    }

    public void setPhoto(StreamedContent photo) {
        this.photo = photo;
    }

    public StreamedContent getIdentityDoc() {
        return identityDoc;
    }

    public void setIdentityDoc(StreamedContent identityDoc) {
        this.identityDoc = identityDoc;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    
}
