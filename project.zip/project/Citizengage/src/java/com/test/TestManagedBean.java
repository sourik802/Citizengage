/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.entity.Userinfo;
import com.jsf.beans.model.Address;
import com.jsf.beans.model.Doctor;
import com.jsf.beans.model.Hospital;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.imageio.stream.FileImageOutputStream;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.map.PointSelectEvent;
import org.primefaces.event.map.StateChangeEvent;
import org.primefaces.model.CroppedImage;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.primefaces.model.chart.PieChartModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.LatLngBounds;

/**
 *
 * @author 258290
 */
@ManagedBean(name = "testManagedBean")
@ViewScoped
public class TestManagedBean implements Serializable {

    @EJB
    private DataServicesHelper dataServices;

    //@ManagedProperty(value = "#{param.id}")
    private String id;
    private String param;
    private String name;

    private String complain;
    private List<SelectItem> complains;


    /**
     * Creates a new instance of TestManagedBean
     */
    public TestManagedBean() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public String getComplain() {
        return complain;
    }

    public void setComplain(String complain) {
        this.complain = complain;
    }

    public List<SelectItem> getComplains() {
        return complains;
    }

    public void setComplains(List<SelectItem> complains) {
        this.complains = complains;
    }

    public void setNavigation(String v) {
        System.out.println("Inside setNavigation()");
        HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        System.out.println("Parameter " + req.getParameter("parameter"));
        System.out.println("Param " + this.param + " value " + v);

        Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String idString = params.get("id");
        System.out.println("value of id " + this.id + " " + idString);

    }

    public String delegate() {
        System.out.println("Inside delegate()");
        HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        System.out.println("Parameter " + req.getParameter("parameter"));
        System.out.println("Param " + this.param);

        Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        String idString = params.get("id");
        System.out.println("value of id " + this.id + " " + idString);
        return "emergency/policeStation";
    }

    private List<SelectItem> categories;
    private String selection;
    private boolean showArea;

    public boolean isShowArea() {
        return showArea;
    }

    public void setShowArea(boolean showArea) {
        this.showArea = showArea;
    }

    @PostConstruct
    public void init() {
        categories = new ArrayList<>();
        SelectItemGroup group1 = new SelectItemGroup("Group 1");
        SelectItemGroup group2 = new SelectItemGroup("Group 2");
        SelectItemGroup group3 = new SelectItemGroup("Group 3");
        SelectItemGroup group4 = new SelectItemGroup("Group 4");

        SelectItemGroup group11 = new SelectItemGroup("Group 1.1");
        SelectItemGroup group12 = new SelectItemGroup("Group 1.2");

        SelectItemGroup group21 = new SelectItemGroup("Group 2.1");

        SelectItem option31 = new SelectItem("Option 3.1", "Option 3.1");
        SelectItem option32 = new SelectItem("Option 3.2", "Option 3.2");
        SelectItem option33 = new SelectItem("Option 3.3", "Option 3.3");
        SelectItem option34 = new SelectItem("Option 3.4", "Option 3.4");

        SelectItem option41 = new SelectItem("Option 4.1", "Option 4.1");

        SelectItem option111 = new SelectItem("Option 1.1.1");
        SelectItem option112 = new SelectItem("Option 1.1.2");
        group11.setSelectItems(new SelectItem[]{option111, option112});

        SelectItem option121 = new SelectItem("Option 1.2.1", "Option 1.2.1");
        SelectItem option122 = new SelectItem("Option 1.2.2", "Option 1.2.2");
        SelectItem option123 = new SelectItem("Option 1.2.3", "Option 1.2.3");
        group12.setSelectItems(new SelectItem[]{option121, option122, option123});

        SelectItem option211 = new SelectItem("Option 2.1.1", "Option 2.1.1");
        group21.setSelectItems(new SelectItem[]{option211});

        group1.setSelectItems(new SelectItem[]{group11, group12});
        group2.setSelectItems(new SelectItem[]{group21});
        group3.setSelectItems(new SelectItem[]{option31, option32, option33, option34});
        group4.setSelectItems(new SelectItem[]{option41});

        categories.add(group1);
        categories.add(group2);
        categories.add(group3);
        categories.add(group4);

        SelectItemGroup g1 = new SelectItemGroup("Legal - Police");
        g1.setSelectItems(new SelectItem[]{new SelectItem("GD", "GD"), new SelectItem("FIR", "FIR")});

        SelectItemGroup g2 = new SelectItemGroup("Report Incident");
        g2.setSelectItems(new SelectItem[]{new SelectItem("Corruption", "Corruption"), new SelectItem("Encroachment", "Encroachment"), new SelectItem("np", "Noise Pollution")});
        complains = new ArrayList<>();
        complains.add(g1);
        complains.add(g2);

        model = new DefaultDashboardModel();
        DashboardColumn column1 = new DefaultDashboardColumn();
        column1.addWidget("address");
        model.addColumn(column1);

//        getProperty().setOwnerName("A A");
//        getProperty().setOwnerPhone("1234345");
//        getProperty().setAddress("New town");
//        getProperty().setPropPin("700156");
//        getProperty().setWard("100");
//        Tax tax = new Tax();
//        tax.setTaxAmt(10000.0);
//        tax.setPaymentStatus("Pending");
//        tax.setFine(0.0);
//        tax.setDueDt(new Date());
//        tax.setAssessEndDt(new Date());
//        tax.setAssessStartDt(new Date());
//        List l = new ArrayList();
//        l.add(tax);
//        getProperty().setTaxList(l);
        //skill
        skillList = service.getSkills();

        //medical - donation
        SelectItemGroup blood = new SelectItemGroup("Blood");
        blood.setSelectItems(new SelectItem[]{new SelectItem("Blood", "Blood")});

        SelectItemGroup organ = new SelectItemGroup("Organ");
        organ.setSelectItems(new SelectItem[]{new SelectItem("Kidney", "Kidney"), new SelectItem("Liver", "Liver")});

        items = new ArrayList<SelectItem>();
        items.add(blood);
        items.add(organ);

        //recruitment
        Recruitment recruit1 = new Recruitment();
        recruit1.setCompany("HIDCO");
        recruit1.setDepartment("Mechanical");
        recruit1.setDescription("all profile should have a id\n"
                + "on submit display application no/request no/ticket no on page\n"
                + "\n"
                + "\n"
                + "\n"
                + "\n"
                + "report on all services - automated\n"
                + "\n"
                + "group and community - individuals can form or follow groups and submit request on the above as groups\n"
                + "\n"
                + "request tracking, status\n"
                + "\n"
                + "chat facility\n"
                + "\n"
                + "search for a housing already registered and become a member\n"
                + "suggestion\n"
                + "pin no check while user registration if pin falls under smart city jurisdiction - master table tracking\n"
                + "benchmark data display - doctors/population, police/population, transport/population\n"
                + "register housing society - save green cover - no of trees and their age, solar power coverage, rain water harvesting");
        recruit1.setDtOfPublish(new Date());
        recruit1.setExperience("5-8 years");
        recruit1.setLastDt(new Date());
        recruit1.setNoOfVacancy(12);
        recruit1.setProcedure("Online");

        Recruitment recruit2 = new Recruitment();
        recruit2.setCompany("NKDA");
        recruit2.setDepartment("Admin");
        recruit2.setDescription("required for project.............");
        recruit2.setDtOfPublish(new Date());
        recruit2.setExperience("2-3 years");
        recruit2.setLastDt(new Date());
        recruit2.setNoOfVacancy(6);
        recruit2.setProcedure("Writtem exam followed by Interview");
        String link = "www.google.com";
        recruit2.getLink().add(link);
        recruitList.add(recruit1);
        recruitList.add(recruit2);
        InputStream stream = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/WEB-INF/sample.pdf");
        file = new DefaultStreamedContent(stream, "application/pdf", "application_form.pdf");

    }

    public List<SelectItem> getCategories() {
        return categories;
    }

    public String getSelection() {
        return selection;
    }

    public void setSelection(String selection) {
        this.selection = selection;
    }

    public void valueChanged(ValueChangeEvent e) {
        System.out.println("within valueChanged" + this.selection);
        setShowArea(true);
    }

    public void onStateChange(StateChangeEvent event) {
        LatLngBounds bounds = event.getBounds();
        int zoomLevel = event.getZoomLevel();

        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Zoom Level", String.valueOf(zoomLevel)));
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Center", event.getCenter().toString()));
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "NorthEast", bounds.getNorthEast().toString()));
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "SouthWest", bounds.getSouthWest().toString()));
    }

    public void onPointSelect(PointSelectEvent event) {
        LatLng latlng = event.getLatLng();
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Point Selected", "Lat:" + latlng.getLat() + ", Lng:" + latlng.getLng()));
    }

    public void addMessage(FacesMessage message) {
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public List<String> completeText(String query) {
        List<String> results = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            results.add(query + i);
        }

        return results;
    }

    //@ManagedProperty(value = "#{doc}")
    private Doctor doc;

    public Doctor getDoc() {
        return doc;
    }

    public void setDoc(Doctor doc) {
        this.doc = doc;
    }

    private List<Doctor> docList;

    public List<Doctor> getDocList() {
        return docList;
    }

    public void setDocList(List<Doctor> docList) {
        this.docList = docList;
    }

    public List<Doctor> populatedoc() {
        System.out.println("within populatedoc() " + getParam());
        Doctor d1 = new Doctor();
        Doctor d2 = new Doctor();
        d1.setName("Amit");
        //d1.setPostalCd(700156);
        d1.setRegistration("1234");
        d2.setName("Tuhin");
        //d2.setPostalCd(700012);
        d2.setRegistration("2222");
        if (docList == null) {
            docList = new ArrayList<>();
        }
        docList.add(d1);
        docList.add(d2);
        return docList;
    }

    public void showDoc(Doctor d) {
        System.out.println("Doctor selected " + d.getName());
        this.doc = d;
    }

    private String srchHospOpt;
    private boolean displaySrchFld;
    private String srchPlcHldr;
    private String selectdHosp;
    private boolean displayHosp;

    public String getSrchHospOpt() {
        return srchHospOpt;
    }

    public void setSrchHospOpt(String srchHospOpt) {
        this.srchHospOpt = srchHospOpt;
    }

    public void selectedSearchOpt() {
        System.out.println("within selectedSearchOpt");
        System.out.println("option selected " + getSrchHospOpt());
        if (getSrchHospOpt() != null && (getSrchHospOpt().equals("h") || getSrchHospOpt().equals("s"))) {
            System.out.println("setting DisplaySrchFld to true");
            setDisplaySrchFld(true);
            if (getSrchHospOpt().equals("h")) {
                setSrchPlcHldr("  Search Hospital, Clinic");
                clearHospList();
            } else if (getSrchHospOpt().equals("s")) {
                setSrchPlcHldr("  Search by Speciality");
                clearHospList();
            }
        } else if (getSrchHospOpt() != null && getSrchHospOpt().equals("l")) {
            System.out.println("setting displayHosp to true");
            setParam("");
            setDisplaySrchFld(false);
            clearHospList();
            populateHospitals();
            setDisplayHosp(true);
        }
    }

    public boolean isDisplaySrchFld() {
        return displaySrchFld;
    }

    public void setDisplaySrchFld(boolean displaySrchFld) {
        this.displaySrchFld = displaySrchFld;
    }

    public String getSrchPlcHldr() {
        return srchPlcHldr;
    }

    public void setSrchPlcHldr(String srchPlcHldr) {
        this.srchPlcHldr = srchPlcHldr;
    }

    public String getSelectdHosp() {
        return selectdHosp;
    }

    public void setSelectdHosp(String selectdHosp) {
        this.selectdHosp = selectdHosp;
    }

    public List<String> compltHospRslt(String query) {
        List<String> results = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            results.add(query + i);
        }
        return results;
    }

    public void populateHospReslts() {

    }

    @ManagedProperty(value = "#{hosp}")
    private Hospital hosp;
    private List<Hospital> hospList = new ArrayList<>();

    public Hospital getHosp() {
        return hosp;
    }

    public void setHosp(Hospital hosp) {
        this.hosp = hosp;
    }

    public List<Hospital> getHospList() {
        return hospList;
    }

    public void setHospList(List<Hospital> hospList) {
        this.hospList = hospList;
    }

    public void addHospital(Hospital h) {
        if (getHospList() == null) {
            setHospList(new ArrayList<>());
        }
        boolean add = getHospList().add(h);
    }

    public void clearHospList() {
        if (getHospList() != null) {
            getHospList().clear();
        }
    }

    public boolean isDisplayHosp() {
        return displayHosp;
    }

    public void setDisplayHosp(boolean displayHosp) {
        this.displayHosp = displayHosp;
    }

    public void populateHospitals() {
        Hospital h1 = new Hospital();
        h1.setName("Apollo");
        //h1.setAddress("Bypass");
        h1.setAmbulanceAvailable("");
        h1.setEmergencyAvailable("");
        h1.setTimings("10 AM - 9 PM");
        h1.setType("Private");
        h1.setPhone("1111111");
        Map<String, List> m1 = new HashMap();
        List<String> l1 = new ArrayList();
        l1.add("Dr. A B, MBBS");
        l1.add("Dr. Devina Bhatta, MD in TIBCO");
        m1.put("ENT", l1);
        h1.setSpecialisation(m1);
        Hospital h2 = new Hospital();
        h2.setName("AMRI");
        //h2.setAddress("Gariahat");
        h2.setAmbulanceAvailable("");
        h2.setEmergencyAvailable("");
        h2.setTimings("9 AM - 9 PM");
        h2.setType("Private");
        h2.setPhone("1111111");
        Map<String, List> m2 = new HashMap();
        List<String> l21 = new ArrayList();
        List<String> l22 = new ArrayList();
        l21.add("Dr. B, MBBS");
        l22.add("Dr. PP, AAAA");
        m2.put("Dentist", l21);
        m2.put("Ortho", l22);
        h2.setSpecialisation(m2);
        Hospital h3 = new Hospital();
        h3.setName("Medico");
        //h3.setAddress("Salt Lake");
        h3.setAmbulanceAvailable("");
        h3.setEmergencyAvailable("");
        h3.setTimings("10 AM - 8 PM");
        h3.setType("Private");
        h3.setPhone("1111111");
        Hospital h4 = new Hospital();
        h4.setName("Beliaghata ESI");
        //h4.setAddress("B M Road");
        h4.setAmbulanceAvailable("");
        h4.setEmergencyAvailable("");
        h4.setTimings("10 AM - 6 PM");
        h4.setType("Gov ESI");
        h4.setPhone("1111111");
        Map<String, List> m4 = new HashMap();
        List<String> l41 = new ArrayList();
        List<String> l42 = new ArrayList();
        l41.add("Dr. B, MBBS");
        l41.add("Dr. X, PPP");
        l42.add("Dr. PP, AAAA");
        m4.put("Cardio", l41);
        m4.put("Ortho", l42);
        h4.setSpecialisation(m4);
        addHospital(h1);
        addHospital(h2);
        addHospital(h3);
        addHospital(h4);
    }

    public void showHospDocs(Hospital h) {
        System.out.println("within showHospDocs() " + h.getName());
        System.out.println(h.getMyHashMapEntryList());
        this.hosp = h;
    }

    private String reqName;
    private String ailment;
    private String reqGender;
    private Integer reqAge;
    private String docName;
    private String hospName;
    private UploadedFile prescription;
    private String reqBloodGrp;
    private String specification;
    private String requestedItem;
    private List<SelectItem> items = new ArrayList<>();

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getAilment() {
        return ailment;
    }

    public void setAilment(String ailment) {
        this.ailment = ailment;
    }

    public String getReqGender() {
        return reqGender;
    }

    public void setReqGender(String reqGender) {
        this.reqGender = reqGender;
    }

    public Integer getReqAge() {
        return reqAge;
    }

    public void setReqAge(Integer reqAge) {
        this.reqAge = reqAge;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getHospName() {
        return hospName;
    }

    public void setHospName(String hospName) {
        this.hospName = hospName;
    }

    public UploadedFile getPrescription() {
        return prescription;
    }

    public void setPrescription(UploadedFile prescription) {
        this.prescription = prescription;
    }

    public String getReqBloodGrp() {
        return reqBloodGrp;
    }

    public void setReqBloodGrp(String reqBloodGrp) {
        this.reqBloodGrp = reqBloodGrp;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getRequestedItem() {
        return requestedItem;
    }

    public void setRequestedItem(String requestedItem) {
        this.requestedItem = requestedItem;
    }

    public List<SelectItem> getItems() {
        return items;
    }

    public void setItems(List<SelectItem> items) {
        this.items = items;
    }

    public void submitMedicalReq() {
        System.out.println("within submitMedicalReq()");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage("medreqmsg", new FacesMessage("", "Your request is submitted"));
    }

    //Tax page
    private String tax;
    private Boolean showProp;

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    private DashboardModel model;

    public DashboardModel getModel() {
        return model;
    }

    public void setModel(DashboardModel model) {
        this.model = model;
    }

    public void searchFrProperty() {
        System.out.println("within searchFrProperty()");
        Map<String, Object> options = new HashMap<String, Object>();
        options.put("resizable", false);
        options.put("draggable", false);
        options.put("modal", true);
        //RequestContext.getCurrentInstance().openDialog("searchProperty", options, null);
        RequestContext.getCurrentInstance().execute("PF('searchProperty').show()");
    }

    public void onPropSelect(SelectEvent event) {
        System.out.println("within onPropSelect() ");
        System.out.println(event.getObject());
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Car Selected", "Id:" + 111);

        FacesContext.getCurrentInstance().addMessage(null, message);
        RequestContext.getCurrentInstance().closeDialog(event.getObject());
    }

    @ManagedProperty(value = "#{property}")
    private Property property;

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public void srchProperty(ActionEvent e) {
        System.out.println("within srchProperty() ");
        System.out.println("search params " + getProperty().getOwnerName());
        FacesMessage message = null;
        if (getProperty().getPinToSrch() == null || getProperty().getPinToSrch().length() <= 0) {
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "What we do in life", "Echoes in eternity.");
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        }
        if (message == null) {
            RequestContext.getCurrentInstance().execute("PF('searchProperty').hide()");
        }

        getProperty().setOwnerName("A A");
        getProperty().setOwnerPhone("1234345");
        getProperty().setAddress("New town");
        getProperty().setPropPin("700156");
        getProperty().setWard("100");
        Tax tax = new Tax();
        tax.setTaxAmt(10000.0);
        tax.setPaymentStatus("Pending");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());
        List l = new ArrayList();
        l.add(tax);
        getProperty().setTaxList(l);
    }

    public void populateTaxOfCurrProp(ActionEvent e) {
        System.out.println("within populateTaxOfCurrProp() " + getProperty());
        getProperty().setOwnerName("B B");
        getProperty().setOwnerPhone("1234345");
        getProperty().setAddress("Rajarhat");
        getProperty().setPropPin("700156");
        getProperty().setWard("200");
        Tax tax = new Tax();
        tax.setTaxAmt(15000.0);
        tax.setPaymentStatus("Paid");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());
        List l = new ArrayList();
        l.add(tax);
        getProperty().setTaxList(l);
    }

    public void payment() {
        System.out.println("within payment()");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage("paymsg", new FacesMessage("", "Your payment is successful"));
    }

    //Online application page
    private String district;
    private String city;
    private String ward;
    private String issueAuth;
    private String applicantName;
    private String houseNo;
    private String streetNo;
    private String building;
    private Integer pin;
    private boolean tenant;
    private String ownerName;
    private String ownerAddr;
    private Double voltage;
    private Double load;
    private Integer noOfOutlets;
    private Integer noOfSockets5A;
    private Integer noOfSockets15A;
    private boolean subMeterReq;
    private String govIdentityNo;
    private UploadedFile govIdentityFile;
    private UploadedFile allotmentLtr;
    private UploadedFile saleDeed;
    private UploadedFile photo;
    private CroppedImage croppedImage;
    private String currentImageName;
    private String newImageName;

    public Boolean getShowProp() {
        return showProp;
    }

    public void setShowProp(Boolean showProp) {
        this.showProp = showProp;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getIssueAuth() {
        return issueAuth;
    }

    public void setIssueAuth(String issueAuth) {
        this.issueAuth = issueAuth;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getStreetNo() {
        return streetNo;
    }

    public void setStreetNo(String streetNo) {
        this.streetNo = streetNo;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public Integer getPin() {
        return pin;
    }

    public void setPin(Integer pin) {
        this.pin = pin;
    }

    public boolean isTenant() {
        return tenant;
    }

    public void setTenant(boolean tenant) {
        this.tenant = tenant;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerAddr() {
        return ownerAddr;
    }

    public void setOwnerAddr(String ownerAddr) {
        this.ownerAddr = ownerAddr;
    }

    public Double getVoltage() {
        return voltage;
    }

    public void setVoltage(Double voltage) {
        this.voltage = voltage;
    }

    public Double getLoad() {
        return load;
    }

    public void setLoad(Double load) {
        this.load = load;
    }

    public Integer getNoOfOutlets() {
        return noOfOutlets;
    }

    public void setNoOfOutlets(Integer noOfOutlets) {
        this.noOfOutlets = noOfOutlets;
    }

    public Integer getNoOfSockets5A() {
        return noOfSockets5A;
    }

    public void setNoOfSockets5A(Integer noOfSockets5A) {
        this.noOfSockets5A = noOfSockets5A;
    }

    public Integer getNoOfSockets15A() {
        return noOfSockets15A;
    }

    public void setNoOfSockets15A(Integer noOfSockets15A) {
        this.noOfSockets15A = noOfSockets15A;
    }

    public boolean isSubMeterReq() {
        return subMeterReq;
    }

    public void setSubMeterReq(boolean subMeterReq) {
        this.subMeterReq = subMeterReq;
    }

    public String getGovIdentityNo() {
        return govIdentityNo;
    }

    public void setGovIdentityNo(String govIdentityNo) {
        this.govIdentityNo = govIdentityNo;
    }

    public UploadedFile getGovIdentityFile() {
        return govIdentityFile;
    }

    public void setGovIdentityFile(UploadedFile govIdentityFile) {
        this.govIdentityFile = govIdentityFile;
    }

    public UploadedFile getSaleDeed() {
        return saleDeed;
    }

    public void setSaleDeed(UploadedFile saleDeed) {
        this.saleDeed = saleDeed;
    }

    public UploadedFile getPhoto() {
        return photo;
    }

    public void setPhoto(UploadedFile photo) {
        this.photo = photo;
    }

    public UploadedFile getAllotmentLtr() {
        return allotmentLtr;
    }

    public void setAllotmentLtr(UploadedFile allotmentLtr) {
        this.allotmentLtr = allotmentLtr;
    }

    public CroppedImage getCroppedImage() {
        return croppedImage;
    }

    public void setCroppedImage(CroppedImage croppedImage) {
        this.croppedImage = croppedImage;
    }

    public String getCurrentImageName() {
        return currentImageName;
    }

    public void setCurrentImageName(String currentImageName) {
        this.currentImageName = currentImageName;
    }

    public String getNewImageName() {
        return newImageName;
    }

    public void setNewImageName(String newImageName) {
        this.newImageName = newImageName;
    }

    private String[] selectedConns;
    private List<String> connTypes;
    private Integer waterSize;
    private Integer sewerageSize;

    public String[] getSelectedConns() {
        return selectedConns;
    }

    public void setSelectedConns(String[] selectedConns) {
        this.selectedConns = selectedConns;
    }

    public List<String> getConnTypes() {
        return connTypes;
    }

    public void setConnTypes(List<String> connTypes) {
        this.connTypes = connTypes;
    }

    public Integer getWaterSize() {
        return waterSize;
    }

    public void setWaterSize(Integer waterSize) {
        this.waterSize = waterSize;
    }

    public Integer getSewerageSize() {
        return sewerageSize;
    }

    public void setSewerageSize(Integer sewerageSize) {
        this.sewerageSize = sewerageSize;
    }

    public void fileUploadAction(FileUploadEvent event) {
        try {
            ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

            FacesContext aFacesContext = FacesContext.getCurrentInstance();
            ServletContext context = (ServletContext) aFacesContext.getExternalContext().getContext();

            String realPath = context.getRealPath("/");

            File file = new File(realPath + "/imagens/prof/");
            file.mkdirs();

            byte[] arquivo = event.getFile().getContents();
            String caminho = realPath + "/imagens/prof/" + event.getFile().getFileName();
            setCurrentImageName(event.getFile().getFileName());

            FileOutputStream fos = new FileOutputStream(caminho);
            fos.write(arquivo);
            fos.close();

        } catch (Exception ex) {
            System.out.println("Erro no upload de imagem" + ex);
        }
    }

    public String crop() {
        if (croppedImage == null) {
            return null;
        }
        setNewImageName(getRandomImageName());
        ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        String newFileName = servletContext.getRealPath("") + File.separator + "imagens" + File.separator + "prof" + File.separator + getNewImageName() + ".jpg";

        FileImageOutputStream imageOutput;
        try {
            imageOutput = new FileImageOutputStream(new File(newFileName));
            imageOutput.write(croppedImage.getBytes(), 0, croppedImage.getBytes().length);
            imageOutput.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public String getRandomImageName() {
        int i = (int) (Math.random() * 100000);

        return String.valueOf(i);
    }

    //License
    private String licenseType;
    private String applicationNo;
    private String state;
    private String rto;
    private String gender;
    private Date dob;
    private String guardian;
    private String citizenshipStat;
    private String qualification;
    private String mark;
    private String booldGrp;
    private String vehicleType;
    private UploadedFile addressProof;
    private UploadedFile qualCert;

    public String getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    public String getApplicationNo() {
        return applicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRto() {
        return rto;
    }

    public void setRto(String rto) {
        this.rto = rto;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getGuardian() {
        return guardian;
    }

    public void setGuardian(String guardian) {
        this.guardian = guardian;
    }

    public String getCitizenshipStat() {
        return citizenshipStat;
    }

    public void setCitizenshipStat(String citizenshipStat) {
        this.citizenshipStat = citizenshipStat;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getBooldGrp() {
        return booldGrp;
    }

    public void setBooldGrp(String booldGrp) {
        this.booldGrp = booldGrp;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public UploadedFile getAddressProof() {
        return addressProof;
    }

    public void setAddressProof(UploadedFile addressProof) {
        this.addressProof = addressProof;
    }

    public UploadedFile getQualCert() {
        return qualCert;
    }

    public void setQualCert(UploadedFile qualCert) {
        this.qualCert = qualCert;
    }

    //skills
    private SkillBean skill;
    private List<SkillBean> skillList;
    @ManagedProperty("#{skillService}")
    private SkillService service;
    private String latitude;
    private String longitude;

    private SkilledPerson skilledP;
    List<SkilledPerson> skilledPersons = new ArrayList<>();

    private String sortStr;

    public SkillBean getSkill() {
        return skill;
    }

    public void setSkill(SkillBean skill) {
        this.skill = skill;
    }

    public List<SkillBean> getSkillList() {
        return skillList;
    }

    public void setSkillList(List<SkillBean> skillList) {
        this.skillList = skillList;
    }

    public SkillService getService() {
        return service;
    }

    public void setService(SkillService service) {
        this.service = service;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public SkilledPerson getSkilledP() {
        return skilledP;
    }

    public void setSkilledP(SkilledPerson skilledP) {
        this.skilledP = skilledP;
    }

    public List<SkilledPerson> getSkilledPersons() {
        return skilledPersons;
    }

    public void setSkilledPersons(List<SkilledPerson> skilledPersons) {
        this.skilledPersons = skilledPersons;
    }

    public void clearSkilledPersonList() {
        if (getSkilledPersons() != null) {
            getSkilledPersons().clear();
        }
    }

    public String getSortStr() {
        return sortStr;
    }

    public void setSortStr(String sortStr) {
        this.sortStr = sortStr;
    }

    public void searchSkill() {
        System.out.println("within searchSkill()");
        System.out.println("latitude " + getLatitude());
        System.out.println("latitude " + getLongitude());
        System.out.println("skill " + getSkill().getName() + " " + getSkill().getId() + " " + getSkill().getDisplayName());
        clearSkilledPersonList();
        if (getSkill().getName() != null && getSkill().getName().equalsIgnoreCase("cook")) {
            getSkilledPersons().add(new SkilledPerson(1, "aaa", "rajarhat", 4, "123456"));
            getSkilledPersons().add(new SkilledPerson(2, "bbb", "new town", 0, "9832000111"));
            getSkilledPersons().add(new SkilledPerson(3, "ccc", "palli", null, ""));
            getSkilledPersons().add(new SkilledPerson(4, "ddd", "kestopur", 5, "033-23456323"));
            setSortStr("Sort by Location");
        }
    }

    public void loadIdentityDoc(SkilledPerson p) throws FileNotFoundException, IOException {
        System.out.println("within loadIdentityDoc() " + p);
        System.out.println("object " + p.getId());
    }

    public List<SkillBean> completeSkill(String query) {
        List<SkillBean> allSkills = service.getSkills();
        List<SkillBean> filteredSkills = new ArrayList<SkillBean>();

        if (allSkills != null && !allSkills.isEmpty()) {
            SkillBean skill = null;
            for (int i = 0; i < allSkills.size(); i++) {
                skill = allSkills.get(i);
                if (skill.getName().toLowerCase().contains(query)) {
                    filteredSkills.add(skill);
                }
            }
        }
        return filteredSkills;
    }

    public void searchSkillService() {
        System.out.println("within searchSkillService()");
        System.out.println("search query " + getSkill());
        List<SkillBean> allSkills = service.getSkills();
        if (allSkills != null && !allSkills.isEmpty() && getSkill() != null) {
            SkillBean skill = null;
            for (int i = 0; i < allSkills.size(); i++) {
                skill = allSkills.get(i);
                if (skill.getName().toLowerCase().equals(getSkill().getName())) {
                    if (skillList != null) {
                        skillList.clear();
                    }
                    skillList.add(skill);
                }
            }
        }
    }

    public void resetSkillService() {
        System.out.println("within resetSkillService()");
        if (skillList != null) {
            skillList.clear();
        }
        skillList.add(new SkillBean(0, "Cook", "cook"));
        skillList.add(new SkillBean(1, "Maid", "maid"));
        skillList.add(new SkillBean(2, "Carpenter", "carpenter"));
        skillList.add(new SkillBean(3, "Plumber", "plumber"));
    }

    //senior citizen distress
    private String snrctznId = "";
    private String scName;
    private Integer scPhone;
    private String scGender;
    private long scAge;
    private boolean isAddrSame;
    private String scAddress;

    public String getSnrctznId() {
        return snrctznId;
    }

    public void setSnrctznId(String snrctznId) {
        this.snrctznId = snrctznId;
    }

    public String getScName() {
        return scName;
    }

    public void setScName(String scName) {
        this.scName = scName;
    }

    public Integer getScPhone() {
        return scPhone;
    }

    public void setScPhone(Integer scPhone) {
        this.scPhone = scPhone;
    }

    public String getScGender() {
        return scGender;
    }

    public void setScGender(String scGender) {
        this.scGender = scGender;
    }

    public long getScAge() {
        return scAge;
    }

    public void setScAge(long scAge) {
        this.scAge = scAge;
    }

    public boolean isIsAddrSame() {
        return isAddrSame;
    }

    public void setIsAddrSame(boolean isAddrSame) {
        this.isAddrSame = isAddrSame;
    }

    public String getScAddress() {
        return scAddress;
    }

    public void setScAddress(String scAddress) {
        this.scAddress = scAddress;
    }

    public void searchSnrCitizen(ActionEvent event) {
        System.out.println("within searchSnrCitizen() " + getSnrctznId());
        if (getSnrctznId() == null || getSnrctznId().trim().equals("")) {
            return;
        }
        //search logic
        Userinfo user = dataServices.searchUserById(new Integer(getSnrctznId()));
        boolean resultFound = true;
        if (user == null) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("rslt", new FacesMessage("", "ID not found"));
            return;
        }
        setScName(user.getFirstname()+" "+user.getLastname());
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");        
        Date d = new Date(format.format(user.getDob()));
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        int byear = cal.get(Calendar.YEAR);
        int bmonth = cal.get(Calendar.MONTH);
        int bday = cal.get(Calendar.DATE);
        LocalDateTime now = LocalDateTime.now();
        int year = now.getYear();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();
        LocalDate start = LocalDate.of(byear, bmonth, bday);
        LocalDate end = LocalDate.of(year, month, day); // use for age-calculation: LocalDate.now()
        long years = ChronoUnit.YEARS.between(start, end);
        System.out.println("Age " + years);        
        setScAge(years);
        setScPhone(user.getMobile());
        setScAddress(user.getAddressList().get(0).getHouseNo()+", "+user.getAddressList().get(0).getStreetNo()+", "+user.getAddressList().get(0).getBuilding()+", "+user.getAddressList().get(0).getPin()+", "+user.getAddressList().get(0).getPin());
        RequestContext.getCurrentInstance().execute("PF('snctznsrchDlg').hide()");
    }

    public void loadSCAddress() {
        System.out.println("within loadSCAddress()");
        //to do - if getScAddress() is null or blank, pull user's address and save
        setScAddress("new town");
    }

    public void saveSCInfo() {
        System.out.println("within saveSCInfo()");
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("distress:scpanel");
        context.scrollTo("distress:scpanel");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Senior Citizen information saved", "Distress Service activated"));
    }
    
    public void registerSCInfo() {
        System.out.println("within registerSCInfo()");
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("distress:scpanel");
        context.scrollTo("distress:scpanel");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Senior Citizen information saved", "Distress Service activated"));
    }

    private UIComponent comp;

    public UIComponent getComp() {
        return comp;
    }

    public void setComp(UIComponent comp) {
        this.comp = comp;
    }

    //Recruitment
    private List<Recruitment> recruitList = new ArrayList<>();
    private StreamedContent file;

    public StreamedContent getFile() {
        return file;
    }

    public List<Recruitment> getRecruitList() {
        return recruitList;
    }

    public void setRecruitList(List<Recruitment> recruitList) {
        this.recruitList = recruitList;
    }

    //projects
    private PieChartModel livePieModel;

    public PieChartModel getLivePieModel() {
        int random1 = (int) (Math.random() * 1000);
        int random2 = (int) (Math.random() * 1000);
        int random3 = (int) (Math.random() * 500);
        livePieModel = new PieChartModel();
        livePieModel.getData().put("Work Completed", random1);
        livePieModel.getData().put("Work Pending", random2);
        livePieModel.getData().put("Finance Approval Pending", random3);

        //livePieModel.setTitle("Progress");
        livePieModel.setLegendPosition("w");

        return livePieModel;
    }



}
