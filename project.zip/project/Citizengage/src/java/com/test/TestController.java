/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

/**
 *
 * @author Sourik
 */
//@Named(value = "testController")
@ManagedBean(name="testController")
@Dependent
public class TestController {

    
    private String module;
    
    @ManagedProperty(value = "#{testManagedBean}")
    TestManagedBean bean;
    
    /**
     * Creates a new instance of TestController
     */
    public TestController() {
    }

    public String getModule() {
        System.out.println("in getModule() "+module);
        return module;
    }

    public void setModule(String module) {
        System.out.println("in setModule() "+module);
        this.module = module;
    }

    public TestManagedBean getBean() {
        return bean;
    }

    public void setBean(TestManagedBean bean) {
        this.bean = bean;        
    }
    
    
}
