/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

/**
 *
 * @author Sourik
 */
@MappedSuperclass
public abstract class AuditBase {
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DateCrtd", insertable = false, updatable = false)
    private Date created;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DateMdfd", insertable = false, updatable = true)
    //@Version
    private Date updated;

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    

    

    @PrePersist
    protected void onCreate(){
        created = new Date();
    }
    
    @PreUpdate
    protected void onUpdate(){
        updated = new Date();
    }
}
