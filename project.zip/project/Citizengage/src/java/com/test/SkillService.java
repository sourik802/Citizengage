/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Sourik
 */
@ManagedBean(name = "skillService", eager = true)
@ViewScoped
public class SkillService {

    private List<SkillBean> skills;

    /**
     * Creates a new instance of SkillService
     */
    public SkillService() {
    }

    public List<SkillBean> getSkills() {
        return skills;
    }

    public void setSkills(List<SkillBean> skills) {
        this.skills = skills;
    }

    @PostConstruct
    public void init() {
        if (skills == null) {
            skills = new ArrayList<>();
        }

        skills.add(new SkillBean(0, "Cook", "cook"));
        skills.add(new SkillBean(1, "Maid", "maid"));
        skills.add(new SkillBean(2, "Carpenter", "carpenter"));
        skills.add(new SkillBean(3, "Plumber", "plumber"));
    }
}
