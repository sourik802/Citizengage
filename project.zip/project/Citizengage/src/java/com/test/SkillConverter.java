/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

/**
 *
 * @author Sourik
 */

@ManagedBean(name="skillConverter1")
public class SkillConverter implements Converter{
 
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if(value != null && value.trim().length() > 0) {
            try {
                System.out.println("bean "+FacesContext.getCurrentInstance().getExternalContext().getApplicationMap().get("skillService"));
                
                SkillService service = (SkillService) fc.getExternalContext().getApplicationMap().get("skillService");
                return service.getSkills().get(Integer.parseInt(value));
            } catch(NumberFormatException e) {
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Conversion Error", "Not a valid skill."));
            }
        }
        else {
            return null;
        }

    }
 
    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if(object != null) {
            return String.valueOf(((SkillBean) object).getId());
        }
        else {
            return null;
        }
    }   

}
