/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 258290
 */
public class Property implements Serializable{

    private String pinToSrch;
    private String ownerNameToSrch;
    private String ownerPhoneToSrch;
    private String propPin;
    private String ownerName;
    private String ownerPhone;
    private String address;
    private String ward;
    private List<Tax> propertyTaxList = new ArrayList<>();

    /**
     * Creates a new instance of Property
     */
    public Property() {
    }

    public String getPinToSrch() {
        return pinToSrch;
    }

    public void setPinToSrch(String pinToSrch) {
        this.pinToSrch = pinToSrch;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    public String getOwnerNameToSrch() {
        return ownerNameToSrch;
    }

    public void setOwnerNameToSrch(String ownerNameToSrch) {
        this.ownerNameToSrch = ownerNameToSrch;
    }

    public String getOwnerPhoneToSrch() {
        return ownerPhoneToSrch;
    }

    public void setOwnerPhoneToSrch(String ownerPhoneToSrch) {
        this.ownerPhoneToSrch = ownerPhoneToSrch;
    }

    public String getPropPin() {
        return propPin;
    }

    public void setPropPin(String propPin) {
        this.propPin = propPin;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public List<Tax> getPropertyTaxList() {
        return propertyTaxList;
    }

    public void setPropertyTaxList(List<Tax> propertyTaxList) {
        this.propertyTaxList = propertyTaxList;
    }

}
