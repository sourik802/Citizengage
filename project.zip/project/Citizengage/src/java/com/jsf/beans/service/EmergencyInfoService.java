/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;

/**
 *
 * @author 258290
 */
@Named(value = "emergencyInfo")
@ApplicationScoped
public class EmergencyInfoService {

    private DashboardModel model;
    /**
     * Creates a new instance of EmergencyInfoService
     */
    public EmergencyInfoService() {
    }
    
    @PostConstruct
    public void init(){
        model = new DefaultDashboardModel();
        DashboardColumn col1 = new DefaultDashboardColumn();
        DashboardColumn col2 = new DefaultDashboardColumn();
        DashboardColumn col3 = new DefaultDashboardColumn();
        
        col1.addWidget(0, "Fire");
        col2.addWidget(0, "Police");
        col3.addWidget(0, "Ambulance");
                
        model.addColumn(col1);
        model.addColumn(col2);
        model.addColumn(col3);
        
    }

    public DashboardModel getModel() {
        return model;
    }
    
    
}
