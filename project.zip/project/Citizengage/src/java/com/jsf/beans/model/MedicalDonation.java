/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class MedicalDonation {

    private String reqName;
    private String ailment;
    private String reqGender;
    private Integer reqAge;
    private String docName;
    private String hospName;
    private UploadedFile prescription;
    private String reqBloodGrp;
    private String specification;
    private String requestedItem;
    private List<SelectItem> items = new ArrayList<>();

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getAilment() {
        return ailment;
    }

    public void setAilment(String ailment) {
        this.ailment = ailment;
    }

    public String getReqGender() {
        return reqGender;
    }

    public void setReqGender(String reqGender) {
        this.reqGender = reqGender;
    }

    public Integer getReqAge() {
        return reqAge;
    }

    public void setReqAge(Integer reqAge) {
        this.reqAge = reqAge;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getHospName() {
        return hospName;
    }

    public void setHospName(String hospName) {
        this.hospName = hospName;
    }

    public UploadedFile getPrescription() {
        return prescription;
    }

    public void setPrescription(UploadedFile prescription) {
        this.prescription = prescription;
    }

    public String getReqBloodGrp() {
        return reqBloodGrp;
    }

    public void setReqBloodGrp(String reqBloodGrp) {
        this.reqBloodGrp = reqBloodGrp;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getRequestedItem() {
        return requestedItem;
    }

    public void setRequestedItem(String requestedItem) {
        this.requestedItem = requestedItem;
    }

    public List<SelectItem> getItems() {
        return items;
    }

    public void setItems(List<SelectItem> items) {
        this.items = items;
    }

    public void submitMedicalReq() {
        System.out.println("within submitMedicalReq()");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage("medreqmsg", new FacesMessage("", "Your request is submitted"));
    }
}
