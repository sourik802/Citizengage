/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.ejb.LoadKeyValues;
import com.citizengage.exception.CitizengageException;
import com.jsf.beans.model.Legal;
import java.io.IOException;
import java.io.InputStream;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.map.PointSelectEvent;
import org.primefaces.model.map.LatLng;

/**
 *
 * @author 258290
 */
@Named(value = "legal")
@SessionScoped
public class LegalService implements Serializable {

    @EJB
    private DataServicesHelper dataServices;

    @EJB
    private LoadKeyValues keyValues;

    private Legal legal;
    private UIInput evFile;

    private Map<String, String> complainType = new HashMap<>();
    private Map<String, String> polStns = new HashMap<>();

    /**
     * Creates a new instance of Legal
     */
    public LegalService() {
    }

    @PostConstruct
    public void init() {
        complainType = keyValues.getComplainTyp();
        polStns = keyValues.getPolStns();
        
        if(getLegal() == null){
            setLegal(new Legal());
        }
    }

    public Map<String, String> getComplainType() {
        return complainType;
    }

    public Map<String, String> getPolStns() {
        return polStns;
    }

    public Legal getLegal() {
        return legal;
    }

    public void setLegal(Legal legal) {
        this.legal = legal;
    }

    public void onPointSelect(PointSelectEvent event) {
        LatLng latlng = event.getLatLng();
        if (getLegal() == null) {
            setLegal(new Legal());
        }
        getLegal().setLatitude(latlng.getLat());
        getLegal().setLongitude(latlng.getLng());
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Point Selected", "Lat:" + latlng.getLat() + ", Lng:" + latlng.getLng()));
    }

    public void addMessage(FacesMessage message) {
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public UIInput getEvFile() {
        return evFile;
    }

    public void setEvFile(UIInput evFile) {
        this.evFile = evFile;
    }

    public void handleFileUpload(FileUploadEvent event) throws IOException {
        System.out.println("file uploading " + event.getFile().getFileName() + " is uploaded of size " + event.getFile().getSize());
        InputStream is = event.getFile().getInputstream();
        System.out.println("file inputstream "+is);        
        if(getLegal().getIs() == null){
            getLegal().setIs(new ArrayList<>());
        }
        getLegal().getIs().add(is);
        System.out.println("inputstream list "+getLegal().getIs());
    }

    public void processValidations(UIInput input) {
        FacesContext context = FacesContext.getCurrentInstance();
        UIInput fileUploadComponent1 = getEvFile();

//        if (fileUploadComponent1 != null && getLegal().getFile() == null) {
//            fileUploadComponent1.setValid(false);
//            context.addMessage(fileUploadComponent1.getClientId(context), new FacesMessage(FacesMessage.SEVERITY_ERROR, "file not uploaded", "no file"));
//            context.validationFailed();
//        }
    }
    
    public void submitComplain() {
        System.out.println("within submitComplain() "+getLegal().getSummary());
        try {            
            Integer id = dataServices.persistLegalComplain(getLegal());
            if (id != null && !id.equals(0)) {                
                RequestContext context = RequestContext.getCurrentInstance();
                context.update("legalform:legalpanel");
                context.scrollTo("legalform:legalpanel");
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Your complain is submitted, provisional Complain id is " + id, "Successfully registered  " + id));
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Failed to submit complain, please try again"));
            }
        } catch (CitizengageException cex) {
            System.err.println("Error " + cex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Failed to submit complain due to " + cex.getMessage() + ", please try again"));
        } catch (Exception ex) {
            Logger.getLogger(LoginService.class.getName()).log(Level.SEVERE, null, ex);
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Failed to submit complain ", "Error is " + ex.getMessage()));
        }
    }
}
