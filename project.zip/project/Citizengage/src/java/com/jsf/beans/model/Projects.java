/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.util.Date;
import org.primefaces.model.chart.PieChartModel;

/**
 *
 * @author 258290
 */
public class Projects {

    private String projectName;
    private Date dtOfInitiation;
    private String department;
    private Date dtOfStart;
    private String contractor;
    private String status;
    private Date deadLine;
    private String description;
    private String conceptBy;
    private PieChartModel projectProgressModel;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Date getDtOfInitiation() {
        return dtOfInitiation;
    }

    public void setDtOfInitiation(Date dtOfInitiation) {
        this.dtOfInitiation = dtOfInitiation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Date getDtOfStart() {
        return dtOfStart;
    }

    public void setDtOfStart(Date dtOfStart) {
        this.dtOfStart = dtOfStart;
    }

    public String getContractor() {
        return contractor;
    }

    public void setContractor(String contractor) {
        this.contractor = contractor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDeadLine() {
        return deadLine;
    }

    public void setDeadLine(Date deadLine) {
        this.deadLine = deadLine;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getConceptBy() {
        return conceptBy;
    }

    public void setConceptBy(String conceptBy) {
        this.conceptBy = conceptBy;
    }

    public PieChartModel getProjectProgressModel() {
        int random1 = (int) (Math.random() * 1000);
        int random2 = (int) (Math.random() * 1000);
        int random3 = (int) (Math.random() * 500);
        projectProgressModel = new PieChartModel();
        projectProgressModel.getData().put("Work Completed", random1);
        projectProgressModel.getData().put("Work Pending", random2);
        projectProgressModel.getData().put("Finance Approval Pending", random3);

        //livePieModel.setTitle("Progress");
        projectProgressModel.setLegendPosition("w");
        return projectProgressModel;
    }

}
