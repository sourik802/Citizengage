/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Projects;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;

/**
 *
 * @author Sourik
 */
@Named(value = "projects")
@ApplicationScoped
public class ProjectsService {

    private Projects projects;
    private List<Projects> projectList = new ArrayList<>();
    /**
     * Creates a new instance of ProjectsService
     */
    public ProjectsService() {
    }
    
    @PostConstruct
    public void init(){
        Projects p1 = new Projects();
        p1.setConceptBy("KMD");
        p1.setContractor("T & L");
        p1.setDeadLine(new Date());
        p1.setDepartment("KMCA");
        p1.setDescription("all profile should have a id\n"
                + "on submit display application no/request no/ticket no on page\n"
                + "\n"
                + "\n"
                + "\n"
                + "\n"
                + "report on all services - automated\n"
                + "\n"
                + "group and community - individuals can form or follow groups and submit request on the above as groups\n"
                + "\n"
                + "request tracking, status\n"
                + "\n"
                + "chat facility\n"
                + "\n"
                + "search for a housing already registered and become a member\n"
                + "suggestion\n"
                + "pin no check while user registration if pin falls under smart city jurisdiction - master table tracking\n"
                + "benchmark data display - doctors/population, police/population, transport/population\n"
                + "register housing society - save green cover - no of trees and their age, solar power coverage, rain water harvesting");
        p1.setDtOfInitiation(new Date());
        p1.setDtOfStart(new Date());
        p1.setProjectName("ABC Flyover");
        p1.setStatus("In Progress");
        
        Projects p2 = new Projects();
        p2.setConceptBy("KMD");
        p2.setContractor("T & L");
        p2.setDeadLine(new Date());
        p2.setDepartment("KMCA");
        p2.setDescription("all profile should have a id\n"
                + "on submit display application no/request no/ticket no on page\n"
                + "\n"
                + "\n"
                + "\n"
                + "\n"
                + "report on all services - automated\n"
                + "\n"
                + "group and community - individuals can form or follow groups and submit request on the above as groups\n"
                + "\n"
                + "request tracking, status\n"
                + "\n"
                + "chat facility\n"
                + "\n"
                + "search for a housing already registered and become a member\n"
                + "suggestion\n"
                + "pin no check while user registration if pin falls under smart city jurisdiction - master table tracking\n"
                + "benchmark data display - doctors/population, police/population, transport/population\n"
                + "register housing society - save green cover - no of trees and their age, solar power coverage, rain water harvesting");
        p2.setDtOfInitiation(new Date());
        p2.setDtOfStart(new Date());
        p2.setProjectName("XYZ Housing");
        p2.setStatus("In Progress");
        
        getProjectList().add(p1);
        getProjectList().add(p2);
    }

    public Projects getProjects() {
        return projects;
    }

    public void setProjects(Projects projects) {
        this.projects = projects;
    }

    public List<Projects> getProjectList() {
        return projectList;
    }

    public void setProjectList(List<Projects> projectList) {
        this.projectList = projectList;
    }
    
    
}
