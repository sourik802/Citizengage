/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;

/**
 *
 * @author Sourik
 */
public class EnvironmentBenchmark {

    private LineChartModel greenCoverModel;
    private LineChartModel monsoonModel;

    public void createLineModels() {
        greenCoverModel = initLinearModel();
        greenCoverModel.setTitle("Green Cover Statistics");
        greenCoverModel.setLegendPosition("e");
        greenCoverModel.setSeriesColors("1BC42E");
        Axis yAxis = greenCoverModel.getAxis(AxisType.Y);
        yAxis.setMin(0);
        yAxis.setMax(1);
        yAxis.setLabel("Per sq km");

        monsoonModel = initLinearModelRain();
        monsoonModel.setTitle("Rainfall");
        monsoonModel.setLegendPosition("e");
        monsoonModel.setSeriesColors("848389");
        Axis yAxis1 = monsoonModel.getAxis(AxisType.Y);
        yAxis1.setMin(0);
        yAxis1.setMax(110);
        yAxis1.setLabel("mm");
    }

    public LineChartModel getGreenCoverModel() {
        return greenCoverModel;
    }

    public void setGreenCoverModel(LineChartModel greenCoverModel) {
        this.greenCoverModel = greenCoverModel;
    }

    public LineChartModel getMonsoonModel() {
        return monsoonModel;
    }

    public void setMonsoonModel(LineChartModel monsoonModel) {
        this.monsoonModel = monsoonModel;
    }

    
    private LineChartModel initLinearModel() {
        LineChartModel model = new LineChartModel();

        LineChartSeries series1 = new LineChartSeries();
        series1.setLabel("Green cover");

        series1.set(2008, .2);
        series1.set(2010, .1);
        series1.set(2012, .3);
        series1.set(2014, .4);
        series1.set(2016, .4);

        model.addSeries(series1);

        return model;
    }

    private LineChartModel initLinearModelRain() {
        LineChartModel model = new LineChartModel();

        LineChartSeries series1 = new LineChartSeries();
        series1.setLabel("Monsoon");

        series1.set(2008, 44);
        series1.set(2010, 80);
        series1.set(2012, 101);
        series1.set(2014, 98);
        series1.set(2016, 99);

        model.addSeries(series1);

        return model;
    }
}
