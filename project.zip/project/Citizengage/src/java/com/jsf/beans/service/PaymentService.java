/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Sourik
 */
@Named(value = "payment")
@SessionScoped
public class PaymentService implements Serializable {

    private Double amount;
    private String payingFor;
    
    /**
     * Creates a new instance of PaymentService
     */
    public PaymentService() {
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getPayingFor() {
        return payingFor;
    }

    public void setPayingFor(String payingFor) {
        this.payingFor = payingFor;
    }
    
    public String confirmPay(){
        System.out.println("within confirmPay()");
        RequestContext.getCurrentInstance().closeDialog("payment");
        return "tax";
    }
}
