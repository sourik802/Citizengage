/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.BarChartModel;
import org.primefaces.model.chart.ChartSeries;

/**
 *
 * @author Sourik
 */
public class EducationBenchmark {

    private BarChartModel educationModel;

    private BarChartModel initBarModel() {
        BarChartModel model = new BarChartModel();

        ChartSeries edu = new ChartSeries();
        edu.setLabel("Student Count");
        edu.set("Students in Primary", 1349);
        edu.set("Students passing Std X", 983);
        edu.set("Students passing Std XII", 807);
        edu.set("Graduating students", 760);

        model.addSeries(edu);

        return model;
    }

    public BarChartModel getEducationModel() {
        return educationModel;
    }

    public void setEducationModel(BarChartModel educationModel) {
        this.educationModel = educationModel;
    }

    public void createBarModel() {
        educationModel = initBarModel();

        educationModel.setTitle("Education");
        educationModel.setLegendPosition("ne");

        Axis xAxis = educationModel.getAxis(AxisType.X);
        xAxis.setLabel("2015 data");

        Axis yAxis = educationModel.getAxis(AxisType.Y);
        yAxis.setLabel("No of students");
        yAxis.setMin(0);
        yAxis.setMax(1400);
    }

}
