/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Schedule;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import org.primefaces.context.RequestContext;
import org.primefaces.event.ScheduleEntryMoveEvent;
import org.primefaces.event.ScheduleEntryResizeEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultScheduleEvent;
import org.primefaces.model.ScheduleEvent;
import org.primefaces.model.ScheduleModel;

/**
 *
 * @author Sourik
 */
@Named(value = "schedule")
@SessionScoped
public class ScheduleService implements Serializable {

    private ScheduleModel model;
    private Schedule schedules;
    private ScheduleEvent event = new DefaultScheduleEvent();

    /**
     * Creates a new instance of ScheduleService
     */
    public ScheduleService() {
    }

    @PostConstruct
    public void init() {
        schedules = new Schedule();
    }

    public ScheduleModel getModel() {
        System.out.println("events " + schedules.getEvents());
        model = schedules.getEvents();
        return model;
    }

    public Schedule getSchedules() {
        return schedules;
    }

    public ScheduleEvent getEvent() {
        return event;
    }

    public void setEvent(ScheduleEvent event) {
        this.event = event;
    }

    public void onEventSelect(SelectEvent selectEvent) {
        event = (ScheduleEvent) selectEvent.getObject();
    }

    public void onDateSelect(SelectEvent selectEvent) {
        event = new DefaultScheduleEvent("", (Date) selectEvent.getObject(), (Date) selectEvent.getObject());
    }

    public void onEventMove(ScheduleEntryMoveEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Event moved", "Day delta:" + event.getDayDelta() + ", Minute delta:" + event.getMinuteDelta());

        addMessage(message);
    }

    public void onEventResize(ScheduleEntryResizeEvent event) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Event resized", "Day delta:" + event.getDayDelta() + ", Minute delta:" + event.getMinuteDelta());

        addMessage(message);
    }

    private void addMessage(FacesMessage message) {
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void addEvent(ActionEvent actionEvent) {
        System.out.println("within addEvent()");
        if (event.getId() == null) {
            model.addEvent(event);
        } else {
            model.updateEvent(event);
        }

        RequestContext context = RequestContext.getCurrentInstance();
        context.execute("PF('myschedule').update()");

        event = new DefaultScheduleEvent();
    }

}
