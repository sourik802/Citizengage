/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Address;
import com.jsf.beans.model.ElectricConnection;
import com.jsf.beans.model.License;
import com.jsf.beans.model.WaterConnection;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Iterator;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.TabChangeEvent;

/**
 *
 * @author 258290
 */
@Named(value = "onlineApplication")
@SessionScoped
public class OnlineApplicationService implements Serializable {

    private ElectricConnection electric;
    private WaterConnection water;
    private License license;
    private String currentImageName;
    private UIInput picFile;
    private UIInput idFile;
    private UIInput sdFile;
    private UIInput evFile;
    private UIInput picFile1;
    private UIInput idFile1;
    private UIInput sdFile1;
    private UIInput alFile;
    private UIInput idFile2;
    private UIInput picFile2;
    private UIInput apFile;
    private UIInput qFile;

    /**
     * Creates a new instance of OnlineApplicationService
     */
    public OnlineApplicationService() {
    }

    @PostConstruct
    public void init() {
        if (electric == null) {
            electric = new ElectricConnection();
        }
        if (water == null) {
            water = new WaterConnection();
        }
        if (license == null) {
            license = new License();
        }
        if (getElectric().getAddress() == null) {
            getElectric().setAddress(new Address());
        }
        if (getWater().getAddress() == null) {
            getWater().setAddress(new Address());
        }
        if (getLicense().getAddress() == null) {
            getLicense().setAddress(new Address());
        }
    }

    public ElectricConnection getElectric() {
        return electric;
    }

    public void setElectric(ElectricConnection electric) {
        this.electric = electric;
    }

    public WaterConnection getWater() {
        return water;
    }

    public void setWater(WaterConnection water) {
        this.water = water;
    }

    public License getLicense() {
        return license;
    }

    public void setLicense(License license) {
        this.license = license;
    }

    public String getCurrentImageName() {
        return currentImageName;
    }

    public void setCurrentImageName(String currentImageName) {
        this.currentImageName = currentImageName;
    }

    public void fileUploadAction(FileUploadEvent event) {
        try {
            ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

            FacesContext aFacesContext = FacesContext.getCurrentInstance();
            ServletContext context = (ServletContext) aFacesContext.getExternalContext().getContext();

            String realPath = context.getRealPath("/");

            File file = new File(realPath + "/imagens/prof/");
            file.mkdirs();

            byte[] arquivo = event.getFile().getContents();
            String caminho = realPath + "/imagens/prof/" + event.getFile().getFileName();
            setCurrentImageName(event.getFile().getFileName());

            FileOutputStream fos = new FileOutputStream(caminho);
            fos.write(arquivo);
            fos.close();

        } catch (Exception ex) {
            System.out.println("Erro no upload de imagem" + ex);
        }
    }

    public void handleFileUpload(FileUploadEvent event) throws IOException {
        System.out.println("file uploading " + event.getFile().getFileName() + " is uploaded of size " + event.getFile().getSize());
    }

    public void requestElectricConn() {
        System.out.println("within requestElectricConn()");
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("onlineapplnpanel:onlinappform");
        context.scrollTo("onlineapplnpanel:onlinappform");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Your application has been successfully sent to " + getElectric().getIssueAuthority()+". You will be notified through email for further actions.", "Successfully registered  "));
    }

    public void requestWaterConn() {
        System.out.println("within requestWaterConn()");
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("onlineapplnpanel:onlinappform1");
        context.scrollTo("onlineapplnpanel:onlinappform1");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Your application has been successfully sent. You will be notified through email for further actions.", "Successfully registered  "));
    }

    public void requestLicense() {
        System.out.println("within requestLicense()");
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("onlineapplnpanel:onlinappform2");
        context.scrollTo("onlineapplnpanel:onlinappform2");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Your application has been successfully sent to " + getLicense().getRto()+ " RTO. You will be notified through email for further actions.", "Successfully registered  "));
    }

    public void onTabChange(TabChangeEvent event) {
        System.out.println("within onTabChange() of " + getClass());
        System.out.println("Active Tab: " + event.getTab().getTitle());
        if (event.getTab().getTitle() != null && event.getTab().getTitle().contains("Electric Connection")) {
            
        } else if (event.getTab().getTitle() != null && event.getTab().getTitle().contains("Water Connection")) {
            
        } else if (event.getTab().getTitle() != null && event.getTab().getTitle().contains("Driving License")) {
            
        }
        FacesContext context = FacesContext.getCurrentInstance();
        Iterator<FacesMessage> it = context.getMessages();
        while (it.hasNext()) {
            it.next();
            it.remove();
        }
        FacesContext.getCurrentInstance().renderResponse();
    }

    public UIInput getPicFile() {
        return picFile;
    }

    public void setPicFile(UIInput picFile) {
        this.picFile = picFile;
    }

    public UIInput getIdFile() {
        return idFile;
    }

    public void setIdFile(UIInput idFile) {
        this.idFile = idFile;
    }

    public UIInput getSdFile() {
        return sdFile;
    }

    public void setSdFile(UIInput sdFile) {
        this.sdFile = sdFile;
    }

    public UIInput getEvFile() {
        return evFile;
    }

    public void setEvFile(UIInput evFile) {
        this.evFile = evFile;
    }

    public UIInput getPicFile1() {
        return picFile1;
    }

    public void setPicFile1(UIInput picFile1) {
        this.picFile1 = picFile1;
    }

    public UIInput getIdFile1() {
        return idFile1;
    }

    public void setIdFile1(UIInput idFile1) {
        this.idFile1 = idFile1;
    }

    public UIInput getSdFile1() {
        return sdFile1;
    }

    public void setSdFile1(UIInput sdFile1) {
        this.sdFile1 = sdFile1;
    }

    public UIInput getAlFile() {
        return alFile;
    }

    public void setAlFile(UIInput alFile) {
        this.alFile = alFile;
    }

    public UIInput getIdFile2() {
        return idFile2;
    }

    public void setIdFile2(UIInput idFile2) {
        this.idFile2 = idFile2;
    }

    public UIInput getPicFile2() {
        return picFile2;
    }

    public void setPicFile2(UIInput picFile2) {
        this.picFile2 = picFile2;
    }

    public UIInput getApFile() {
        return apFile;
    }

    public void setApFile(UIInput apFile) {
        this.apFile = apFile;
    }

    public UIInput getQFile() {
        return qFile;
    }

    public void setQFile(UIInput qFile) {
        this.qFile = qFile;
    }

    public void processValidations(UIInput input) {
        FacesContext context = FacesContext.getCurrentInstance();

//        if (input != null) {
//            input.setValid(false);
//            context.addMessage(input.getClientId(context), new FacesMessage(FacesMessage.SEVERITY_ERROR, "file not uploaded", "no file"));
//            context.validationFailed();
//        }
    }
}
