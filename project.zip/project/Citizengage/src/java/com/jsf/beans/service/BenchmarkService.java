/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.EducationBenchmark;
import com.jsf.beans.model.EnvironmentBenchmark;
import com.jsf.beans.model.HealthcareBenchmark;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;

/**
 *
 * @author Sourik
 */
@Named(value = "benchmark")
@ApplicationScoped
public class BenchmarkService {

    HealthcareBenchmark bm;
    EnvironmentBenchmark em;
    EducationBenchmark sm;
    
    /**
     * Creates a new instance of BenchmarkService
     */
    public BenchmarkService() {
    }
    
    @PostConstruct
    public void init(){
        bm = new HealthcareBenchmark();
        bm.createBarModel();
        
        em = new EnvironmentBenchmark();
        em.createLineModels();
        
        sm = new EducationBenchmark();
        sm.createBarModel();
    }

    public HealthcareBenchmark getBm() {
        return bm;
    }

    public void setBm(HealthcareBenchmark bm) {
        this.bm = bm;
    }

    public EnvironmentBenchmark getEm() {
        return em;
    }

    public void setEm(EnvironmentBenchmark em) {
        this.em = em;
    }

    public EducationBenchmark getSm() {
        return sm;
    }

    public void setSm(EducationBenchmark sm) {
        this.sm = sm;
    }
    
    
}
