/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Property;
import com.jsf.beans.model.Tax;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.primefaces.context.RequestContext;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;

/**
 *
 * @author 258290
 */
@Named(value = "tax")
@SessionScoped
public class TaxService implements Serializable {

    private Property property;
    private DashboardModel model;
    private List<Tax> waterTaxList = new ArrayList<>();
    private List<Tax> electricTaxList = new ArrayList<>();
    private String tabSelected;
    private String waterConnConsumerID;
    private String electricConnConsumerID;
    private Double totalTax;

    /**
     * Creates a new instance of TaxService
     */
    public TaxService() {
    }

    @PostConstruct
    public void init() {
        if (property == null) {
            property = new Property();
        }
        model = new DefaultDashboardModel();
        DashboardColumn column1 = new DefaultDashboardColumn();
        column1.addWidget("address");
        model.addColumn(column1);
    }

    public DashboardModel getModel() {
        return model;
    }

    public void setModel(DashboardModel model) {
        this.model = model;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public void srchProperty(ActionEvent e) {
        System.out.println("within srchProperty() ");
        System.out.println("search params " + getProperty().getOwnerName());
        FacesMessage message = null;
        if (getProperty().getPinToSrch() == null || getProperty().getPinToSrch().length() <= 0) {
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "What we do in life", "Echoes in eternity.");
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        }
        if (message == null) {
            RequestContext.getCurrentInstance().execute("PF('searchProperty').hide()");
        }

        getProperty().setOwnerName("A A");
        getProperty().setOwnerPhone("1234345");
        getProperty().setAddress("New town");
        getProperty().setPropPin("700156");
        getProperty().setWard("100");
        Tax tax = new Tax();
        tax.setTaxAmt(10000.0);
        tax.setPaymentStatus("Pending");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());
        List l = new ArrayList();
        l.add(tax);
        getProperty().setPropertyTaxList(l);
    }

    public void populateTaxOfCurrProp(ActionEvent e) {
        System.out.println("within populateTaxOfCurrProp() " + getProperty());
        getProperty().setOwnerName("B B");
        getProperty().setOwnerPhone("1234345");
        getProperty().setAddress("Rajarhat");
        getProperty().setPropPin("700156");
        getProperty().setWard("200");
        Tax tax = new Tax();
        tax.setTaxAmt(15000.0);
        tax.setPaymentStatus("Paid");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());
        List l = new ArrayList();
        l.add(tax);
        getProperty().setPropertyTaxList(l);
    }

    public String payment() {
        System.out.println("within payment()");
        Map<String, Object> options = new HashMap<>();
        options.put("resizable", false);
        options.put("draggable", false);
        options.put("modal", true);
        options.put("height", "100");
        options.put("contentWidth", 500);
        options.put("contentHeight", 100);
        options.put("includeViewParams", true);
        List list = getProperty().getPropertyTaxList();
        Double amount = 0.0;
        for (int i = 0; i < list.size(); i++) {
            Tax tax = (Tax) list.get(i);
            if (tax.getPaymentStatus() != null && !tax.getPaymentStatus().equalsIgnoreCase("paid")) {
                amount = amount + tax.getTaxAmt();
            }
        }

        Map<String, List<String>> params = new HashMap<>();
        List<String> taxFor = new ArrayList<>();
        List<String> taxAmt = new ArrayList<>();
        taxFor.add("Property tax");
        taxAmt.add(amount.toString());
        params.put("taxfor", taxFor);
        params.put("taxAmt", taxAmt);
        RequestContext.getCurrentInstance().openDialog("payment", options, params);        
        return "tax";
    }

    public void populateWaterTaxList() {
        System.out.println("within populateWaterTaxList() ");
        System.out.println("updating water tax list");
        setWaterConnConsumerID("AA1234");
        Tax tax = new Tax();
        tax.setBillId("1AAA9H-12");
        tax.setConsumerNo("AA1234");
        tax.setConsumerName("Mr. A A XXXX");
        tax.setTaxAmt(1500.0);
        tax.setPaymentStatus("Paid");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());

        Tax tax1 = new Tax();
        tax1.setBillId("1AAA9H-20");
        tax1.setConsumerNo("AA1234");
        tax1.setConsumerName("Mr. A A XXXX");
        tax1.setTaxAmt(12000.0);
        tax1.setPaymentStatus("Due");
        tax1.setFine(0.0);
        tax1.setDueDt(new Date());
        tax1.setAssessEndDt(new Date());
        tax1.setAssessStartDt(new Date());

        List l = new ArrayList();
        l.add(tax);
        l.add(tax1);
        setWaterTaxList(l);

    }

    public String getTabSelected() {
        return tabSelected;
    }

    public void setTabSelected(String tabSelected) {
        this.tabSelected = tabSelected;
    }

    public void onTabChange(TabChangeEvent event) {
        System.out.println("within onTabChange()");
        System.out.println("Active Tab: " + event.getTab().getTitle());
        if (event.getTab().getTitle() != null && event.getTab().getTitle().equalsIgnoreCase("Property Tax")) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.renderResponse();
        } else if (event.getTab().getTitle() != null && event.getTab().getTitle().equalsIgnoreCase("Water Tax")) {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            HttpSession session = request.getSession(false);
            if (session != null && session.getAttribute("tax") != null) {
                session.setAttribute("tax", 0.0);
            }
            populateWaterTaxList();
        } else if (event.getTab().getTitle() != null && event.getTab().getTitle().equalsIgnoreCase("Electricity Bill")) {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            HttpSession session = request.getSession(false);
            if (session != null && session.getAttribute("tax") != null) {
                session.setAttribute("tax", 0.0);
            }
            populateElectricTaxList();
        }
    }

    public List<Tax> getWaterTaxList() {
        return waterTaxList;
    }

    public void setWaterTaxList(List<Tax> waterTaxList) {
        this.waterTaxList = waterTaxList;
    }

    public String getWaterConnConsumerID() {
        return waterConnConsumerID;
    }

    public void setWaterConnConsumerID(String waterConnConsumerID) {
        this.waterConnConsumerID = waterConnConsumerID;
    }

    public String makePayment(String payTowards) {
        System.out.println("within makePayment()");
        String returnPage = "";
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession(false);
        Double tax = 0.0;
        if (session != null) {
            tax = (Double) (session.getAttribute("tax"));
            System.out.println("total tax " + tax);
        }
        
        Map<String, Object> options = new HashMap<>();
        options.put("resizable", false);
        options.put("draggable", false);
        options.put("modal", true);
        options.put("height", "100");
        options.put("contentWidth", 500);
        options.put("contentHeight", 100);
        options.put("includeViewParams", true);
        
        Map<String, List<String>> params = new HashMap<>();
        List<String> taxFor = new ArrayList<>();
        List<String> taxAmt = new ArrayList<>();
        if(payTowards.equalsIgnoreCase("water")){
            taxFor.add("Water consumption tax");
            returnPage = "tax";
        }else if(payTowards.equalsIgnoreCase("electricity")){
            taxFor.add("Electric bill");
            returnPage = "tax";
        }
        
        taxAmt.add(tax.toString());
        params.put("taxfor", taxFor);
        params.put("taxAmt", taxAmt);
        RequestContext.getCurrentInstance().openDialog("payment", options, params);
        return returnPage;
    }

    public Double getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(Double totalTax) {
        this.totalTax = totalTax;
    }

    public void addTaxToPay(Double amt) {
        System.out.println("within addTaxToPay");
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession(false);
        if (session != null) {
            synchronized (this) {
                Double totTaxAmt = 0.0;
                if (session.getAttribute("tax") == null) {
                    session.setAttribute("tax", amt);
                } else {
                    totTaxAmt = amt + (Double) session.getAttribute("tax");;
                    session.setAttribute("tax", totTaxAmt);
                }
            }
        }
    }

    public void populateElectricTaxList() {
        System.out.println("within populateElectricTaxList() ");
        System.out.println("updating water tax list");
        setElectricConnConsumerID("Elec - 1234");
        Tax tax = new Tax();
        tax.setBillId("E-3-2016-1234");
        tax.setConsumerNo("AA1234");
        tax.setConsumerName("Mr. A A XXXX");
        tax.setTaxAmt(3500.0);
        tax.setPaymentStatus("Due");
        tax.setFine(0.0);
        tax.setDueDt(new Date());
        tax.setAssessEndDt(new Date());
        tax.setAssessStartDt(new Date());

        Tax tax1 = new Tax();
        tax1.setBillId("E-4-2016-1234");
        tax1.setConsumerNo("AA1234");
        tax1.setConsumerName("Mr. A A XXXX");
        tax1.setTaxAmt(5000.0);
        tax1.setPaymentStatus("Due");
        tax1.setFine(0.0);
        tax1.setDueDt(new Date());
        tax1.setAssessEndDt(new Date());
        tax1.setAssessStartDt(new Date());

        List l = new ArrayList();
        l.add(tax);
        l.add(tax1);
        setElectricTaxList(l);
    }

    public List<Tax> getElectricTaxList() {
        return electricTaxList;
    }

    public void setElectricTaxList(List<Tax> electricTaxList) {
        this.electricTaxList = electricTaxList;
    }

    public String getElectricConnConsumerID() {
        return electricConnConsumerID;
    }

    public void setElectricConnConsumerID(String electricConnConsumerID) {
        this.electricConnConsumerID = electricConnConsumerID;
    }

}
