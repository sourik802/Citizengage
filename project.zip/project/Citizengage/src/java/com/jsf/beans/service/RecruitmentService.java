/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Recruitment;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import javax.faces.context.FacesContext;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author Sourik
 */
@Named(value = "recruitment")
@ApplicationScoped
public class RecruitmentService {

    private List<Recruitment> recruitList = new ArrayList<>();
    private StreamedContent file;

    /**
     * Creates a new instance of RecruitmentService
     */
    public RecruitmentService() {
    }

    @PostConstruct
    public void init() {
        Recruitment recruit1 = new Recruitment();
        recruit1.setCompany("ABC Co Pvt Ltd");
        recruit1.setVacancy("Graduates required");
        recruit1.setEligibility("3 years full time degree");
        recruit1.setDescription("all profile should have a id\n"
                + "on submit display application no/request no/ticket no on page\n"
                + "\n"
                + "\n"
                + "\n"
                + "\n"
                + "report on all services - automated\n"
                + "\n"
                + "group and community - individuals can form or follow groups and submit request on the above as groups\n"
                + "\n"
                + "request tracking, status\n"
                + "\n"
                + "chat facility\n"
                + "\n"
                + "search for a housing already registered and become a member\n"
                + "suggestion\n"
                + "pin no check while user registration if pin falls under smart city jurisdiction - master table tracking\n"
                + "benchmark data display - doctors/population, police/population, transport/population\n"
                + "register housing society - save green cover - no of trees and their age, solar power coverage, rain water harvesting");
        recruit1.setDtOfPublish(new Date());
        recruit1.setExperience("5-8 years");
        recruit1.setLastDt(new Date());
        recruit1.setNoOfVacancy(12);
        recruit1.setProcedure("Online");

        Recruitment recruit2 = new Recruitment();
        recruit2.setCompany("www.googly.com");
        recruit2.setVacancy("Engineers required");
        recruit2.setEligibility("B.Tech");
        recruit2.setDescription("required for project.............");
        recruit2.setDtOfPublish(new Date());
        recruit2.setExperience("2-3 years");
        recruit2.setLastDt(new Date());
        recruit2.setNoOfVacancy(6);
        recruit2.setProcedure("Writtem exam followed by Interview");
        String link = "www.google.com";
        recruit2.getLink().add(link);
        recruitList.add(recruit1);
        recruitList.add(recruit2);
        InputStream stream = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/WEB-INF/sample.pdf");
        file = new DefaultStreamedContent(stream, "application/pdf", "application_form.pdf");
    }

    public StreamedContent getFile() {
        return file;
    }

    public List<Recruitment> getRecruitList() {
        return recruitList;
    }

    public void setRecruitList(List<Recruitment> recruitList) {
        this.recruitList = recruitList;
    }

}
