/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class Legal {

    private String complainType;
    private String policeStn;
    private String summary;
    private String details;
    private List<UploadedFile> evidenceFile = new ArrayList<>();
    private UploadedFile file;
    private Double latitude;
    private Double longitude;
    private List<InputStream> is = new ArrayList<>();

    public String getComplainType() {
        return complainType;
    }

    public void setComplainType(String complainType) {
        this.complainType = complainType;
    }

    public String getPoliceStn() {
        return policeStn;
    }

    public void setPoliceStn(String policeStn) {
        this.policeStn = policeStn;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }

    public List<UploadedFile> getEvidenceFile() {
        return evidenceFile;
    }

    public void setEvidenceFile(List<UploadedFile> evidenceFile) {
        this.evidenceFile = evidenceFile;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public List<InputStream> getIs() {
        return is;
    }

    public void setIs(List<InputStream> is) {
        this.is = is;
    }

}
