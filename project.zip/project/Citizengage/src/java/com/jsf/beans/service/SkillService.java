/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Address;
import com.jsf.beans.model.Skill;
import com.jsf.beans.model.SkilledPerson;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;

/**
 *
 * @author Sourik
 */
@Named(value = "skill")
@SessionScoped
public class SkillService implements Serializable {

    private List<SkilledPerson> skillPersons = new ArrayList<>();
    private List<Skill> skills = new ArrayList<>();
    private Skill skill;
    private SkilledPerson person;
    private String latitude;
    private String longitude;
    private String srchLbrQuery;

    /**
     * Creates a new instance of SkillService
     */
    public SkillService() {
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    @PostConstruct
    public void init() {
        if (skills == null) {
            skills = new ArrayList<>();
        }

        if (skill == null) {
            skill = new Skill();
        }

        Skill s1 = new Skill();
        s1.setId(0);
        s1.setItemName("Cook");
        s1.setItemValue("Cook");
        Skill s2 = new Skill();
        s2.setId(1);
        s2.setItemName("Carpenter");
        s2.setItemValue("Carpenter");
        Skill s3 = new Skill();
        s3.setId(2);
        s3.setItemName("Electrician");
        s3.setItemValue("Electrician");
        Skill s4 = new Skill();
        s4.setId(3);
        s4.setItemName("Plumber");
        s4.setItemValue("Plumber");

        skills.clear();

        skills.add(s1);
        skills.add(s2);
        skills.add(s3);
        skills.add(s4);

        if(person == null){
            person = new SkilledPerson();
        }
    }

    public List<SkilledPerson> getSkillPersons() {
        return skillPersons;
    }

    public void setSkillPersons(List<SkilledPerson> skillPersons) {
        this.skillPersons = skillPersons;
    }

    public Skill getSkill() {
        return skill;
    }

    public void setSkill(Skill skill) {
        this.skill = skill;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public SkilledPerson getPerson() {
        return person;
    }

    public void setPerson(SkilledPerson person) {
        this.person = person;
    }

    public SkillService(Skill skill, SkilledPerson person, String latitude, String longitude) {
        this.skill = skill;
        this.person = person;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public void clearSkilledPersonList() {
        if (getSkillPersons() != null) {
            getSkillPersons().clear();
        }
    }

    public void searchSkill() {
        System.out.println("within searchSkill()");
        System.out.println("latitude " + getLatitude());
        System.out.println("latitude " + getLongitude());
        System.out.println("skill " + getSkill().getItemName() + " " + getSkill().getId() + " " + getSkill().getItemValue());
        clearSkilledPersonList();

        Address a = new Address();
        a.setHouseNo("1");
        a.setBuilding("BBBB");
        a.setStreetNo("12");
        a.setCity("Kolkata");
        a.setPin("700001");
        a.setState("WB");

        SkilledPerson sp1 = new SkilledPerson();
        sp1.setId(0);
        sp1.setName("AAAA");
        sp1.setPhone("11111");
        sp1.setAddress(a);
        sp1.setRate(4);
        sp1.setSkillType("Cook");

        SkilledPerson sp2 = new SkilledPerson();
        sp2.setId(1);
        sp2.setName("SVFBXF");
        sp2.setPhone("2222");
        sp2.setAddress(a);
        sp2.setRate(3);
        sp2.setSkillType("Carpenter");

        SkilledPerson sp3 = new SkilledPerson();
        sp3.setId(2);
        sp3.setName("qqqq");
        sp3.setPhone("55555");
        sp3.setAddress(a);
        sp3.setRate(5);
        sp3.setSkillType("Electrician");

        SkilledPerson sp4 = new SkilledPerson();
        sp4.setId(3);
        sp4.setName("ABCDE");
        sp4.setPhone("66666");
        sp4.setAddress(a);
        sp4.setRate(null);
        sp4.setSkillType("Plumber");

        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("cook")) {
            getSkillPersons().add(sp1);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Carpenter")) {
            getSkillPersons().add(sp2);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Electrician")) {
            getSkillPersons().add(sp3);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Plumber")) {
            getSkillPersons().add(sp4);
        }
    }

    public void loadIdentityDoc(SkilledPerson p) throws FileNotFoundException, IOException {
        System.out.println("within loadIdentityDoc() " + p);
        System.out.println("object " + p.getId() + "  " + p.getName());
    }

    //Facility
    public List<Skill> completeSkill(String query) {
        List<Skill> allSkills = getSkills();
        List<Skill> filteredSkills = new ArrayList<>();

        if (allSkills != null && !allSkills.isEmpty()) {
            Skill skill = null;
            for (int i = 0; i < allSkills.size(); i++) {
                skill = allSkills.get(i);
                if (skill.getItemName().toLowerCase().contains(query)) {
                    filteredSkills.add(skill);
                }
            }
        }
        return filteredSkills;
    }

    public void searchSkillService() {
        System.out.println("within searchSkillService()");
        System.out.println("search query " + getSkill());
        List<Skill> allSkills = getSkills();
        if (allSkills != null && !allSkills.isEmpty() && getSkill() != null) {
            Skill skill = null;
            for (int i = 0; i < allSkills.size(); i++) {
                skill = allSkills.get(i);
                if (skill.getItemName().toLowerCase().equals(getSkill().getItemName())) {
                    if (skills != null) {
                        skills.clear();
                    }
                    skills.add(skill);
                }
            }
        }
    }

    public void resetSkillService() {
        System.out.println("within resetSkillService()");
        if (skills != null) {
            skills.clear();
        }
        Address a = new Address();
        a.setHouseNo("1");
        a.setBuilding("BBBB");
        a.setStreetNo("12");
        a.setCity("Kolkata");
        a.setPin("700001");
        a.setState("WB");

        SkilledPerson sp1 = new SkilledPerson();
        sp1.setId(0);
        sp1.setName("AAAA");
        sp1.setPhone("11111");
        sp1.setAddress(a);
        sp1.setRate(4);
        sp1.setSkillType("Cook");

        SkilledPerson sp2 = new SkilledPerson();
        sp2.setId(1);
        sp2.setName("SVFBXF");
        sp2.setPhone("2222");
        sp2.setAddress(a);
        sp2.setRate(3);
        sp2.setSkillType("Carpenter");

        SkilledPerson sp3 = new SkilledPerson();
        sp3.setId(2);
        sp3.setName("qqqq");
        sp3.setPhone("55555");
        sp3.setAddress(a);
        sp3.setRate(5);
        sp3.setSkillType("Electrician");

        SkilledPerson sp4 = new SkilledPerson();
        sp4.setId(3);
        sp4.setName("ABCDE");
        sp4.setPhone("66666");
        sp4.setAddress(a);
        sp4.setRate(null);
        sp4.setSkillType("Plumber");

        if (getSkillPersons() != null) {
            getSkillPersons().clear();
        }
        
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("cook")) {
            getSkillPersons().add(sp1);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Carpenter")) {
            getSkillPersons().add(sp2);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Electrician")) {
            getSkillPersons().add(sp3);
        }
        if (getSkill().getItemName() != null && getSkill().getItemName().equalsIgnoreCase("Plumber")) {
            getSkillPersons().add(sp4);
        }
    }

    public String getSrchLbrQuery() {
        return srchLbrQuery;
    }

    public void setSrchLbrQuery(String srchLbrQuery) {
        this.srchLbrQuery = srchLbrQuery;
    }
    
    public void searchLabour(ActionEvent event){
        System.out.println("within searchLabour() for "+getSrchLbrQuery());
    }
    
    public void addLabour(){
        System.out.println("within addLabour() ");
    }
    
    public void removeLabour(){
        System.out.println("within removeLabour() ");
    }
    
    public void saveLabour(){
        System.out.println("within saveLabour() ");
    }
}
