/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class OnlineApplication {

    private String applicationId;
    private String applicantName;
    private Address address;
    private UploadedFile govIdentityFile;
    private UploadedFile photo;

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public UploadedFile getGovIdentityFile() {
        return govIdentityFile;
    }

    public void setGovIdentityFile(UploadedFile govIdentityFile) {
        this.govIdentityFile = govIdentityFile;
    }

    public UploadedFile getPhoto() {
        return photo;
    }

    public void setPhoto(UploadedFile photo) {
        this.photo = photo;
    }

}
