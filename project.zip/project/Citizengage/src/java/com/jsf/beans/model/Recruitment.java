/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author 258290
 */
public class Recruitment {

    private String vacancy;
    private Date dtOfPublish;
    private Integer noOfVacancy;
    private String experience;
    private String company;
    private Date lastDt;
    private String procedure;
    private String eligibility;
    private String description;
    private List link = new ArrayList();

    public String getVacancy() {
        return vacancy;
    }

    public void setVacancy(String vacancy) {
        this.vacancy = vacancy;
    }

    public Date getDtOfPublish() {
        return dtOfPublish;
    }

    public void setDtOfPublish(Date dtOfPublish) {
        this.dtOfPublish = dtOfPublish;
    }

    public Integer getNoOfVacancy() {
        return noOfVacancy;
    }

    public void setNoOfVacancy(Integer noOfVacancy) {
        this.noOfVacancy = noOfVacancy;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public Date getLastDt() {
        return lastDt;
    }

    public void setLastDt(Date lastDt) {
        this.lastDt = lastDt;
    }

    public String getProcedure() {
        return procedure;
    }

    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public String getEligibility() {
        return eligibility;
    }

    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List getLink() {
        return link;
    }

    public void setLink(List link) {
        this.link = link;
    }

}
