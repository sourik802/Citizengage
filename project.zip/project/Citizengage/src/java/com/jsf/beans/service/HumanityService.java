/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.Humanity;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Sourik
 */
@Named(value = "humanity")
@SessionScoped
public class HumanityService implements Serializable {
    
    private List<Humanity> fieldSet = new ArrayList();
    /**
     * Creates a new instance of HumanityService
     */
    public HumanityService() {
    }

    @PostConstruct
    public void init(){
        Humanity h1 = new Humanity();
        h1.setHid("h1");
        h1.setLegend("Blood Donation Camp");
        h1.setLocation("EZZ Park, New Town");
        h1.setDetails("Blood donation camp has been organized");
        
        Humanity h2 = new Humanity();
        h2.setHid("h2");
        h2.setLegend("Study Material Collectionn Drive");
        h2.setLocation("AABBCC School, Central");
        h2.setDetails("People are requested to come up with study materials for needy students. Materials can include books, boxes, copies");
        
        Humanity h3 = new Humanity();
        h3.setHid("h3");
        h3.setLegend("Dog Show");
        h3.setLocation("EZZ Park, New Town");
        h3.setDetails("Pet owners are requested to come with their pets and show off their best friends");
        
        fieldSet.add(h1);
        fieldSet.add(h2);
        fieldSet.add(h3);
    }
            
    public void volunteer(Humanity h){
        System.out.println("within volunteer for "+h.getHid());
        FacesContext context = FacesContext.getCurrentInstance();         
        context.addMessage(null, new FacesMessage("You have successfuly registered for "+h.getLegend(),  "") );

    }

    public List<Humanity> getFieldSet() {
        return fieldSet;
    }

    public void setFieldSet(List<Humanity> fieldSet) {
        this.fieldSet = fieldSet;
    }

    
    
    
}
