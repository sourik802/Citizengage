/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.ejb.LoadKeyValues;
import com.citizengage.entity.Address;
import com.citizengage.utility.DistanceUtility;
import com.jsf.beans.model.Doctor;
import com.jsf.beans.model.Hospital;
import com.jsf.beans.model.MedicalDonation;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;

/**
 *
 * @author 258290
 */
@Named(value = "medical")
@SessionScoped
public class MedicalService implements Serializable {
    
    @EJB
    private DataServicesHelper dataServices;
    
    @EJB
    private LoadKeyValues keyValues;
    
    private UIInput prescrpFile;

    /**
     * Creates a new instance of MedicalService
     */
    public MedicalService() {
    }

    //Doctor tab : Start
    private Doctor doc;
    private String specialityQuery;
    private List<Doctor> docList;
    private Date bookingDate;
    private final Date currentDate = new Date();
    private List<String> specialities = new ArrayList<>();
    private Map<String, String> donateItems = new HashMap<>();
    
    @PostConstruct
    public void init() {
        specialities = keyValues.getDocSpecialityList();
    }
    
    public Doctor getDoc() {
        return doc;
    }
    
    public void setDoc(Doctor doc) {
        this.doc = doc;
    }
    
    public Map<String, String> getDonateItems() {
        return donateItems;
    }
    
    public List<Doctor> getDocList() {
        return docList;
    }
    
    public void setDocList(List<Doctor> docList) {
        this.docList = docList;
    }
    
    public String getSpecialityQuery() {
        return specialityQuery;
    }
    
    public void setSpecialityQuery(String specialityQuery) {
        this.specialityQuery = specialityQuery;
    }
    
    public List<String> getSpecialities() {
        return specialities;
    }
    
    public List<String> completeSpeciality(String query) {
        return specialities;
    }
    
    public List<Doctor> populatedoc() {
        System.out.println("within populatedoc() " + getSpecialityQuery());
        List<com.citizengage.entity.Doctor> docs = dataServices.fetchDoctors(getSpecialityQuery());
        
        if (docList == null) {
            docList = new ArrayList<>();
        }
        docList.clear();
        setBookingDate(null);
        if (docs != null && docs.size() > 0) {
            DistanceUtility dist = new DistanceUtility();
            docs.stream().forEach((d) -> {
                com.citizengage.entity.Doctor value = (com.citizengage.entity.Doctor) d;
                Doctor doc = new Doctor();
                doc.setName(d.getDocname());
                doc.setQualification(d.getQualification());
                doc.setRegistration(d.getRegistration());
                doc.setSpecialization(d.getSpecialization());
                doc.setTimings(d.getTimings());
                com.citizengage.entity.Address addr = d.getAddrId();
                
                com.jsf.beans.model.Address address = new com.jsf.beans.model.Address();
                address.setHouseNo(addr.getHouseNo()+", ");
                address.setStreetNo(addr.getStreetNo()+", ");
                address.setStreetName(addr.getStreetName()+", ");
                address.setBuilding(addr.getBuilding()+", ");
                address.setCity(addr.getCity()+", ");
                address.setPin(addr.getPin()+", ");
                doc.setAddress(address);
                doc.setExperience(d.getExperience().doubleValue());
                doc.setHospitalAssoc(d.getAssochospital());
                doc.setPhone(d.getPhone());
                doc.setDistance(dist.getDistance("700156", Integer.toString(addr.getPin())));
                docList.add(doc);
            });
        }
        return docList;
    }
    
    public void bookDoc(Doctor d, Date date) {
        FacesMessage message = null;
        if (date == null) {
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "", "Please select appointment date and time for " + d.getName());
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        } else {
            System.out.println("Doctor selected " + d.getName() + " " + date);
            this.doc = d;
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "", "You have taken appointment for " + d.getName() + " on " + date);
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        }
    }
    
    public Date getBookingDate() {
        return bookingDate;
    }
    
    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }
    
    public Date getCurrentDate() {
        return currentDate;
    }
    
    public void onDateSelect(SelectEvent event) {
        //System.out.println("booking done on "+date);
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        System.out.println("Date Selected " + format.format(event.getObject()));
        setBookingDate((Date) event.getObject());
    }
    //Doctor tab : End

    //Hospital tab : Start
    private Hospital hosp;
    private List<Hospital> hospList = new ArrayList<>();
    
    public void onTabChange(TabChangeEvent event) {
        System.out.println("within onTabChange()");
        System.out.println("Active Tab: " + event.getTab().getTitle());
        if (event.getTab().getTitle() != null && event.getTab().getTitle().equalsIgnoreCase("Hospitals & Clinics")) {
            clearHospList();
            populateHospitals();
            setBookingDate(null);
        } else if (event.getTab().getTitle() != null && event.getTab().getTitle().equalsIgnoreCase("Place Blood or Organ request")) {
            populateDonationItems();
        } else {
            
        }
    }
    
    public Hospital getHosp() {
        return hosp;
    }
    
    public void setHosp(Hospital hosp) {
        this.hosp = hosp;
    }
    
    public List<Hospital> getHospList() {
        return hospList;
    }
    
    public void setHospList(List<Hospital> hospList) {
        this.hospList = hospList;
    }
    
    public void addHospital(Hospital h) {
        if (getHospList() == null) {
            setHospList(new ArrayList<>());
        }
        boolean add = getHospList().add(h);
    }
    
    public void clearHospList() {
        if (getHospList() != null) {
            getHospList().clear();
        }
    }
    
    public void populateHospitals() {
        Hospital h1 = new Hospital();
        h1.setName("Apollo");
        h1.setAddress("Bypass");
        h1.setAmbulanceAvailable("Yes");
        h1.setEmergencyAvailable("Yes");
        h1.setTimings("10 AM - 9 PM");
        h1.setType("Private");
        h1.setPhone("1111111");
        Map<String, List> m1 = new HashMap();
        List<String> l1 = new ArrayList();
        l1.add("Dr. A B, MBBS");
        l1.add("Dr. DAAA, MD in ABCS");
        m1.put("ENT", l1);
        h1.setSpecialisation(m1);
        Doctor d1 = new Doctor();
        Doctor d2 = new Doctor();
        d1.setName("Dr. XXXD");
        d1.setRegistration("99999");
        d1.setExperience(20.0);
        d1.setQualification("MBBS");
        d1.setSpecialization("Cardio");
        d2.setName("Dr. PPPPP");
        d2.setRegistration("2222");
        d1.setExperience(23.0);
        d1.setQualification("MD");
        d1.setSpecialization("General Physician");
        
        if (h1.getHospDocList() == null) {
            h1.setHospDocList(new ArrayList<>());
        }
        h1.getHospDocList().clear();
        h1.getHospDocList().add(d1);
        h1.getHospDocList().add(d2);
        
        Hospital h2 = new Hospital();
        h2.setName("AMRI");
        h2.setAddress("Gariahat");
        h2.setAmbulanceAvailable("Yes");
        h2.setEmergencyAvailable("Yes");
        h2.setTimings("9 AM - 9 PM");
        h2.setType("Private");
        h2.setPhone("1111111");
        Map<String, List> m2 = new HashMap();
        List<String> l2 = new ArrayList();
        l2.add("Dr. A B, MBBS");
        l2.add("Dr. DAAA, MD in ABCS");
        m2.put("ENT", l1);
        h2.setSpecialisation(m2);
        Doctor d21 = new Doctor();
        Doctor d22 = new Doctor();
        d21.setName("Dr. XXXD");
        d21.setRegistration("99999");
        d21.setExperience(20.0);
        d21.setQualification("MBBS");
        d21.setSpecialization("Cardio");
        d22.setName("Dr. PPPPP");
        d22.setRegistration("2222");
        d22.setExperience(23.0);
        d22.setQualification("MD");
        d22.setSpecialization("General Physician");
        
        if (h2.getHospDocList() == null) {
            h2.setHospDocList(new ArrayList<>());
        }
        h2.getHospDocList().clear();
        h2.getHospDocList().add(d21);
        h2.getHospDocList().add(d22);
        
        
        
        Hospital h3 = new Hospital();
        h3.setName("Medico");
        h3.setAddress("Salt Lake");
        h3.setAmbulanceAvailable("No");
        h3.setEmergencyAvailable("Yes");
        h3.setTimings("10 AM - 8 PM");
        h3.setType("Private");
        h3.setPhone("1111111");
        Map<String, List> m3 = new HashMap();
        List<String> l3 = new ArrayList();
        l3.add("Dr. A B, MBBS");
        l3.add("Dr. DAAA, MD in ABCS");
        m3.put("ENT", l1);
        h3.setSpecialisation(m3);
        Doctor d31 = new Doctor();
        Doctor d32 = new Doctor();
        d31.setName("Dr. XXXD");
        d31.setRegistration("99999");
        d31.setExperience(20.0);
        d31.setQualification("MBBS");
        d31.setSpecialization("Cardio");
        d32.setName("Dr. PPPPP");
        d32.setRegistration("2222");
        d32.setExperience(23.0);
        d32.setQualification("MD");
        d32.setSpecialization("General Physician");
        
        if (h3.getHospDocList() == null) {
            h3.setHospDocList(new ArrayList<>());
        }
        h3.getHospDocList().clear();
        h3.getHospDocList().add(d31);
        h3.getHospDocList().add(d32);
        
        
        
        Hospital h4 = new Hospital();
        h4.setName("Beliaghata ESI");
        h4.setAddress("B M Road");
        h4.setAmbulanceAvailable("Yes");
        h4.setEmergencyAvailable("No");
        h4.setTimings("10 AM - 6 PM");
        h4.setType("Gov ESI");
        h4.setPhone("1111111");
        
        addHospital(h1);
        addHospital(h2);
        addHospital(h3);
        addHospital(h4);
    }
    
    public void showHospDocs(Hospital h) {
        
        System.out.println("within showHospDocs() " + h.getName());
        
        System.out.println(h.getHospDocList());
        System.out.println(h.getMyHashMapEntryList());
        this.hosp = h;
    }
    
    public void bookDocApointment(Doctor d, Date date) {
        System.out.println("within bookDocApointment() " + date);
        FacesMessage message;
        if (date == null) {
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "", "Please select appointment date and time for " + d.getName());
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        } else {
            System.out.println("Doctor selected " + d.getName() + " " + date);
            this.doc = d;
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "", "You have taken appointment for " + d.getName() + " on " + date);
            RequestContext.getCurrentInstance().showMessageInDialog(message);
        }
    }

    //Hospital tab : End
    //Donation tab: Start
    private MedicalDonation donation;
    
    public MedicalDonation getDonation() {
        return donation;
    }
    
    public void setDonation(MedicalDonation donation) {
        this.donation = donation;
    }
    
    public void populateDonationItems() {
        SelectItemGroup blood = new SelectItemGroup("Blood");
        blood.setSelectItems(new SelectItem[]{new SelectItem("Blood", "Blood")});
        
        SelectItemGroup organ = new SelectItemGroup("Organ");
        organ.setSelectItems(new SelectItem[]{new SelectItem("Kidney", "Kidney"), new SelectItem("Liver", "Liver")});
        if (getDonation() == null) {
            setDonation(new MedicalDonation());
        }
        if (getDonation().getItems() != null) {
            getDonateItems().clear();
            getDonation().getItems().add(blood);
            getDonation().getItems().add(organ);
        }
    }
    
    public void submitMedicalReq() {
        System.out.println("within submitMedicalReq()");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage("medreqmsg", new FacesMessage("", "Your request is submitted"));
    }
    //Donation tab: End

    public UIInput getPrescrpFile() {
        return prescrpFile;
    }
    
    public void setPrescrpFile(UIInput prescrpFile) {
        this.prescrpFile = prescrpFile;
    }
    
}
