/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.entity.Citycomplaints;
import com.jsf.beans.model.Complain;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Sourik
 */
@Named(value = "complain")
@SessionScoped
public class ComplainsService implements Serializable {

    @EJB
    private DataServicesHelper dataServices;

    private Complain complain;

    /**
     * Creates a new instance of ComplainsService
     */
    public ComplainsService() {
    }

    public Complain getComplain() {
        return complain;
    }

    public void setComplain(Complain complain) {
        this.complain = complain;
    }

    @PostConstruct
    public void init() {

        List complainList = dataServices.fetchCityComplaints();

        if (getComplain() == null) {
            setComplain(new Complain());
        }

        if (getComplain().getCategories() == null) {
            getComplain().setCategories(new ArrayList<>());
        }

        if (complainList != null && complainList.size() > 0) {

            Map<String, List<String>> map = new HashMap<>();

            for (Object o : complainList) {
                Citycomplaints cc = (Citycomplaints) o;
                if (!map.containsKey(cc.getCategory())) {
                    List<String> list = new ArrayList<>();
                    map.put(cc.getCategory(), list);
                    list.add(cc.getComplainID() + ":" + cc.getSubCategory());
                } else {
                    List list = map.get(cc.getCategory());
                    list.add(cc.getComplainID() + ":" + cc.getSubCategory());
                }
            }

            Iterator<Map.Entry<String, List<String>>> entries = map.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, List<String>> entry = entries.next();
                System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
                SelectItemGroup group = new SelectItemGroup(entry.getKey());

                ListIterator<String> itr = entry.getValue().listIterator();
                int i = 0;
                SelectItem[] items = new SelectItem[entry.getValue().size()];
                while (itr.hasNext()) {
                    String s = itr.next();
                    System.out.println("iterator value " + s);
                    String[] arr = s.split(":");
                    SelectItem option = new SelectItem(arr[0], arr[1]);
                    System.out.println("options created[" + i + "] " + option);
                    items[i] = option;
                    group.setSelectItems(items);
                    i++;
                }
                getComplain().getCategories().add(group);
            }
        }
    }

    public void submitComplain() {
        System.out.println("within submitComplain() " + getComplain().getSelection());
        RequestContext context = RequestContext.getCurrentInstance();
        context.update("complainform:complainpanel");
        context.scrollTo("complainform:complainpanel");
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Your complain has been successfully submitted, you will get notification on the progress", "Successfully registered  "));
    }
}
