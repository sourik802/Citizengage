/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

/**
 *
 * @author Sourik
 */
public class Skill {

    private int id;
    private String itemValue;
    private String itemName;
    
    /**
     * Creates a new instance of SkillBean
     */
    public Skill() {
    }

    public Skill(int id, String displayName, String name) {
        this.id = id;
        this.itemValue = name;
        this.itemName = displayName;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemValue() {
        return itemValue;
    }

    public void setItemValue(String itemValue) {
        this.itemValue = itemValue;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    
}
