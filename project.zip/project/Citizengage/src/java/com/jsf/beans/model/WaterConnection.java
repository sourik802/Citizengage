/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class WaterConnection extends OnlineApplication{
    
    private String ward;
    private boolean tenant;
    private String ownerName;
    private Address ownerAddress; //to be checked on save as parent class has Address also
    private String connType;
    private Integer waterSize;
    private Integer sewerageSize;
    private String identityNo;
    private UploadedFile allotmentLtr;
    private UploadedFile saleDeed;

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public boolean isTenant() {
        return tenant;
    }

    public void setTenant(boolean tenant) {
        this.tenant = tenant;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public Address getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(Address ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public String getConnType() {
        return connType;
    }

    public void setConnType(String connType) {
        this.connType = connType;
    }

    public Integer getWaterSize() {
        return waterSize;
    }

    public void setWaterSize(Integer waterSize) {
        this.waterSize = waterSize;
    }

    public Integer getSewerageSize() {
        return sewerageSize;
    }

    public void setSewerageSize(Integer sewerageSize) {
        this.sewerageSize = sewerageSize;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public UploadedFile getAllotmentLtr() {
        return allotmentLtr;
    }

    public void setAllotmentLtr(UploadedFile allotmentLtr) {
        this.allotmentLtr = allotmentLtr;
    }

    public UploadedFile getSaleDeed() {
        return saleDeed;
    }

    public void setSaleDeed(UploadedFile saleDeed) {
        this.saleDeed = saleDeed;
    }
    
    
}
