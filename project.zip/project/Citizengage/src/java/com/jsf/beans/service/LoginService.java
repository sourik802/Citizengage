/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.ejb.LoadKeyValues;
import com.citizengage.entity.Userinfo;
import com.citizengage.exception.CitizengageException;
import com.jsf.beans.model.Address;
import com.jsf.beans.model.UserData;
import java.io.IOException;
import java.io.InputStream;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.FlowEvent;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author Sourik
 */
@Named(value = "login")
@SessionScoped
public class LoginService implements Serializable {

    @EJB
    private DataServicesHelper dataServices;

    @EJB
    private LoadKeyValues keyValues;

    private UserData user;
    private String loginVerbiage;
    private String userName;
    private String password;
    private Integer generatedId;

    Map<String, String> docTyps = new HashMap();
    Map<String, String> genders = new HashMap();

    /**
     * Creates a new instance of LoginService
     */
    public LoginService() {
    }

    @PostConstruct
    public void init() {
        if (user == null) {
            user = new UserData();
        }
        if (getUser().getAddress() == null) {
            getUser().setAddress(new Address());
        }
        setLoginVerbiage("Login");

        genders = keyValues.getGender();
        docTyps = keyValues.getRegistrationDocNames();

    }

    public Map<String, String> getGenders() {
        return genders;
    }

    public void setGenders(Map<String, String> genders) {
        this.genders = genders;
    }

    public Map<String, String> getDocTyps() {
        return docTyps;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserData getUser() {
        return user;
    }

    public void setUser(UserData user) {
        this.user = user;
    }

    public String onFlowProcess(FlowEvent event) {
        return event.getNewStep();
    }

    public void register() {
        try {
            System.out.println("within register " + getUser().getFirstname());
            Integer id = dataServices.persistUser(getUser());
            if (id != null && !id.equals(0)) {
                setGeneratedId(id);
                RequestContext context = RequestContext.getCurrentInstance();
                context.update("userform:panel");
                context.scrollTo("userform:panel");
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Successfully registered, your generated id is " + id, "Successfully registered  " + id));
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Registration failed, please try again"));
            }
        } catch (CitizengageException cex) {
            System.err.println("Error " + cex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Registration failed due to " + cex.getMessage() + ", please try again"));
        } catch (Exception ex) {
            Logger.getLogger(LoginService.class.getName()).log(Level.SEVERE, null, ex);
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Registration not done ", "Error is " + ex.getMessage()));
        }
    }

    public String getLoginVerbiage() {
        return loginVerbiage;
    }

    public void setLoginVerbiage(String loginVerbiage) {
        this.loginVerbiage = loginVerbiage;
    }

    public String login() {
        System.out.println("within login() " + getUserName());
        if (getLoginVerbiage().equals("Login")) {
            //Userinfo user = dataServices.getLoggedin(getUserName(), getPassword());
//            if (true) {
//                RequestContext context = RequestContext.getCurrentInstance();
//                context.update("loginform:homepanel");
//                context.scrollTo("loginform:homepanel");
//                FacesContext.getCurrentInstance().addMessage("messages", new FacesMessage("Wrong credentials", ""));
//            } else {
//                HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
//                if (session != null) {
//                    session.setAttribute("user", user);
//                    setLoginVerbiage("Logout");
//                } else {
//                    System.out.println("Failed to login");
//                }
//            }

            if (getLoginVerbiage().equals("Login")) {
                HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
                if (session != null) {
                    session.setAttribute("user", getUserName());
                    setLoginVerbiage("Logout");
                } else {
                    System.out.println("Failed to login");
                }
            }
        }
        return "/common/home.xhtml";
    }

    public String doLogin() {
        System.out.println("within doLogin() " + getLoginVerbiage());
        if (getLoginVerbiage().equals("Login")) {
            RequestContext.getCurrentInstance().execute("PF('loginDlg').show()");
            System.out.println("here to login");
            return "";
        } else if (getLoginVerbiage().equals("Logout")) {
            System.out.println("logging out");
            HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
            if (session != null) {
                session.removeAttribute("user");
                session.invalidate();
                System.out.println("invalidating session");
            }
            setLoginVerbiage("Login");
            return "/common/home.xhtml";
        }
        return "";
    }

    public String loginForward() {
        System.out.println("within loginForward()");
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        if (session != null) {
            session.setAttribute("user", getUserName());
            setLoginVerbiage("Logout");
        } else {
            System.out.println("Failed to login");
        }
        return "home.xhtml";
    }

    public void processValidations(UIInput input) {
        FacesContext context = FacesContext.getCurrentInstance();

//        if (input != null) {
//            input.setValid(false);
//            context.addMessage(input.getClientId(context), new FacesMessage(FacesMessage.SEVERITY_ERROR, "file not uploaded", "no file"));
//            context.validationFailed();
//        }
    }

    private UIInput picFile;
    private UIInput idFile;

    public UIInput getPicFile() {
        return picFile;
    }

    public void setPicFile(UIInput picFile) {
        this.picFile = picFile;
    }

    public UIInput getIdFile() {
        return idFile;
    }

    public void setIdFile(UIInput idFile) {
        this.idFile = idFile;
    }

    public void handleFileUpload(FileUploadEvent event) throws IOException {
        System.out.println("file uploading " + event.getFile().getFileName() + " is uploaded of size " + event.getFile().getSize());
        InputStream is = event.getFile().getInputstream();
        getUser().setIs1(is);
    }

    public void handleFileUpload1(FileUploadEvent event) throws IOException {
        System.out.println("file uploading " + event.getFile().getFileName() + " is uploaded " + event.getFile().getSize());
        InputStream is = event.getFile().getInputstream();
        getUser().setIs2(is);
    }

    public void onDobSelect(SelectEvent event) {
        System.out.println("within onDobSelect() " + event + " ..... " + getUser().getFirstname());
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        format.format(event.getObject());
        Date d = new Date(format.format(event.getObject()));
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        int byear = cal.get(Calendar.YEAR);
        int bmonth = cal.get(Calendar.MONTH);
        int bday = cal.get(Calendar.DATE);
        LocalDateTime now = LocalDateTime.now();
        int year = now.getYear();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();
        LocalDate start = LocalDate.of(byear, bmonth, bday);
        LocalDate end = LocalDate.of(year, month, day); // use for age-calculation: LocalDate.now()
        long years = ChronoUnit.YEARS.between(start, end);
        System.out.println("Age " + years);
        getUser().setAge(years);
    }

    public Integer getGeneratedId() {
        return generatedId;
    }

    public void setGeneratedId(Integer generatedId) {
        this.generatedId = generatedId;
    }

}
