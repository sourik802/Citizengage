/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Sourik
 */
public class ClubMembership implements Serializable {

    private String membership[];
    private Date startDate;
    private String memberOf;
    private String membershipCode;
    private boolean selectedMembership;
    private boolean membershipSelected;
    private Date validUpto;

    public String[] getMembership() {
        return membership;
    }

    public void setMembership(String[] membership) {
        this.membership = membership;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getMemberOf() {
        return memberOf;
    }

    public void setMemberOf(String memberOf) {
        this.memberOf = memberOf;
    }

    public String getMembershipCode() {
        return membershipCode;
    }

    public void setMembershipCode(String membershipCode) {
        this.membershipCode = membershipCode;
    }

    public boolean isSelectedMembership() {
        return selectedMembership;
    }

    public void setMembershipSelected(boolean membershipSelected) {
        this.membershipSelected = membershipSelected;
    }

    public boolean isMembershipSelected() {
        return membershipSelected;
    }

    public Date getValidUpto() {
        return validUpto;
    }

    public void setValidUpto(Date validUpto) {
        this.validUpto = validUpto;
    }

}
