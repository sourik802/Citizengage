/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.io.InputStream;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author Sourik
 */
public class UserData {

    private String userId;
    private String firstname;
    private String lastname;
    private String password;
    private String gender;
    private Date dob;
    private long age;
    private String homePhone;
    private Integer mobile;
    private String email;
    private String identityDocType;
    private String identityNo;
    private Address address;
    private UploadedFile identityFile;
    private UploadedFile photo;
    private boolean snCtznDistress;
    private Date currentDate;
    private Date minDate;
    private InputStream is1;
    private InputStream is2;
    

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public long getAge() {
        return age;
    }

    public void setAge(long age) {
        this.age = age;
    }

    public Integer getMobile() {
        return mobile;
    }

    public void setMobile(Integer mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public UploadedFile getPhoto() {
        return photo;
    }

    public void setPhoto(UploadedFile photo) {
        this.photo = photo;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public String getIdentityDocType() {
        return identityDocType;
    }

    public void setIdentityDocType(String identityDocType) {
        this.identityDocType = identityDocType;
    }

    public UploadedFile getIdentityFile() {
        return identityFile;
    }

    public void setIdentityFile(UploadedFile identityFile) {
        this.identityFile = identityFile;
    }

    public boolean isSnCtznDistress() {
        return snCtznDistress;
    }

    public void setSnCtznDistress(boolean snCtznDistress) {
        this.snCtznDistress = snCtznDistress;
    }

    public Date getCurrentDate() {
        return new Date();
    }

    public void setMinDate() {
        Calendar cal = Calendar.getInstance();
        
        cal.add(Calendar.YEAR, -80);
        Date dateBefore80years = cal.getTime();
        this.minDate = dateBefore80years;
    }

    public Date getMinDate() {
        return minDate;
    }

    public String getYearRange(){
        String currentYear = Integer.toString(Year.now().getValue());
        String startYear = Integer.toString(Year.now().getValue() - 100);
        return startYear+":"+currentYear;
    }

    public InputStream getIs1() {
        return is1;
    }

    public void setIs1(InputStream is1) {
        this.is1 = is1;
    }

    public InputStream getIs2() {
        return is2;
    }

    public void setIs2(InputStream is2) {
        this.is2 = is2;
    }

}
