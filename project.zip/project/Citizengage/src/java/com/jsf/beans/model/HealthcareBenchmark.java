/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.BarChartModel;
import org.primefaces.model.chart.ChartSeries;

/**
 *
 * @author Sourik
 */
public class HealthcareBenchmark {

    private BarChartModel healthCareModel;

    private BarChartModel initBarModel() {
        BarChartModel model = new BarChartModel();

        ChartSeries city = new ChartSeries();
        city.setLabel("Your city");
        city.set("No of Hospitals", 6);
        city.set("No of Doctors", 32);
        city.set("Beds in hospital", 20);

        ChartSeries who = new ChartSeries();
        who.setLabel("WHO Standard");
        who.set("No of Hospitals", 5);
        who.set("No of Doctors", 35);
        who.set("Beds in hospital", 38);

        model.addSeries(city);
        model.addSeries(who);

        return model;
    }

    public BarChartModel getHealthCareModel() {
        return healthCareModel;
    }

    public void setHealthCareModel(BarChartModel healthCareModel) {
        this.healthCareModel = healthCareModel;
    }

    public void createBarModel() {
        healthCareModel = initBarModel();

        healthCareModel.setTitle("Healthcare");
        healthCareModel.setLegendPosition("ne");

        Axis xAxis = healthCareModel.getAxis(AxisType.X);
        xAxis.setLabel("Hospital Data");

        Axis yAxis = healthCareModel.getAxis(AxisType.Y);
        yAxis.setLabel("Per 1000 of population");
        yAxis.setMin(0);
        yAxis.setMax(50);
    }

}
