/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 258290
 */
public class Hospital {

    private String hospId;
    private String name;
    private String address;
    private String type;
    private String ambulanceAvailable;
    private String emergencyAvailable;
    private String timings;
    private String phone;
    private String specialities;
    private Map<String, List> specialisation = new HashMap();
    private List<Doctor> hospDocList = new ArrayList<>();

    /**
     * Creates a new instance of Hospital
     */
    public Hospital() {
    }

    public String getHospId() {
        return hospId;
    }

    public void setHospId(String hospId) {
        this.hospId = hospId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLowerCase() {
        if (name == null) {
            return null;
        }
        return name.toLowerCase();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmbulanceAvailable() {
        return ambulanceAvailable;
    }

    public void setAmbulanceAvailable(String ambulanceAvailable) {
        this.ambulanceAvailable = ambulanceAvailable;
    }

    public String getEmergencyAvailable() {
        return emergencyAvailable;
    }

    public void setEmergencyAvailable(String emergencyAvailable) {
        this.emergencyAvailable = emergencyAvailable;
    }

    public String getTimings() {
        return timings;
    }

    public void setTimings(String timings) {
        this.timings = timings;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Map getSpecialisation() {
        return specialisation;
    }

    public void setSpecialisation(Map specialisation) {
        this.specialisation = specialisation;
    }

    public String getSpecialities() {
        return specialities;
    }

    public void setSpecialities(String specialities) {
        this.specialities = specialities;
    }

    public List<Map.Entry<String, List>> getMyHashMapEntryList() {
        return new ArrayList(getSpecialisation().entrySet());
    }

    public List<Doctor> getHospDocList() {
        return hospDocList;
    }

    public void setHospDocList(List<Doctor> hospDocList) {
        this.hospDocList = hospDocList;
    }

    
}
