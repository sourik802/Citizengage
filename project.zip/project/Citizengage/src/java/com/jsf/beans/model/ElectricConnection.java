/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class ElectricConnection extends OnlineApplication {
    
    private String ward;
    private String issueAuthority;
    private boolean tenant;
    private String ownerName;
    private String ownerAddress; //to be checked on save as parent class has Address also
    private Double voltage;
    private Double load;
    private Integer noOfOutlets;
    private Integer noOfpoints5A;
    private Integer noOfpoints15A;
    private boolean subMeterReqd;
    private String identityNo;
    private UploadedFile allotmentLtr;
    private UploadedFile saleDeed;

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getIssueAuthority() {
        return issueAuthority;
    }

    public void setIssueAuthority(String issueAuthority) {
        this.issueAuthority = issueAuthority;
    }

    public boolean isTenant() {
        return tenant;
    }

    public void setTenant(boolean tenant) {
        this.tenant = tenant;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public Double getVoltage() {
        return voltage;
    }

    public void setVoltage(Double voltage) {
        this.voltage = voltage;
    }

    public Double getLoad() {
        return load;
    }

    public void setLoad(Double load) {
        this.load = load;
    }

    public Integer getNoOfOutlets() {
        return noOfOutlets;
    }

    public void setNoOfOutlets(Integer noOfOutlets) {
        this.noOfOutlets = noOfOutlets;
    }

    public Integer getNoOfpoints5A() {
        return noOfpoints5A;
    }

    public void setNoOfpoints5A(Integer noOfpoints5A) {
        this.noOfpoints5A = noOfpoints5A;
    }

    public Integer getNoOfpoints15A() {
        return noOfpoints15A;
    }

    public void setNoOfpoints15A(Integer noOfpoints15A) {
        this.noOfpoints15A = noOfpoints15A;
    }

    public boolean isSubMeterReqd() {
        return subMeterReqd;
    }

    public void setSubMeterReqd(boolean subMeterReqd) {
        this.subMeterReqd = subMeterReqd;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public UploadedFile getAllotmentLtr() {
        return allotmentLtr;
    }

    public void setAllotmentLtr(UploadedFile allotmentLtr) {
        this.allotmentLtr = allotmentLtr;
    }

    public UploadedFile getSaleDeed() {
        return saleDeed;
    }

    public void setSaleDeed(UploadedFile saleDeed) {
        this.saleDeed = saleDeed;
    }
    
    
    
}
