/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.service;

import com.jsf.beans.model.ClubMembership;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;

/**
 *
 * @author Sourik
 */
@Named(value = "clubMembership")
@SessionScoped
public class ClubMembershipService implements Serializable {

    private ClubMembership member;
    private List<String> membershipItems = new ArrayList<>();
    private List<ClubMembership> currentMemberships = new ArrayList<>();
    private List<String> toBeRemoved = new ArrayList<>();

    /**
     * Creates a new instance of ClubMembership
     */
    public ClubMembershipService() {
    }

    @PostConstruct
    public void init() {
        if (member == null) {
            member = new ClubMembership();
        }
        getMembershipItems().add("Gym");
        getMembershipItems().add("Swimming");
        
        setCurrentMemberships(getCurrentMembership());
        
    }

    public ClubMembership getMember() {
        return member;
    }

    public void setMember(ClubMembership member) {
        this.member = member;
    }

    public List<String> getMembershipItems() {
        return membershipItems;
    }

    public void setMembershipItems(List<String> membershipItems) {
        this.membershipItems = membershipItems;
    }
    
    public void takeMembership(){
        System.out.println("within takeMembership "+getMember().getStartDate());
    }

    public List<ClubMembership> getCurrentMemberships() {
        return currentMemberships;
    }

    public void setCurrentMemberships(List<ClubMembership> currentMemberships) {
        this.currentMemberships = currentMemberships;
    }
    
    public List<ClubMembership> getCurrentMembership(){
        List<ClubMembership> list = new ArrayList<>();
        ClubMembership m = new ClubMembership();
        m.setMemberOf("Gym");
        m.setMembershipCode("1000G");
        m.setStartDate(new Date());
        m.setValidUpto(new Date());
        list.add(m);
        return list;
    }

    public List<String> getToBeRemoved() {
        return toBeRemoved;
    }

    public void setToBeRemoved(List<String> toBeRemoved) {
        this.toBeRemoved = toBeRemoved;
    }
    
    public void removeMembershipListener(String mid){
        System.out.println("within removeMembershipListener() "+mid);
        getToBeRemoved().add(mid);
    }
    
    public void updateMembership(){
        System.out.println("within updateMembership()");
    }
}
