/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.util.Date;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author 258290
 */
public class License extends OnlineApplication{
    
    private String licenseType;
    private String applicationNo;
    private String rto;
    private String gender;
    private Date dateOfBirth;
    private String guardianName;
    private String citizenStatus;
    private String qualification;
    private String identificationMark;
    private String booldGrp;
    private String vehicleType;
    private UploadedFile addressProof;
    private UploadedFile qualCert;

    public String getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    public String getApplicationNo() {
        return applicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getRto() {
        return rto;
    }

    public void setRto(String rto) {
        this.rto = rto;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGuardianName() {
        return guardianName;
    }

    public void setGuardianName(String guardianName) {
        this.guardianName = guardianName;
    }

    public String getCitizenStatus() {
        return citizenStatus;
    }

    public void setCitizenStatus(String citizenStatus) {
        this.citizenStatus = citizenStatus;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getIdentificationMark() {
        return identificationMark;
    }

    public void setIdentificationMark(String identificationMark) {
        this.identificationMark = identificationMark;
    }

    public String getBooldGrp() {
        return booldGrp;
    }

    public void setBooldGrp(String booldGrp) {
        this.booldGrp = booldGrp;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public UploadedFile getAddressProof() {
        return addressProof;
    }

    public void setAddressProof(UploadedFile addressProof) {
        this.addressProof = addressProof;
    }

    public UploadedFile getQualCert() {
        return qualCert;
    }

    public void setQualCert(UploadedFile qualCert) {
        this.qualCert = qualCert;
    }
    
    
}
