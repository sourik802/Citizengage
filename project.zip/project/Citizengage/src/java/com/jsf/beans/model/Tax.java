/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.beans.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author 258290
 */
public class Tax implements Serializable{

    private String billId;
    private String consumerNo;
    private String consumerName;
    private Double taxAmt;
    private Double fine;
    private Date assessStartDt;
    private Date assessEndDt;
    private Date dueDt;
    private String paymentStatus;
    private String taxFor; //property, water, electric, telephone
    private boolean payCheckbox;

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public String getConsumerNo() {
        return consumerNo;
    }

    public void setConsumerNo(String consumerNo) {
        this.consumerNo = consumerNo;
    }

    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String consumerName) {
        this.consumerName = consumerName;
    }

    public String getTaxFor() {
        return taxFor;
    }

    public void setTaxFor(String taxFor) {
        this.taxFor = taxFor;
    }

    public Double getTaxAmt() {
        return taxAmt;
    }

    public void setTaxAmt(Double taxAmt) {
        this.taxAmt = taxAmt;
    }

    public Date getAssessStartDt() {
        return assessStartDt;
    }

    public void setAssessStartDt(Date assessStartDt) {
        this.assessStartDt = assessStartDt;
    }

    public Date getAssessEndDt() {
        return assessEndDt;
    }

    public void setAssessEndDt(Date assessEndDt) {
        this.assessEndDt = assessEndDt;
    }

    public Date getDueDt() {
        return dueDt;
    }

    public void setDueDt(Date dueDt) {
        this.dueDt = dueDt;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Double getFine() {
        return fine;
    }

    public void setFine(Double fine) {
        this.fine = fine;
    }

    public boolean isPayCheckbox() {
        return payCheckbox;
    }

    public void setPayCheckbox(boolean payCheckbox) {
        this.payCheckbox = payCheckbox;
    }
    
    
}
