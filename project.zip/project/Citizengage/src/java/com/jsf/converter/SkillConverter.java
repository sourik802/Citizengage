/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf.converter;

import com.jsf.beans.model.Skill;
import com.jsf.beans.service.SkillService;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author Sourik
 */
@FacesConverter("skillConverter")
public class SkillConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        System.out.println("within getAsObject() for value "+value);
        if (value != null && value.trim().length() > 0) {
            try {
                FacesContext context = FacesContext.getCurrentInstance();
                SkillService bean = context.getApplication().evaluateExpressionGet(context, "#{skill}", SkillService.class);
                System.out.println("bean " + bean);
                Skill s = bean.getSkills().get(Integer.parseInt(value));
                System.out.println("skill matched "+s.getItemName());
                return s;
            } catch (NumberFormatException e) {
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Conversion Error", "Not a valid skill."));
            }
        } else {
            return null;
        }

    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if (object != null) {
            return String.valueOf(((Skill) object).getId());
        } else {
            return null;
        }
    }

}
