/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.dataservices;

import com.citizengage.entity.Address;
import com.citizengage.entity.Citycomplaints;
import com.citizengage.entity.Complainimage;
import com.citizengage.entity.Keyvalueholder;
import com.citizengage.entity.Legalcomplains;
import com.citizengage.entity.Userimage;
import com.citizengage.entity.Userinfo;
import com.citizengage.exception.CitizengageException;
import com.jsf.beans.model.Doctor;
import com.jsf.beans.model.Legal;
import com.jsf.beans.model.UserData;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author Sourik
 */
@Singleton
public class DataServicesHelper {

    @PersistenceContext(unitName = "CitizengagePU")
    private EntityManager em;

    private List<String> emailList = new ArrayList<>();

    public List getRegDocKeyValues() {
        List<Keyvalueholder> results = null;
        try {
            if (em != null) {
                Query q = em.createNamedQuery("Keyvalueholder.findByCode");
                q.setParameter("code", "RegDoc");
                results = q.getResultList();
            }
        } catch (Exception e) {
            System.err.println("Exception while getting Registration Document names " + e.getMessage());
        } finally {
            return results;
        }
    }

    public List getKeyValues(String code) {
        List<Keyvalueholder> results = null;
        try {
            if (em != null) {
                Query q = em.createNamedQuery("Keyvalueholder.findByCode");
                q.setParameter("code", code);
                results = q.getResultList();
            }
        } catch (Exception e) {
            System.err.println("Exception while getting key value " + e.getMessage());
        } finally {
            return results;
        }
    }

    public List getUsersEmail() {
        List<String> list = new ArrayList<>();
        try {
            if (em != null && (emailList == null || emailList.size() <= 0)) {
                Query query = em.createQuery("Select u.email from Userinfo u");
                list = query.getResultList();

                list.stream().forEach((e) -> {
                    System.out.println(" email id :" + e);
                    emailList.add(e);
                });

            }
        } catch (Exception e) {
            System.err.println("Error while retrieving email ids " + e);
        } finally {
            return emailList;
        }
    }

    public Integer persistUser(UserData user) throws CitizengageException {
        Integer genID = 0;
        try {
            System.out.println("within persist() of DataServicesHelper");
            if (user == null || user.getEmail() == null || user.getEmail().equals("")) {
                throw new CitizengageException("User data is null");
            }
//            if (emailList.contains(user.getEmail().trim())) {
//                throw new CitizengageException("Email id already exists");
//            }

            Userinfo newUser = new Userinfo();
            newUser.setFirstname(user.getFirstname());
            newUser.setLastname(user.getLastname());
            newUser.setPassword(user.getPassword());
            newUser.setGender(user.getGender());
            newUser.setDob(user.getDob());
            if (user.getMobile() == null) {
                newUser.setMobile(0);
            } else {
                newUser.setMobile(user.getMobile());
            }
            newUser.setHomePhone(user.getHomePhone());
            newUser.setEmail(user.getEmail());
            newUser.setIdentityNo(user.getIdentityNo());
            newUser.setIdentityDocType(user.getIdentityDocType());
            if (!emailList.contains(user.getEmail().trim())) {
                emailList.add(user.getEmail().trim());
            }
            em.persist(newUser);

            Userimage identity = new Userimage();
            System.out.println("identity file stream " + user.getIs1());
            byte[] byteArr = IOUtils.toByteArray(user.getIs1());
            System.out.println("identity byte array " + byteArr);
            //byte[] byteArr = IOUtils.toByteArray(user.getIdentityFile().getInputstream());
            identity.setImage(byteArr);
            identity.setImageName("Photo");
            identity.setUserId(newUser);
            newUser.getUserimageList().add(identity);
            em.persist(identity);

            Userimage img = new Userimage();
            System.out.println("identity file stream " + user.getIs2());
            byte[] byteArrImg = IOUtils.toByteArray(user.getIs2());
            System.out.println("identity byte array " + byteArrImg);
            //byte[] byteArrImg = IOUtils.toByteArray(user.getPhoto().getInputstream());
            img.setImage(byteArrImg);
            img.setImageName("Identity");
            img.setUserId(newUser);
            if (newUser.getUserimageList() == null) {
                newUser.setUserimageList(new ArrayList<>());
            }
            newUser.getUserimageList().add(img);
            em.persist(img);

            Address addr = new Address();
            addr.setHouseNo(user.getAddress().getHouseNo());
            addr.setStreetName("");
            addr.setStreetNo(user.getAddress().getStreetNo());
            addr.setBuilding(user.getAddress().getBuilding());
            addr.setLocality(user.getAddress().getLocality());
            addr.setAddrType("R");
            addr.setCity(user.getAddress().getCity());
            addr.setDistrict(user.getAddress().getDistrict());
            addr.setRstate(user.getAddress().getState());
            addr.setPin(Integer.parseInt(user.getAddress().getPin()));
            addr.setUserId(newUser);
            if (newUser.getAddressList() == null) {
                newUser.setAddressList(new ArrayList<>());
            }
            newUser.getAddressList().add(addr);
            em.persist(addr);
            em.flush();
            System.out.println("After persist and flush primary key is " + newUser.getUserId());
            genID = newUser.getUserId();
        } catch (IOException ex) {
            Logger.getLogger(DataServicesHelper.class.getName()).log(Level.SEVERE, null, ex);
            throw new CitizengageException("Failed to persist user");
        }
        return genID;
    }

    public Integer persistLegalComplain(Legal legal) throws CitizengageException, Exception {
        System.out.println("within persistLegalComplain()");
        Integer id = 0;
        try {
            if (legal == null) {
                throw new CitizengageException("legal complain data is null");
            }
            Userinfo user = em.find(Userinfo.class, 1);
            Legalcomplains legCompln = new Legalcomplains();
            legCompln.setComplainType(legal.getComplainType());
            legCompln.setPoliceStn(legal.getPoliceStn());
            legCompln.setSummary(legal.getSummary());
            legCompln.setDetails(legal.getDetails());
            legCompln.setRaiseDt(new Date());
            legCompln.setIsActive(Boolean.TRUE);
            legCompln.setStatus("N");
            legCompln.setOccurencelatitude(legal.getLatitude().floatValue());
            legCompln.setOccurencelongitude(legal.getLongitude().floatValue());
            legCompln.setUserId(user);
            if (user.getLegalcomplainsList() == null) {
                user.setLegalcomplainsList(new ArrayList<>());
            }
            user.getLegalcomplainsList().add(legCompln);
            em.persist(legCompln);
            int noOfFiles = 0;
            if (legal.getIs() != null && legal.getIs().size() > 0) {
                noOfFiles = legal.getIs().size();
            }
            System.out.println("no of files as evidence " + noOfFiles);
            for (int i = 0; i < noOfFiles; i++) {
                Complainimage ci = new Complainimage();
                byte[] byteArr = IOUtils.toByteArray(legal.getIs().get(i));
                System.out.println("evidence files byte arr " + byteArr);
                ci.setImageName("File_" + i + 1);
                ci.setComplainID(legCompln);
                ci.setImage(byteArr);
                if (legCompln.getComplainimageList() == null) {
                    legCompln.setComplainimageList(new ArrayList<>());
                }
                legCompln.getComplainimageList().add(ci);
                System.out.println("persisting complain image " + ci);
                em.persist(ci);
            }
            em.flush();
            System.out.println("complain id " + legCompln.getComplainID());
            id = legCompln.getComplainID();
        } catch (CitizengageException cex) {
            throw new CitizengageException("Error occurred " + cex.getMessage());
        } catch (Exception e) {
            throw new Exception("Error occurred " + e.getMessage());
        }
        return id;
    }

    public List fetchDoctors(String speciality) {
        System.out.println("within fetchDoctors() for " + speciality);
        List<Doctor> docList = new ArrayList<>();
        try {
            if (!"All".equals(speciality)) {
                Query q = em.createNamedQuery("Doctor.findBySpecialization");
                q.setParameter("specialization", speciality);
                docList = q.getResultList();
            } else {
                Query q = em.createNamedQuery("Doctor.findAll");
                docList = q.getResultList();
            }
        } catch (Exception e) {
            System.err.println("Error retrieving doctors " + e.getMessage());
        }
        return docList;
    }

    public Userinfo searchUserById(Integer id) {
        System.out.println("within searchUserById() for " + id);
        Userinfo user = null;
        try {
            Query q = em.createNamedQuery("Userinfo.findByUserId");
            q.setParameter("userId", id);
            user = (Userinfo) q.getSingleResult();
        } catch (Exception e) {
            System.err.println("Failed to find user " + e.getMessage());
        }
        return user;
    }

    public List fetchCityComplaints() {
        System.out.println("within fetchCityComplaints()");
        List<Citycomplaints> cList = new ArrayList<>();
        try {

            Query q = em.createNamedQuery("Citycomplaints.findAll");
            cList = q.getResultList();

        } catch (Exception e) {
            System.err.println("Error retrieving complain list " + e.getMessage());
        }
        return cList;
    }

    public Userinfo getLoggedin(String email, String password){
        System.out.println("within getLoggedin() for "+email);
        Userinfo user = null;
        try {
            Query q = em.createQuery("SELECT u FROM Userinfo u WHERE u.email = :email and u.password = :password");
            q.setParameter("email", email);
            q.setParameter("password", password);
            user = (Userinfo) q.getSingleResult();
            System.out.println("user "+user);
            return user;
        } finally {
            return user;
        }        
    }
}
