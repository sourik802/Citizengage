/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.ejb;

import com.citizengage.dataservices.DataServicesHelper;
import com.citizengage.entity.Keyvalueholder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Singleton;

/**
 *
 * @author Sourik
 */
@Singleton
public class LoadKeyValues {

    @EJB
    private DataServicesHelper dataServices;

    private final Map<String, String> registerDocs = new HashMap();
    private final Map<String, String> genders = new HashMap();
    private final Map<String, String> complainTyp = new HashMap();
    private final Map<String, String> polStns = new HashMap();
    private final List<String> specialities = new ArrayList<>();
    private final Map<String, String> donateItems = new HashMap();
    
    public Map getGender() {
        if(genders == null || genders.size() <=0){
            List list = dataServices.getKeyValues("Gender");
            if(list != null && list.size() > 0){
                list.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    genders.put(value.getValue(), value.getUICode());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return genders;
    }

    public Map getRegistrationDocNames() {
        if(registerDocs == null || registerDocs.size() <=0){
            List docList = dataServices.getKeyValues("IdDocTyp");
            if(docList != null && docList.size() > 0){
                docList.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    registerDocs.put(value.getValue(), value.getUICode());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return registerDocs;
    }
    
    public Map getComplainTyp() {
        if(complainTyp == null || complainTyp.size() <=0){
            List list = dataServices.getKeyValues("LegalComTp");
            if(list != null && list.size() > 0){
                list.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    complainTyp.put(value.getValue(), value.getUICode());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return complainTyp;
    }

    public Map getPolStns() {
        if(polStns == null || polStns.size() <=0){
            List list = dataServices.getKeyValues("PolStn");
            if(list != null && list.size() > 0){
                list.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    polStns.put(value.getValue(), value.getUICode());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return polStns;
    }

    
    public List getDocSpecialityList() {
        if(specialities == null || specialities.size() <=0){
            List list = dataServices.getKeyValues("DocSplty");
            if(list != null && list.size() > 0){
                list.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    specialities.add(value.getValue());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return specialities;
    }  
    
    //not used
    public Map getDonationItems() {
        if(donateItems == null || donateItems.size() <=0){
            List list = dataServices.getKeyValues("OrganReq");
            if(list != null && list.size() > 0){
                list.stream().forEach((o) -> {
                    Keyvalueholder value = (Keyvalueholder) o;
                    donateItems.put(value.getValue(), value.getUICode());
                    System.out.println("key "+value.getUICode()+"  value "+value.getValue());
                });
            }
        }
        return donateItems;
    }

}
