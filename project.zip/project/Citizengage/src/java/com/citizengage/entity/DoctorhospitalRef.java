/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "doctorhospital_ref")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DoctorhospitalRef.findAll", query = "SELECT d FROM DoctorhospitalRef d"),
    @NamedQuery(name = "DoctorhospitalRef.findBySeqID", query = "SELECT d FROM DoctorhospitalRef d WHERE d.seqID = :seqID")})
public class DoctorhospitalRef implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "seqID")
    private Integer seqID;
    @JoinColumn(name = "hospitalid", referencedColumnName = "hospitalId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Hospital hospitalid;
    @JoinColumn(name = "docId", referencedColumnName = "docId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Doctor docId;

    public DoctorhospitalRef() {
    }

    public DoctorhospitalRef(Integer seqID) {
        this.seqID = seqID;
    }

    public Integer getSeqID() {
        return seqID;
    }

    public void setSeqID(Integer seqID) {
        this.seqID = seqID;
    }

    public Hospital getHospitalid() {
        return hospitalid;
    }

    public void setHospitalid(Hospital hospitalid) {
        this.hospitalid = hospitalid;
    }

    public Doctor getDocId() {
        return docId;
    }

    public void setDocId(Doctor docId) {
        this.docId = docId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (seqID != null ? seqID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DoctorhospitalRef)) {
            return false;
        }
        DoctorhospitalRef other = (DoctorhospitalRef) object;
        if ((this.seqID == null && other.seqID != null) || (this.seqID != null && !this.seqID.equals(other.seqID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.DoctorhospitalRef[ seqID=" + seqID + " ]";
    }

}
