/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "tax")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tax.findAll", query = "SELECT t FROM Tax t"),
    @NamedQuery(name = "Tax.findByTaxid", query = "SELECT t FROM Tax t WHERE t.taxid = :taxid"),
    @NamedQuery(name = "Tax.findByTaxFor", query = "SELECT t FROM Tax t WHERE t.taxFor = :taxFor"),
    @NamedQuery(name = "Tax.findByBillId", query = "SELECT t FROM Tax t WHERE t.billId = :billId"),
    @NamedQuery(name = "Tax.findByConsumerNo", query = "SELECT t FROM Tax t WHERE t.consumerNo = :consumerNo"),
    @NamedQuery(name = "Tax.findByTaxAmt", query = "SELECT t FROM Tax t WHERE t.taxAmt = :taxAmt"),
    @NamedQuery(name = "Tax.findByFine", query = "SELECT t FROM Tax t WHERE t.fine = :fine"),
    @NamedQuery(name = "Tax.findByAssessStartDt", query = "SELECT t FROM Tax t WHERE t.assessStartDt = :assessStartDt"),
    @NamedQuery(name = "Tax.findByAssessEndDt", query = "SELECT t FROM Tax t WHERE t.assessEndDt = :assessEndDt"),
    @NamedQuery(name = "Tax.findByDueDt", query = "SELECT t FROM Tax t WHERE t.dueDt = :dueDt"),
    @NamedQuery(name = "Tax.findByPaymentStatus", query = "SELECT t FROM Tax t WHERE t.paymentStatus = :paymentStatus")})
public class Tax implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "taxid")
    private Integer taxid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "taxFor")
    private String taxFor;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "billId")
    private String billId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "consumerNo")
    private String consumerNo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "taxAmt")
    private float taxAmt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fine")
    private float fine;
    @Column(name = "assessStartDt")
    @Temporal(TemporalType.DATE)
    private Date assessStartDt;
    @Column(name = "assessEndDt")
    @Temporal(TemporalType.DATE)
    private Date assessEndDt;
    @Column(name = "dueDt")
    @Temporal(TemporalType.DATE)
    private Date dueDt;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "paymentStatus")
    private String paymentStatus;
    @JoinColumn(name = "userid", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userid;

    public Tax() {
    }

    public Tax(Integer taxid) {
        this.taxid = taxid;
    }

    public Tax(Integer taxid, String taxFor, String billId, String consumerNo, float taxAmt, float fine, String paymentStatus) {
        this.taxid = taxid;
        this.taxFor = taxFor;
        this.billId = billId;
        this.consumerNo = consumerNo;
        this.taxAmt = taxAmt;
        this.fine = fine;
        this.paymentStatus = paymentStatus;
    }

    public Integer getTaxid() {
        return taxid;
    }

    public void setTaxid(Integer taxid) {
        this.taxid = taxid;
    }

    public String getTaxFor() {
        return taxFor;
    }

    public void setTaxFor(String taxFor) {
        this.taxFor = taxFor;
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public String getConsumerNo() {
        return consumerNo;
    }

    public void setConsumerNo(String consumerNo) {
        this.consumerNo = consumerNo;
    }

    public float getTaxAmt() {
        return taxAmt;
    }

    public void setTaxAmt(float taxAmt) {
        this.taxAmt = taxAmt;
    }

    public float getFine() {
        return fine;
    }

    public void setFine(float fine) {
        this.fine = fine;
    }

    public Date getAssessStartDt() {
        return assessStartDt;
    }

    public void setAssessStartDt(Date assessStartDt) {
        this.assessStartDt = assessStartDt;
    }

    public Date getAssessEndDt() {
        return assessEndDt;
    }

    public void setAssessEndDt(Date assessEndDt) {
        this.assessEndDt = assessEndDt;
    }

    public Date getDueDt() {
        return dueDt;
    }

    public void setDueDt(Date dueDt) {
        this.dueDt = dueDt;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Userinfo getUserid() {
        return userid;
    }

    public void setUserid(Userinfo userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (taxid != null ? taxid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tax)) {
            return false;
        }
        Tax other = (Tax) object;
        if ((this.taxid == null && other.taxid != null) || (this.taxid != null && !this.taxid.equals(other.taxid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Tax[ taxid=" + taxid + " ]";
    }

}
