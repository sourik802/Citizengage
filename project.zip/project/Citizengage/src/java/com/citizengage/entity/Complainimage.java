/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "complainimage")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Complainimage.findAll", query = "SELECT c FROM Complainimage c"),
    @NamedQuery(name = "Complainimage.findByImageid", query = "SELECT c FROM Complainimage c WHERE c.imageid = :imageid"),
    @NamedQuery(name = "Complainimage.findByImageName", query = "SELECT c FROM Complainimage c WHERE c.imageName = :imageName")})
public class Complainimage implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "imageid")
    private Integer imageid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "image_name")
    private String imageName;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "image")
    private byte[] image;
    @JoinColumn(name = "complainID", referencedColumnName = "complainID")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Legalcomplains complainID;

    public Complainimage() {
    }

    public Complainimage(Integer imageid) {
        this.imageid = imageid;
    }

    public Complainimage(Integer imageid, String imageName, byte[] image) {
        this.imageid = imageid;
        this.imageName = imageName;
        this.image = image;
    }

    public Integer getImageid() {
        return imageid;
    }

    public void setImageid(Integer imageid) {
        this.imageid = imageid;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Legalcomplains getComplainID() {
        return complainID;
    }

    public void setComplainID(Legalcomplains complainID) {
        this.complainID = complainID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (imageid != null ? imageid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Complainimage)) {
            return false;
        }
        Complainimage other = (Complainimage) object;
        if ((this.imageid == null && other.imageid != null) || (this.imageid != null && !this.imageid.equals(other.imageid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Complainimage[ imageid=" + imageid + " ]";
    }

}
