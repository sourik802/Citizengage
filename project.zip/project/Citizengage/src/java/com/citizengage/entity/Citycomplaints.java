/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "citycomplaints")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Citycomplaints.findAll", query = "SELECT c FROM Citycomplaints c"),
    @NamedQuery(name = "Citycomplaints.findByComplainID", query = "SELECT c FROM Citycomplaints c WHERE c.complainID = :complainID"),
    @NamedQuery(name = "Citycomplaints.findByCategory", query = "SELECT c FROM Citycomplaints c WHERE c.category = :category"),
    @NamedQuery(name = "Citycomplaints.findBySubCategory", query = "SELECT c FROM Citycomplaints c WHERE c.subCategory = :subCategory"),
    @NamedQuery(name = "Citycomplaints.findByDescription", query = "SELECT c FROM Citycomplaints c WHERE c.description = :description"),
    @NamedQuery(name = "Citycomplaints.findByCreatedAt", query = "SELECT c FROM Citycomplaints c WHERE c.createdAt = :createdAt")})
public class Citycomplaints implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ComplainID")
    private Integer complainID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "Category")
    private String category;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "SubCategory")
    private String subCategory;
    @Size(max = 100)
    @Column(name = "Description")
    private String description;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    public Citycomplaints() {
    }

    public Citycomplaints(Integer complainID) {
        this.complainID = complainID;
    }

    public Citycomplaints(Integer complainID, String category, String subCategory, Date createdAt) {
        this.complainID = complainID;
        this.category = category;
        this.subCategory = subCategory;
        this.createdAt = createdAt;
    }

    public Integer getComplainID() {
        return complainID;
    }

    public void setComplainID(Integer complainID) {
        this.complainID = complainID;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (complainID != null ? complainID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Citycomplaints)) {
            return false;
        }
        Citycomplaints other = (Citycomplaints) object;
        if ((this.complainID == null && other.complainID != null) || (this.complainID != null && !this.complainID.equals(other.complainID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Citycomplaints[ complainID=" + complainID + " ]";
    }
    
}
