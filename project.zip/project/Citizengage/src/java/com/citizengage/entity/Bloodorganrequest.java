/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "bloodorganrequest")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bloodorganrequest.findAll", query = "SELECT b FROM Bloodorganrequest b"),
    @NamedQuery(name = "Bloodorganrequest.findByRequestID", query = "SELECT b FROM Bloodorganrequest b WHERE b.requestID = :requestID"),
    @NamedQuery(name = "Bloodorganrequest.findByRequestorName", query = "SELECT b FROM Bloodorganrequest b WHERE b.requestorName = :requestorName"),
    @NamedQuery(name = "Bloodorganrequest.findByAilment", query = "SELECT b FROM Bloodorganrequest b WHERE b.ailment = :ailment"),
    @NamedQuery(name = "Bloodorganrequest.findByReqGender", query = "SELECT b FROM Bloodorganrequest b WHERE b.reqGender = :reqGender"),
    @NamedQuery(name = "Bloodorganrequest.findByReqAge", query = "SELECT b FROM Bloodorganrequest b WHERE b.reqAge = :reqAge"),
    @NamedQuery(name = "Bloodorganrequest.findByDocName", query = "SELECT b FROM Bloodorganrequest b WHERE b.docName = :docName"),
    @NamedQuery(name = "Bloodorganrequest.findByHospName", query = "SELECT b FROM Bloodorganrequest b WHERE b.hospName = :hospName"),
    @NamedQuery(name = "Bloodorganrequest.findByReqBloodGrp", query = "SELECT b FROM Bloodorganrequest b WHERE b.reqBloodGrp = :reqBloodGrp"),
    @NamedQuery(name = "Bloodorganrequest.findByRequestedItem", query = "SELECT b FROM Bloodorganrequest b WHERE b.requestedItem = :requestedItem"),
    @NamedQuery(name = "Bloodorganrequest.findBySpecification", query = "SELECT b FROM Bloodorganrequest b WHERE b.specification = :specification"),
    @NamedQuery(name = "Bloodorganrequest.findByIsActive", query = "SELECT b FROM Bloodorganrequest b WHERE b.isActive = :isActive")})
public class Bloodorganrequest implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "requestID")
    private Integer requestID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "requestorName")
    private String requestorName;
    @Size(max = 30)
    @Column(name = "ailment")
    private String ailment;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "reqGender")
    private String reqGender;
    @Column(name = "reqAge")
    private Integer reqAge;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "docName")
    private String docName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "hospName")
    private String hospName;
    @Basic(optional = false)

    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "reqBloodGrp")
    private String reqBloodGrp;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "requestedItem")
    private String requestedItem;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "specification")
    private String specification;
    @Column(name = "isActive")
    private Boolean isActive;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Bloodorganrequest() {
    }

    public Bloodorganrequest(Integer requestID) {
        this.requestID = requestID;
    }

    public Bloodorganrequest(Integer requestID, String requestorName, String reqGender, String docName, String hospName, String reqBloodGrp, String requestedItem, String specification) {
        this.requestID = requestID;
        this.requestorName = requestorName;
        this.reqGender = reqGender;
        this.docName = docName;
        this.hospName = hospName;
        this.reqBloodGrp = reqBloodGrp;
        this.requestedItem = requestedItem;
        this.specification = specification;
    }

    public Integer getRequestID() {
        return requestID;
    }

    public void setRequestID(Integer requestID) {
        this.requestID = requestID;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    public String getAilment() {
        return ailment;
    }

    public void setAilment(String ailment) {
        this.ailment = ailment;
    }

    public String getReqGender() {
        return reqGender;
    }

    public void setReqGender(String reqGender) {
        this.reqGender = reqGender;
    }

    public Integer getReqAge() {
        return reqAge;
    }

    public void setReqAge(Integer reqAge) {
        this.reqAge = reqAge;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getHospName() {
        return hospName;
    }

    public void setHospName(String hospName) {
        this.hospName = hospName;
    }

    public String getReqBloodGrp() {
        return reqBloodGrp;
    }

    public void setReqBloodGrp(String reqBloodGrp) {
        this.reqBloodGrp = reqBloodGrp;
    }

    public String getRequestedItem() {
        return requestedItem;
    }

    public void setRequestedItem(String requestedItem) {
        this.requestedItem = requestedItem;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (requestID != null ? requestID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bloodorganrequest)) {
            return false;
        }
        Bloodorganrequest other = (Bloodorganrequest) object;
        if ((this.requestID == null && other.requestID != null) || (this.requestID != null && !this.requestID.equals(other.requestID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Bloodorganrequest[ requestID=" + requestID + " ]";
    }

}
