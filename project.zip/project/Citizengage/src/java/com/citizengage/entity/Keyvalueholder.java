/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "keyvalueholder")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Keyvalueholder.findAll", query = "SELECT k FROM Keyvalueholder k"),
    @NamedQuery(name = "Keyvalueholder.findByCodeID", query = "SELECT k FROM Keyvalueholder k WHERE k.codeID = :codeID"),
    @NamedQuery(name = "Keyvalueholder.findByCode", query = "SELECT k FROM Keyvalueholder k WHERE k.code = :code"),
    @NamedQuery(name = "Keyvalueholder.findByUICode", query = "SELECT k FROM Keyvalueholder k WHERE k.uICode = :uICode"),
    @NamedQuery(name = "Keyvalueholder.findByValue", query = "SELECT k FROM Keyvalueholder k WHERE k.value = :value"),
    @NamedQuery(name = "Keyvalueholder.findByDescription", query = "SELECT k FROM Keyvalueholder k WHERE k.description = :description")})
public class Keyvalueholder implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CodeID")
    private Integer codeID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "Code")
    private String code;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "UICode")
    private String uICode;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "Value")
    private String value;
    @Size(max = 100)
    @Column(name = "Description")
    private String description;

    public Keyvalueholder() {
    }

    public Keyvalueholder(Integer codeID) {
        this.codeID = codeID;
    }

    public Keyvalueholder(Integer codeID, String code, String uICode, String value) {
        this.codeID = codeID;
        this.code = code;
        this.uICode = uICode;
        this.value = value;
    }

    public Integer getCodeID() {
        return codeID;
    }

    public void setCodeID(Integer codeID) {
        this.codeID = codeID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getUICode() {
        return uICode;
    }

    public void setUICode(String uICode) {
        this.uICode = uICode;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codeID != null ? codeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Keyvalueholder)) {
            return false;
        }
        Keyvalueholder other = (Keyvalueholder) object;
        if ((this.codeID == null && other.codeID != null) || (this.codeID != null && !this.codeID.equals(other.codeID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Keyvalueholder[ codeID=" + codeID + " ]";
    }

}
