/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "applicationfiles")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Applicationfiles.findAll", query = "SELECT a FROM Applicationfiles a"),
    @NamedQuery(name = "Applicationfiles.findByImageid", query = "SELECT a FROM Applicationfiles a WHERE a.imageid = :imageid"),
    @NamedQuery(name = "Applicationfiles.findByImageName", query = "SELECT a FROM Applicationfiles a WHERE a.imageName = :imageName")})
public class Applicationfiles implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "imageid")
    private Integer imageid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "image_name")
    private String imageName;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "image")
    private byte[] image;
    
    @JoinColumn(name = "applicationid", referencedColumnName = "applicationid")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Onlineapplication applicationid;

    public Applicationfiles() {
    }

    public Applicationfiles(Integer imageid) {
        this.imageid = imageid;
    }

    public Applicationfiles(Integer imageid, String imageName, byte[] image) {
        this.imageid = imageid;
        this.imageName = imageName;
        this.image = image;
    }

    public Integer getImageid() {
        return imageid;
    }

    public void setImageid(Integer imageid) {
        this.imageid = imageid;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Onlineapplication getApplicationid() {
        return applicationid;
    }

    public void setApplicationid(Onlineapplication applicationid) {
        this.applicationid = applicationid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (imageid != null ? imageid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Applicationfiles)) {
            return false;
        }
        Applicationfiles other = (Applicationfiles) object;
        if ((this.imageid == null && other.imageid != null) || (this.imageid != null && !this.imageid.equals(other.imageid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Applicationfiles[ imageid=" + imageid + " ]";
    }
    
}
