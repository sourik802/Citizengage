/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "property")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Property.findAll", query = "SELECT p FROM Property p"),
    @NamedQuery(name = "Property.findByPropid", query = "SELECT p FROM Property p WHERE p.propid = :propid"),
    @NamedQuery(name = "Property.findByPropertypin", query = "SELECT p FROM Property p WHERE p.propertypin = :propertypin"),
    @NamedQuery(name = "Property.findByTaxid", query = "SELECT p FROM Property p WHERE p.taxid = :taxid"),
    @NamedQuery(name = "Property.findByOwnerName", query = "SELECT p FROM Property p WHERE p.ownerName = :ownerName"),
    @NamedQuery(name = "Property.findByOwnerPhone", query = "SELECT p FROM Property p WHERE p.ownerPhone = :ownerPhone"),
    @NamedQuery(name = "Property.findByAddrid", query = "SELECT p FROM Property p WHERE p.addrid = :addrid"),
    @NamedQuery(name = "Property.findByWard", query = "SELECT p FROM Property p WHERE p.ward = :ward")})
public class Property implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "propid")
    private Integer propid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "propertypin")
    private String propertypin;
    @Basic(optional = false)
    @NotNull
    @Column(name = "taxid")
    private int taxid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ownerName")
    private String ownerName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ownerPhone")
    private String ownerPhone;
    @Basic(optional = false)
    @NotNull
    @Column(name = "addrid")
    private int addrid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ward")
    private String ward;
    @JoinColumn(name = "userid", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userid;

    public Property() {
    }

    public Property(Integer propid) {
        this.propid = propid;
    }

    public Property(Integer propid, String propertypin, int taxid, String ownerName, String ownerPhone, int addrid, String ward) {
        this.propid = propid;
        this.propertypin = propertypin;
        this.taxid = taxid;
        this.ownerName = ownerName;
        this.ownerPhone = ownerPhone;
        this.addrid = addrid;
        this.ward = ward;
    }

    public Integer getPropid() {
        return propid;
    }

    public void setPropid(Integer propid) {
        this.propid = propid;
    }

    public String getPropertypin() {
        return propertypin;
    }

    public void setPropertypin(String propertypin) {
        this.propertypin = propertypin;
    }

    public int getTaxid() {
        return taxid;
    }

    public void setTaxid(int taxid) {
        this.taxid = taxid;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    public int getAddrid() {
        return addrid;
    }

    public void setAddrid(int addrid) {
        this.addrid = addrid;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public Userinfo getUserid() {
        return userid;
    }

    public void setUserid(Userinfo userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (propid != null ? propid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Property)) {
            return false;
        }
        Property other = (Property) object;
        if ((this.propid == null && other.propid != null) || (this.propid != null && !this.propid.equals(other.propid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Property[ propid=" + propid + " ]";
    }

}
