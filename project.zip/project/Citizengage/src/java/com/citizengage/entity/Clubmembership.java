/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "clubmembership")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Clubmembership.findAll", query = "SELECT c FROM Clubmembership c"),
    @NamedQuery(name = "Clubmembership.findByMembershipID", query = "SELECT c FROM Clubmembership c WHERE c.membershipID = :membershipID"),
    @NamedQuery(name = "Clubmembership.findByMemberOf", query = "SELECT c FROM Clubmembership c WHERE c.memberOf = :memberOf"),
    @NamedQuery(name = "Clubmembership.findByStartDt", query = "SELECT c FROM Clubmembership c WHERE c.startDt = :startDt"),
    @NamedQuery(name = "Clubmembership.findByValidUpto", query = "SELECT c FROM Clubmembership c WHERE c.validUpto = :validUpto"),
    @NamedQuery(name = "Clubmembership.findByMembershipCd", query = "SELECT c FROM Clubmembership c WHERE c.membershipCd = :membershipCd")})
public class Clubmembership implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "membershipID")
    private Integer membershipID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "memberOf")
    private String memberOf;
    @Basic(optional = false)
    @NotNull
    @Column(name = "startDt")
    @Temporal(TemporalType.DATE)
    private Date startDt;
    @Column(name = "validUpto")
    @Temporal(TemporalType.DATE)
    private Date validUpto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "membershipCd")
    private String membershipCd;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Clubmembership() {
    }

    public Clubmembership(Integer membershipID) {
        this.membershipID = membershipID;
    }

    public Clubmembership(Integer membershipID, String memberOf, Date startDt, String membershipCd) {
        this.membershipID = membershipID;
        this.memberOf = memberOf;
        this.startDt = startDt;
        this.membershipCd = membershipCd;
    }

    public Integer getMembershipID() {
        return membershipID;
    }

    public void setMembershipID(Integer membershipID) {
        this.membershipID = membershipID;
    }

    public String getMemberOf() {
        return memberOf;
    }

    public void setMemberOf(String memberOf) {
        this.memberOf = memberOf;
    }

    public Date getStartDt() {
        return startDt;
    }

    public void setStartDt(Date startDt) {
        this.startDt = startDt;
    }

    public Date getValidUpto() {
        return validUpto;
    }

    public void setValidUpto(Date validUpto) {
        this.validUpto = validUpto;
    }

    public String getMembershipCd() {
        return membershipCd;
    }

    public void setMembershipCd(String membershipCd) {
        this.membershipCd = membershipCd;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (membershipID != null ? membershipID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Clubmembership)) {
            return false;
        }
        Clubmembership other = (Clubmembership) object;
        if ((this.membershipID == null && other.membershipID != null) || (this.membershipID != null && !this.membershipID.equals(other.membershipID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Clubmembership[ membershipID=" + membershipID + " ]";
    }

}
