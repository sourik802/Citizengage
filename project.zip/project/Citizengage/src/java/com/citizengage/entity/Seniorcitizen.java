/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "seniorcitizen")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Seniorcitizen.findAll", query = "SELECT s FROM Seniorcitizen s"),
    @NamedQuery(name = "Seniorcitizen.findByScid", query = "SELECT s FROM Seniorcitizen s WHERE s.scid = :scid")})
public class Seniorcitizen implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "scid")
    private Integer scid;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Seniorcitizen() {
    }

    public Seniorcitizen(Integer scid) {
        this.scid = scid;
    }

    public Integer getScid() {
        return scid;
    }

    public void setScid(Integer scid) {
        this.scid = scid;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (scid != null ? scid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seniorcitizen)) {
            return false;
        }
        Seniorcitizen other = (Seniorcitizen) object;
        if ((this.scid == null && other.scid != null) || (this.scid != null && !this.scid.equals(other.scid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Seniorcitizen[ scid=" + scid + " ]";
    }

}
