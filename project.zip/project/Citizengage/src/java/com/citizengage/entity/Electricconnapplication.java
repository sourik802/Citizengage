/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "electricconnapplication")
@DiscriminatorValue("Electric")
@PrimaryKeyJoinColumn(referencedColumnName = "applicationid")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Electricconnapplication.findAll", query = "SELECT e FROM Electricconnapplication e"),
    @NamedQuery(name = "Electricconnapplication.findByApplicationid", query = "SELECT e FROM Electricconnapplication e WHERE e.applicationid = :applicationid"),
    @NamedQuery(name = "Electricconnapplication.findByApplicationtype", query = "SELECT e FROM Electricconnapplication e WHERE e.applicationtype = :applicationtype"),
    @NamedQuery(name = "Electricconnapplication.findByWard", query = "SELECT e FROM Electricconnapplication e WHERE e.ward = :ward"),
    @NamedQuery(name = "Electricconnapplication.findByIssueAuthority", query = "SELECT e FROM Electricconnapplication e WHERE e.issueAuthority = :issueAuthority"),
    @NamedQuery(name = "Electricconnapplication.findByTenant", query = "SELECT e FROM Electricconnapplication e WHERE e.tenant = :tenant"),
    @NamedQuery(name = "Electricconnapplication.findByOwnerName", query = "SELECT e FROM Electricconnapplication e WHERE e.ownerName = :ownerName"),
    @NamedQuery(name = "Electricconnapplication.findByOwnerAddress", query = "SELECT e FROM Electricconnapplication e WHERE e.ownerAddress = :ownerAddress"),
    @NamedQuery(name = "Electricconnapplication.findByVoltage", query = "SELECT e FROM Electricconnapplication e WHERE e.voltage = :voltage"),
    @NamedQuery(name = "Electricconnapplication.findByTotalload", query = "SELECT e FROM Electricconnapplication e WHERE e.totalload = :totalload"),
    @NamedQuery(name = "Electricconnapplication.findByNoOfOutlets", query = "SELECT e FROM Electricconnapplication e WHERE e.noOfOutlets = :noOfOutlets"),
    @NamedQuery(name = "Electricconnapplication.findByNoOfpoints5A", query = "SELECT e FROM Electricconnapplication e WHERE e.noOfpoints5A = :noOfpoints5A"),
    @NamedQuery(name = "Electricconnapplication.findByNoOfpoints15A", query = "SELECT e FROM Electricconnapplication e WHERE e.noOfpoints15A = :noOfpoints15A"),
    @NamedQuery(name = "Electricconnapplication.findBySubMeterReqd", query = "SELECT e FROM Electricconnapplication e WHERE e.subMeterReqd = :subMeterReqd"),
    @NamedQuery(name = "Electricconnapplication.findByIdentityNo", query = "SELECT e FROM Electricconnapplication e WHERE e.identityNo = :identityNo")})
public class Electricconnapplication extends Onlineapplication {

    private static final long serialVersionUID = 1L;

    @Size(max = 10)
    @Column(name = "applicationtype")
    private String applicationtype;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "ward")
    private String ward;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "issueAuthority")
    private String issueAuthority;
    @Column(name = "tenant")
    private Boolean tenant;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "ownerName")
    private String ownerName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ownerAddress")
    private String ownerAddress;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "voltage")
    private Float voltage;
    @Column(name = "totalload")
    private Float totalload;
    @Column(name = "noOfOutlets")
    private Integer noOfOutlets;
    @Column(name = "noOfpoints5A")
    private Integer noOfpoints5A;
    @Column(name = "noOfpoints15A")
    private Integer noOfpoints15A;
    @Column(name = "subMeterReqd")
    private Boolean subMeterReqd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "identityNo")
    private String identityNo;
    @Lob
    @Column(name = "allotmentLtr")
    private byte[] allotmentLtr;
    @Lob
    @Column(name = "saleDeed")
    private byte[] saleDeed;
    @JoinColumn(name = "applicationid", referencedColumnName = "applicationid", insertable = false, updatable = false)
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    private Onlineapplication onlineapplication;

    public Electricconnapplication() {
    }

    public Electricconnapplication(Integer applicationid) {
        super(applicationid);
    }

    public Electricconnapplication(Integer applicationid, String ward, String issueAuthority, String ownerName, String ownerAddress, String identityNo) {
        super(applicationid);
        this.ward = ward;
        this.issueAuthority = issueAuthority;
        this.ownerName = ownerName;
        this.ownerAddress = ownerAddress;
        this.identityNo = identityNo;
    }

    public String getApplicationtype() {
        return applicationtype;
    }

    public void setApplicationtype(String applicationtype) {
        this.applicationtype = applicationtype;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getIssueAuthority() {
        return issueAuthority;
    }

    public void setIssueAuthority(String issueAuthority) {
        this.issueAuthority = issueAuthority;
    }

    public Boolean getTenant() {
        return tenant;
    }

    public void setTenant(Boolean tenant) {
        this.tenant = tenant;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public Float getVoltage() {
        return voltage;
    }

    public void setVoltage(Float voltage) {
        this.voltage = voltage;
    }

    public Float getTotalload() {
        return totalload;
    }

    public void setTotalload(Float totalload) {
        this.totalload = totalload;
    }

    public Integer getNoOfOutlets() {
        return noOfOutlets;
    }

    public void setNoOfOutlets(Integer noOfOutlets) {
        this.noOfOutlets = noOfOutlets;
    }

    public Integer getNoOfpoints5A() {
        return noOfpoints5A;
    }

    public void setNoOfpoints5A(Integer noOfpoints5A) {
        this.noOfpoints5A = noOfpoints5A;
    }

    public Integer getNoOfpoints15A() {
        return noOfpoints15A;
    }

    public void setNoOfpoints15A(Integer noOfpoints15A) {
        this.noOfpoints15A = noOfpoints15A;
    }

    public Boolean getSubMeterReqd() {
        return subMeterReqd;
    }

    public void setSubMeterReqd(Boolean subMeterReqd) {
        this.subMeterReqd = subMeterReqd;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public byte[] getAllotmentLtr() {
        return allotmentLtr;
    }

    public void setAllotmentLtr(byte[] allotmentLtr) {
        this.allotmentLtr = allotmentLtr;
    }

    public byte[] getSaleDeed() {
        return saleDeed;
    }

    public void setSaleDeed(byte[] saleDeed) {
        this.saleDeed = saleDeed;
    }

    public Onlineapplication getOnlineapplication() {
        return onlineapplication;
    }

    public void setOnlineapplication(Onlineapplication onlineapplication) {
        this.onlineapplication = onlineapplication;
    }

}
