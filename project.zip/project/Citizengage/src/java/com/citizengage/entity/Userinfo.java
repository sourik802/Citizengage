/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "userinfo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Userinfo.findAll", query = "SELECT u FROM Userinfo u"),
    @NamedQuery(name = "Userinfo.findByUserId", query = "SELECT u FROM Userinfo u WHERE u.userId = :userId"),
    @NamedQuery(name = "Userinfo.findByFirstname", query = "SELECT u FROM Userinfo u WHERE u.firstname = :firstname"),
    @NamedQuery(name = "Userinfo.findByLastname", query = "SELECT u FROM Userinfo u WHERE u.lastname = :lastname"),
    @NamedQuery(name = "Userinfo.findByPassword", query = "SELECT u FROM Userinfo u WHERE u.password = :password"),
    @NamedQuery(name = "Userinfo.findByGender", query = "SELECT u FROM Userinfo u WHERE u.gender = :gender"),
    @NamedQuery(name = "Userinfo.findByAge", query = "SELECT u FROM Userinfo u WHERE u.age = :age"),
    @NamedQuery(name = "Userinfo.findByDob", query = "SELECT u FROM Userinfo u WHERE u.dob = :dob"),
    @NamedQuery(name = "Userinfo.findByHomePhone", query = "SELECT u FROM Userinfo u WHERE u.homePhone = :homePhone"),
    @NamedQuery(name = "Userinfo.findByMobile", query = "SELECT u FROM Userinfo u WHERE u.mobile = :mobile"),
    @NamedQuery(name = "Userinfo.findByEmail", query = "SELECT u FROM Userinfo u WHERE u.email = :email"),
    @NamedQuery(name = "Userinfo.findByIdentityDocType", query = "SELECT u FROM Userinfo u WHERE u.identityDocType = :identityDocType"),
    @NamedQuery(name = "Userinfo.findByIdentityNo", query = "SELECT u FROM Userinfo u WHERE u.identityNo = :identityNo")})
public class Userinfo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "userId")
    private Integer userId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "firstname")
    private String firstname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "lastname")
    private String lastname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "gender")
    private String gender;
    @Basic(optional = false)
    @NotNull
    @Column(name = "age")
    private int age;
    @Column(name = "dob")
    @Temporal(TemporalType.DATE)
    private Date dob;
    @Size(max = 15)
    @Column(name = "homePhone")
    private String homePhone;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mobile")
    private int mobile;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "identityDocType")
    private String identityDocType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "identityNo")
    private String identityNo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Medicalappointment> medicalappointmentList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Address> addressList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Skilledperson> skilledpersonList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Clubmembership> clubmembershipList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Seniorcitizen> seniorcitizenList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userid", fetch = FetchType.LAZY)
    private List<Tax> taxList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Bloodorganrequest> bloodorganrequestList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Legalcomplains> legalcomplainsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Complains> complainsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Userimage> userimageList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userid", fetch = FetchType.LAZY)
    private List<Property> propertyList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Onlineapplication> onlineapplicationList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId", fetch = FetchType.LAZY)
    private List<Payment> paymentList;

    public Userinfo() {
    }

    public Userinfo(Integer userId) {
        this.userId = userId;
    }

    public Userinfo(Integer userId, String firstname, String lastname, String password, String gender, int age, int mobile, String email, String identityDocType, String identityNo) {
        this.userId = userId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.password = password;
        this.gender = gender;
        this.age = age;
        this.mobile = mobile;
        this.email = email;
        this.identityDocType = identityDocType;
        this.identityNo = identityNo;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentityDocType() {
        return identityDocType;
    }

    public void setIdentityDocType(String identityDocType) {
        this.identityDocType = identityDocType;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    @XmlTransient
    public List<Medicalappointment> getMedicalappointmentList() {
        return medicalappointmentList;
    }

    public void setMedicalappointmentList(List<Medicalappointment> medicalappointmentList) {
        this.medicalappointmentList = medicalappointmentList;
    }

    @XmlTransient
    public List<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<Address> addressList) {
        this.addressList = addressList;
    }

    @XmlTransient
    public List<Skilledperson> getSkilledpersonList() {
        return skilledpersonList;
    }

    public void setSkilledpersonList(List<Skilledperson> skilledpersonList) {
        this.skilledpersonList = skilledpersonList;
    }

    @XmlTransient
    public List<Clubmembership> getClubmembershipList() {
        return clubmembershipList;
    }

    public void setClubmembershipList(List<Clubmembership> clubmembershipList) {
        this.clubmembershipList = clubmembershipList;
    }

    @XmlTransient
    public List<Seniorcitizen> getSeniorcitizenList() {
        return seniorcitizenList;
    }

    public void setSeniorcitizenList(List<Seniorcitizen> seniorcitizenList) {
        this.seniorcitizenList = seniorcitizenList;
    }

    @XmlTransient
    public List<Tax> getTaxList() {
        return taxList;
    }

    public void setTaxList(List<Tax> taxList) {
        this.taxList = taxList;
    }

    @XmlTransient
    public List<Bloodorganrequest> getBloodorganrequestList() {
        return bloodorganrequestList;
    }

    public void setBloodorganrequestList(List<Bloodorganrequest> bloodorganrequestList) {
        this.bloodorganrequestList = bloodorganrequestList;
    }

    @XmlTransient
    public List<Legalcomplains> getLegalcomplainsList() {
        return legalcomplainsList;
    }

    public void setLegalcomplainsList(List<Legalcomplains> legalcomplainsList) {
        this.legalcomplainsList = legalcomplainsList;
    }

    @XmlTransient
    public List<Complains> getComplainsList() {
        return complainsList;
    }

    public void setComplainsList(List<Complains> complainsList) {
        this.complainsList = complainsList;
    }

    @XmlTransient
    public List<Userimage> getUserimageList() {
        return userimageList;
    }

    public void setUserimageList(List<Userimage> userimageList) {
        this.userimageList = userimageList;
    }

    @XmlTransient
    public List<Property> getPropertyList() {
        return propertyList;
    }

    public void setPropertyList(List<Property> propertyList) {
        this.propertyList = propertyList;
    }

    @XmlTransient
    public List<Onlineapplication> getOnlineapplicationList() {
        return onlineapplicationList;
    }

    public void setOnlineapplicationList(List<Onlineapplication> onlineapplicationList) {
        this.onlineapplicationList = onlineapplicationList;
    }

    @XmlTransient
    public List<Payment> getPaymentList() {
        return paymentList;
    }

    public void setPaymentList(List<Payment> paymentList) {
        this.paymentList = paymentList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userId != null ? userId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userinfo)) {
            return false;
        }
        Userinfo other = (Userinfo) object;
        if ((this.userId == null && other.userId != null) || (this.userId != null && !this.userId.equals(other.userId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Userinfo[ userId=" + userId + " ]";
    }

}
