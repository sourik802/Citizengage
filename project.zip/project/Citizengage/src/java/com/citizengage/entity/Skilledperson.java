/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "skilledperson")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Skilledperson.findAll", query = "SELECT s FROM Skilledperson s"),
    @NamedQuery(name = "Skilledperson.findBySpid", query = "SELECT s FROM Skilledperson s WHERE s.spid = :spid"),
    @NamedQuery(name = "Skilledperson.findBySkilltype", query = "SELECT s FROM Skilledperson s WHERE s.skilltype = :skilltype"),
    @NamedQuery(name = "Skilledperson.findByRating", query = "SELECT s FROM Skilledperson s WHERE s.rating = :rating")})
public class Skilledperson implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "spid")
    private Integer spid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "skilltype")
    private String skilltype;
    @Column(name = "rating")
    private Integer rating;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Skilledperson() {
    }

    public Skilledperson(Integer spid) {
        this.spid = spid;
    }

    public Skilledperson(Integer spid, String skilltype) {
        this.spid = spid;
        this.skilltype = skilltype;
    }

    public Integer getSpid() {
        return spid;
    }

    public void setSpid(Integer spid) {
        this.spid = spid;
    }

    public String getSkilltype() {
        return skilltype;
    }

    public void setSkilltype(String skilltype) {
        this.skilltype = skilltype;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (spid != null ? spid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Skilledperson)) {
            return false;
        }
        Skilledperson other = (Skilledperson) object;
        if ((this.spid == null && other.spid != null) || (this.spid != null && !this.spid.equals(other.spid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Skilledperson[ spid=" + spid + " ]";
    }

}
