/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "doctor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Doctor.findAll", query = "SELECT d FROM Doctor d"),
    @NamedQuery(name = "Doctor.findByDocId", query = "SELECT d FROM Doctor d WHERE d.docId = :docId"),
    @NamedQuery(name = "Doctor.findByDocname", query = "SELECT d FROM Doctor d WHERE d.docname = :docname"),
    @NamedQuery(name = "Doctor.findByRegistration", query = "SELECT d FROM Doctor d WHERE d.registration = :registration"),
    @NamedQuery(name = "Doctor.findByQualification", query = "SELECT d FROM Doctor d WHERE d.qualification = :qualification"),
    @NamedQuery(name = "Doctor.findBySpecialization", query = "SELECT d FROM Doctor d WHERE d.specialization = :specialization"),
    @NamedQuery(name = "Doctor.findByIsfromhospital", query = "SELECT d FROM Doctor d WHERE d.isfromhospital = :isfromhospital"),
    @NamedQuery(name = "Doctor.findByAssochospital", query = "SELECT d FROM Doctor d WHERE d.assochospital = :assochospital"),
    @NamedQuery(name = "Doctor.findByExperience", query = "SELECT d FROM Doctor d WHERE d.experience = :experience"),
    @NamedQuery(name = "Doctor.findByPhone", query = "SELECT d FROM Doctor d WHERE d.phone = :phone"),
    @NamedQuery(name = "Doctor.findByTimings", query = "SELECT d FROM Doctor d WHERE d.timings = :timings")})
public class Doctor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "docId")
    private Integer docId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "docname")
    private String docname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "registration")
    private String registration;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "qualification")
    private String qualification;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "specialization")
    private String specialization;
    @Column(name = "isfromhospital")
    private Boolean isfromhospital;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "assochospital")
    private String assochospital;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "experience")
    private Float experience;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "phone")
    private String phone;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "timings")
    private String timings;
    @JoinColumn(name = "addrId", referencedColumnName = "addrID")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Address addrId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "docId", fetch = FetchType.EAGER)
    private List<DoctorhospitalRef> doctorhospitalRefList;

    public Doctor() {
    }

    public Doctor(Integer docId) {
        this.docId = docId;
    }

    public Doctor(Integer docId, String docname, String registration, String qualification, String specialization, String assochospital, String phone, String timings) {
        this.docId = docId;
        this.docname = docname;
        this.registration = registration;
        this.qualification = qualification;
        this.specialization = specialization;
        this.assochospital = assochospital;
        this.phone = phone;
        this.timings = timings;
    }

    public Integer getDocId() {
        return docId;
    }

    public void setDocId(Integer docId) {
        this.docId = docId;
    }

    public String getDocname() {
        return docname;
    }

    public void setDocname(String docname) {
        this.docname = docname;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Boolean getIsfromhospital() {
        return isfromhospital;
    }

    public void setIsfromhospital(Boolean isfromhospital) {
        this.isfromhospital = isfromhospital;
    }

    public String getAssochospital() {
        return assochospital;
    }

    public void setAssochospital(String assochospital) {
        this.assochospital = assochospital;
    }

    public Float getExperience() {
        return experience;
    }

    public void setExperience(Float experience) {
        this.experience = experience;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTimings() {
        return timings;
    }

    public void setTimings(String timings) {
        this.timings = timings;
    }

    public Address getAddrId() {
        return addrId;
    }

    public void setAddrId(Address addrId) {
        this.addrId = addrId;
    }

    @XmlTransient
    public List<DoctorhospitalRef> getDoctorhospitalRefList() {
        return doctorhospitalRefList;
    }

    public void setDoctorhospitalRefList(List<DoctorhospitalRef> doctorhospitalRefList) {
        this.doctorhospitalRefList = doctorhospitalRefList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (docId != null ? docId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Doctor)) {
            return false;
        }
        Doctor other = (Doctor) object;
        if ((this.docId == null && other.docId != null) || (this.docId != null && !this.docId.equals(other.docId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Doctor[ docId=" + docId + " ]";
    }

}
