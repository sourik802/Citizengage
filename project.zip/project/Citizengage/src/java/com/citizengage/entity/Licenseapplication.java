/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "licenseapplication")
@DiscriminatorValue("License")
@PrimaryKeyJoinColumn(referencedColumnName = "applicationid")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Licenseapplication.findAll", query = "SELECT l FROM Licenseapplication l"),
    @NamedQuery(name = "Licenseapplication.findByApplicationid", query = "SELECT l FROM Licenseapplication l WHERE l.applicationid = :applicationid"),
    @NamedQuery(name = "Licenseapplication.findByApplicationtype", query = "SELECT l FROM Licenseapplication l WHERE l.applicationtype = :applicationtype"),
    @NamedQuery(name = "Licenseapplication.findByLicenseType", query = "SELECT l FROM Licenseapplication l WHERE l.licenseType = :licenseType"),
    @NamedQuery(name = "Licenseapplication.findByApplicationNo", query = "SELECT l FROM Licenseapplication l WHERE l.applicationNo = :applicationNo"),
    @NamedQuery(name = "Licenseapplication.findByRto", query = "SELECT l FROM Licenseapplication l WHERE l.rto = :rto"),
    @NamedQuery(name = "Licenseapplication.findByGender", query = "SELECT l FROM Licenseapplication l WHERE l.gender = :gender"),
    @NamedQuery(name = "Licenseapplication.findByDob", query = "SELECT l FROM Licenseapplication l WHERE l.dob = :dob"),
    @NamedQuery(name = "Licenseapplication.findByGuardianname", query = "SELECT l FROM Licenseapplication l WHERE l.guardianname = :guardianname"),
    @NamedQuery(name = "Licenseapplication.findByCitizenstatus", query = "SELECT l FROM Licenseapplication l WHERE l.citizenstatus = :citizenstatus"),
    @NamedQuery(name = "Licenseapplication.findByQualification", query = "SELECT l FROM Licenseapplication l WHERE l.qualification = :qualification"),
    @NamedQuery(name = "Licenseapplication.findByIdentification", query = "SELECT l FROM Licenseapplication l WHERE l.identification = :identification"),
    @NamedQuery(name = "Licenseapplication.findByBloodgrp", query = "SELECT l FROM Licenseapplication l WHERE l.bloodgrp = :bloodgrp"),
    @NamedQuery(name = "Licenseapplication.findByVehicletype", query = "SELECT l FROM Licenseapplication l WHERE l.vehicletype = :vehicletype")})
public class Licenseapplication extends Onlineapplication {

    private static final long serialVersionUID = 1L;

    @Size(max = 10)
    @Column(name = "applicationtype")
    private String applicationtype;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "licenseType")
    private String licenseType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "applicationNo")
    private String applicationNo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "rto")
    private String rto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "gender")
    private String gender;
    @Column(name = "dob")
    @Temporal(TemporalType.DATE)
    private Date dob;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "guardianname")
    private String guardianname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "citizenstatus")
    private String citizenstatus;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "qualification")
    private String qualification;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "identification")
    private String identification;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "bloodgrp")
    private String bloodgrp;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "vehicletype")
    private String vehicletype;
    @Lob
    @Column(name = "addrproof")
    private byte[] addrproof;
    @Lob
    @Column(name = "qualcert")
    private byte[] qualcert;
    @JoinColumn(name = "applicationid", referencedColumnName = "applicationid", insertable = false, updatable = false)
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    private Onlineapplication onlineapplication;

    public Licenseapplication() {
    }

    public Licenseapplication(Integer applicationid) {
        super(applicationid);
    }

    public Licenseapplication(Integer applicationid, String licenseType, String applicationNo, String rto, String gender, String guardianname, String citizenstatus, String qualification, String identification, String bloodgrp, String vehicletype) {
        super(applicationid);
        this.licenseType = licenseType;
        this.applicationNo = applicationNo;
        this.rto = rto;
        this.gender = gender;
        this.guardianname = guardianname;
        this.citizenstatus = citizenstatus;
        this.qualification = qualification;
        this.identification = identification;
        this.bloodgrp = bloodgrp;
        this.vehicletype = vehicletype;
    }

    public String getApplicationtype() {
        return applicationtype;
    }

    public void setApplicationtype(String applicationtype) {
        this.applicationtype = applicationtype;
    }

    public String getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    public String getApplicationNo() {
        return applicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getRto() {
        return rto;
    }

    public void setRto(String rto) {
        this.rto = rto;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getGuardianname() {
        return guardianname;
    }

    public void setGuardianname(String guardianname) {
        this.guardianname = guardianname;
    }

    public String getCitizenstatus() {
        return citizenstatus;
    }

    public void setCitizenstatus(String citizenstatus) {
        this.citizenstatus = citizenstatus;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getBloodgrp() {
        return bloodgrp;
    }

    public void setBloodgrp(String bloodgrp) {
        this.bloodgrp = bloodgrp;
    }

    public String getVehicletype() {
        return vehicletype;
    }

    public void setVehicletype(String vehicletype) {
        this.vehicletype = vehicletype;
    }

    public byte[] getAddrproof() {
        return addrproof;
    }

    public void setAddrproof(byte[] addrproof) {
        this.addrproof = addrproof;
    }

    public byte[] getQualcert() {
        return qualcert;
    }

    public void setQualcert(byte[] qualcert) {
        this.qualcert = qualcert;
    }

    public Onlineapplication getOnlineapplication() {
        return onlineapplication;
    }

    public void setOnlineapplication(Onlineapplication onlineapplication) {
        this.onlineapplication = onlineapplication;
    }

}
