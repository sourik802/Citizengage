/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "hospital")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hospital.findAll", query = "SELECT h FROM Hospital h"),
    @NamedQuery(name = "Hospital.findByHospitalId", query = "SELECT h FROM Hospital h WHERE h.hospitalId = :hospitalId"),
    @NamedQuery(name = "Hospital.findByHospitalname", query = "SELECT h FROM Hospital h WHERE h.hospitalname = :hospitalname"),
    @NamedQuery(name = "Hospital.findByRegistration", query = "SELECT h FROM Hospital h WHERE h.registration = :registration"),
    @NamedQuery(name = "Hospital.findByHosptype", query = "SELECT h FROM Hospital h WHERE h.hosptype = :hosptype"),
    @NamedQuery(name = "Hospital.findByAmbulanceAvailable", query = "SELECT h FROM Hospital h WHERE h.ambulanceAvailable = :ambulanceAvailable"),
    @NamedQuery(name = "Hospital.findByEmergencyAvailable", query = "SELECT h FROM Hospital h WHERE h.emergencyAvailable = :emergencyAvailable"),
    @NamedQuery(name = "Hospital.findByPhone", query = "SELECT h FROM Hospital h WHERE h.phone = :phone"),
    @NamedQuery(name = "Hospital.findByTimings", query = "SELECT h FROM Hospital h WHERE h.timings = :timings"),
    @NamedQuery(name = "Hospital.findBySpecialities", query = "SELECT h FROM Hospital h WHERE h.specialities = :specialities")})
public class Hospital implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "hospitalId")
    private Integer hospitalId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "hospitalname")
    private String hospitalname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "registration")
    private String registration;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "hosptype")
    private String hosptype;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ambulanceAvailable")
    private boolean ambulanceAvailable;
    @Basic(optional = false)
    @NotNull
    @Column(name = "emergencyAvailable")
    private boolean emergencyAvailable;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "phone")
    private String phone;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "timings")
    private String timings;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "specialities")
    private String specialities;
    @JoinColumn(name = "addrId", referencedColumnName = "addrID")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Address addrId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hospitalid", fetch = FetchType.LAZY)
    private List<DoctorhospitalRef> doctorhospitalRefList;

    public Hospital() {
    }

    public Hospital(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Hospital(Integer hospitalId, String hospitalname, String registration, String hosptype, boolean ambulanceAvailable, boolean emergencyAvailable, String phone, String timings, String specialities) {
        this.hospitalId = hospitalId;
        this.hospitalname = hospitalname;
        this.registration = registration;
        this.hosptype = hosptype;
        this.ambulanceAvailable = ambulanceAvailable;
        this.emergencyAvailable = emergencyAvailable;
        this.phone = phone;
        this.timings = timings;
        this.specialities = specialities;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getHospitalname() {
        return hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        this.hospitalname = hospitalname;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public String getHosptype() {
        return hosptype;
    }

    public void setHosptype(String hosptype) {
        this.hosptype = hosptype;
    }

    public boolean getAmbulanceAvailable() {
        return ambulanceAvailable;
    }

    public void setAmbulanceAvailable(boolean ambulanceAvailable) {
        this.ambulanceAvailable = ambulanceAvailable;
    }

    public boolean getEmergencyAvailable() {
        return emergencyAvailable;
    }

    public void setEmergencyAvailable(boolean emergencyAvailable) {
        this.emergencyAvailable = emergencyAvailable;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTimings() {
        return timings;
    }

    public void setTimings(String timings) {
        this.timings = timings;
    }

    public String getSpecialities() {
        return specialities;
    }

    public void setSpecialities(String specialities) {
        this.specialities = specialities;
    }

    public Address getAddrId() {
        return addrId;
    }

    public void setAddrId(Address addrId) {
        this.addrId = addrId;
    }

    @XmlTransient
    public List<DoctorhospitalRef> getDoctorhospitalRefList() {
        return doctorhospitalRefList;
    }

    public void setDoctorhospitalRefList(List<DoctorhospitalRef> doctorhospitalRefList) {
        this.doctorhospitalRefList = doctorhospitalRefList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (hospitalId != null ? hospitalId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hospital)) {
            return false;
        }
        Hospital other = (Hospital) object;
        if ((this.hospitalId == null && other.hospitalId != null) || (this.hospitalId != null && !this.hospitalId.equals(other.hospitalId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Hospital[ hospitalId=" + hospitalId + " ]";
    }

}
