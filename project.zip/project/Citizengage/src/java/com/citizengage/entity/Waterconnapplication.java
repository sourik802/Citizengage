/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "waterconnapplication")
@DiscriminatorValue("Water")
@PrimaryKeyJoinColumn(referencedColumnName = "applicationid")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Waterconnapplication.findAll", query = "SELECT w FROM Waterconnapplication w"),
    @NamedQuery(name = "Waterconnapplication.findByApplicationid", query = "SELECT w FROM Waterconnapplication w WHERE w.applicationid = :applicationid"),
    @NamedQuery(name = "Waterconnapplication.findByApplicationtype", query = "SELECT w FROM Waterconnapplication w WHERE w.applicationtype = :applicationtype"),
    @NamedQuery(name = "Waterconnapplication.findByWard", query = "SELECT w FROM Waterconnapplication w WHERE w.ward = :ward"),
    @NamedQuery(name = "Waterconnapplication.findByTenant", query = "SELECT w FROM Waterconnapplication w WHERE w.tenant = :tenant"),
    @NamedQuery(name = "Waterconnapplication.findByOwnerName", query = "SELECT w FROM Waterconnapplication w WHERE w.ownerName = :ownerName"),
    @NamedQuery(name = "Waterconnapplication.findByOwnerAddress", query = "SELECT w FROM Waterconnapplication w WHERE w.ownerAddress = :ownerAddress"),
    @NamedQuery(name = "Waterconnapplication.findByConntype", query = "SELECT w FROM Waterconnapplication w WHERE w.conntype = :conntype"),
    @NamedQuery(name = "Waterconnapplication.findByWatersize", query = "SELECT w FROM Waterconnapplication w WHERE w.watersize = :watersize"),
    @NamedQuery(name = "Waterconnapplication.findBySeweragesize", query = "SELECT w FROM Waterconnapplication w WHERE w.seweragesize = :seweragesize"),
    @NamedQuery(name = "Waterconnapplication.findByIdentityNo", query = "SELECT w FROM Waterconnapplication w WHERE w.identityNo = :identityNo")})
public class Waterconnapplication extends Onlineapplication {

    private static final long serialVersionUID = 1L;

    @Size(max = 10)
    @Column(name = "applicationtype")
    private String applicationtype;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ward")
    private String ward;
    @Column(name = "tenant")
    private Boolean tenant;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ownerName")
    private String ownerName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "ownerAddress")
    private String ownerAddress;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "conntype")
    private String conntype;
    @Column(name = "watersize")
    private Integer watersize;
    @Column(name = "seweragesize")
    private Integer seweragesize;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "identityNo")
    private String identityNo;
    @Lob
    @Column(name = "allotmentLtr")
    private byte[] allotmentLtr;
    @Lob
    @Column(name = "saleDeed")
    private byte[] saleDeed;
    @JoinColumn(name = "applicationid", referencedColumnName = "applicationid", insertable = false, updatable = false)
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    private Onlineapplication onlineapplication;

    public Waterconnapplication() {
    }

    public Waterconnapplication(Integer applicationid) {
        super(applicationid);
    }

    public Waterconnapplication(Integer applicationid, String ward, String ownerName, String ownerAddress, String conntype, String identityNo) {
        super(applicationid);
        this.ward = ward;
        this.ownerName = ownerName;
        this.ownerAddress = ownerAddress;
        this.conntype = conntype;
        this.identityNo = identityNo;
    }

    public String getApplicationtype() {
        return applicationtype;
    }

    public void setApplicationtype(String applicationtype) {
        this.applicationtype = applicationtype;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public Boolean getTenant() {
        return tenant;
    }

    public void setTenant(Boolean tenant) {
        this.tenant = tenant;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public String getConntype() {
        return conntype;
    }

    public void setConntype(String conntype) {
        this.conntype = conntype;
    }

    public Integer getWatersize() {
        return watersize;
    }

    public void setWatersize(Integer watersize) {
        this.watersize = watersize;
    }

    public Integer getSeweragesize() {
        return seweragesize;
    }

    public void setSeweragesize(Integer seweragesize) {
        this.seweragesize = seweragesize;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public byte[] getAllotmentLtr() {
        return allotmentLtr;
    }

    public void setAllotmentLtr(byte[] allotmentLtr) {
        this.allotmentLtr = allotmentLtr;
    }

    public byte[] getSaleDeed() {
        return saleDeed;
    }

    public void setSaleDeed(byte[] saleDeed) {
        this.saleDeed = saleDeed;
    }

    public Onlineapplication getOnlineapplication() {
        return onlineapplication;
    }

    public void setOnlineapplication(Onlineapplication onlineapplication) {
        this.onlineapplication = onlineapplication;
    }

}
