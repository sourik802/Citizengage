/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "medicalappointment")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Medicalappointment.findAll", query = "SELECT m FROM Medicalappointment m"),
    @NamedQuery(name = "Medicalappointment.findByAppointId", query = "SELECT m FROM Medicalappointment m WHERE m.appointId = :appointId"),
    @NamedQuery(name = "Medicalappointment.findByIshospialappointment", query = "SELECT m FROM Medicalappointment m WHERE m.ishospialappointment = :ishospialappointment"),
    @NamedQuery(name = "Medicalappointment.findByDocId", query = "SELECT m FROM Medicalappointment m WHERE m.docId = :docId"),
    @NamedQuery(name = "Medicalappointment.findByHospitalId", query = "SELECT m FROM Medicalappointment m WHERE m.hospitalId = :hospitalId"),
    @NamedQuery(name = "Medicalappointment.findByBookingDt", query = "SELECT m FROM Medicalappointment m WHERE m.bookingDt = :bookingDt"),
    @NamedQuery(name = "Medicalappointment.findByAppointmenttime", query = "SELECT m FROM Medicalappointment m WHERE m.appointmenttime = :appointmenttime")})
public class Medicalappointment implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "appointId")
    private Integer appointId;
    @Column(name = "ishospialappointment")
    private Boolean ishospialappointment;
    @Column(name = "docId")
    private Integer docId;
    @Column(name = "hospitalId")
    private Integer hospitalId;
    @Column(name = "bookingDt")
    @Temporal(TemporalType.DATE)
    private Date bookingDt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "appointmenttime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date appointmenttime;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Medicalappointment() {
    }

    public Medicalappointment(Integer appointId) {
        this.appointId = appointId;
    }

    public Medicalappointment(Integer appointId, Date appointmenttime) {
        this.appointId = appointId;
        this.appointmenttime = appointmenttime;
    }

    public Integer getAppointId() {
        return appointId;
    }

    public void setAppointId(Integer appointId) {
        this.appointId = appointId;
    }

    public Boolean getIshospialappointment() {
        return ishospialappointment;
    }

    public void setIshospialappointment(Boolean ishospialappointment) {
        this.ishospialappointment = ishospialappointment;
    }

    public Integer getDocId() {
        return docId;
    }

    public void setDocId(Integer docId) {
        this.docId = docId;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Date getBookingDt() {
        return bookingDt;
    }

    public void setBookingDt(Date bookingDt) {
        this.bookingDt = bookingDt;
    }

    public Date getAppointmenttime() {
        return appointmenttime;
    }

    public void setAppointmenttime(Date appointmenttime) {
        this.appointmenttime = appointmenttime;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (appointId != null ? appointId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Medicalappointment)) {
            return false;
        }
        Medicalappointment other = (Medicalappointment) object;
        if ((this.appointId == null && other.appointId != null) || (this.appointId != null && !this.appointId.equals(other.appointId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Medicalappointment[ appointId=" + appointId + " ]";
    }

}
