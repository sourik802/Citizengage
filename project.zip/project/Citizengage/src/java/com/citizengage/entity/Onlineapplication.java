/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "onlineapplication")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "applicationtype", discriminatorType = DiscriminatorType.STRING)
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Onlineapplication.findAll", query = "SELECT o FROM Onlineapplication o"),
    @NamedQuery(name = "Onlineapplication.findByApplicationid", query = "SELECT o FROM Onlineapplication o WHERE o.applicationid = :applicationid"),
    @NamedQuery(name = "Onlineapplication.findByApplicantname", query = "SELECT o FROM Onlineapplication o WHERE o.applicantname = :applicantname"),
    @NamedQuery(name = "Onlineapplication.findByAddrid", query = "SELECT o FROM Onlineapplication o WHERE o.addrid = :addrid"),
    @NamedQuery(name = "Onlineapplication.findByApplicationtype", query = "SELECT o FROM Onlineapplication o WHERE o.applicationtype = :applicationtype"),
    @NamedQuery(name = "Onlineapplication.findBySubmitdate", query = "SELECT o FROM Onlineapplication o WHERE o.submitdate = :submitdate"),
    @NamedQuery(name = "Onlineapplication.findByStatus", query = "SELECT o FROM Onlineapplication o WHERE o.status = :status"),
    @NamedQuery(name = "Onlineapplication.findByIsactive", query = "SELECT o FROM Onlineapplication o WHERE o.isactive = :isactive")})
public class Onlineapplication implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "applicationid")
    private Integer applicationid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "applicantname")
    private String applicantname;
    @Basic(optional = false)
    @NotNull
    @Column(name = "addrid")
    private int addrid;
    @Size(max = 10)
    @Column(name = "applicationtype")
    private String applicationtype;
    @Basic(optional = false)
    @NotNull
    @Column(name = "submitdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submitdate;
    @Size(max = 5)
    @Column(name = "status")
    private String status;
    @Column(name = "isactive")
    private Boolean isactive;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "onlineapplication", fetch = FetchType.LAZY)
    private Waterconnapplication waterconnapplication;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "applicationid", fetch = FetchType.LAZY)
    private List<Applicationfiles> applicationfilesList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "onlineapplication", fetch = FetchType.LAZY)
    private Electricconnapplication electricconnapplication;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "onlineapplication", fetch = FetchType.LAZY)
    private Licenseapplication licenseapplication;

    public Onlineapplication() {
    }

    public Onlineapplication(Integer applicationid) {
        this.applicationid = applicationid;
    }

    public Onlineapplication(Integer applicationid, String applicantname, int addrid, Date submitdate) {
        this.applicationid = applicationid;
        this.applicantname = applicantname;
        this.addrid = addrid;
        this.submitdate = submitdate;
    }

    public Integer getApplicationid() {
        return applicationid;
    }

    public void setApplicationid(Integer applicationid) {
        this.applicationid = applicationid;
    }

    public String getApplicantname() {
        return applicantname;
    }

    public void setApplicantname(String applicantname) {
        this.applicantname = applicantname;
    }

    public int getAddrid() {
        return addrid;
    }

    public void setAddrid(int addrid) {
        this.addrid = addrid;
    }

    public String getApplicationtype() {
        return applicationtype;
    }

    public void setApplicationtype(String applicationtype) {
        this.applicationtype = applicationtype;
    }

    public Date getSubmitdate() {
        return submitdate;
    }

    public void setSubmitdate(Date submitdate) {
        this.submitdate = submitdate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getIsactive() {
        return isactive;
    }

    public void setIsactive(Boolean isactive) {
        this.isactive = isactive;
    }

    public Waterconnapplication getWaterconnapplication() {
        return waterconnapplication;
    }

    public void setWaterconnapplication(Waterconnapplication waterconnapplication) {
        this.waterconnapplication = waterconnapplication;
    }

    @XmlTransient
    public List<Applicationfiles> getApplicationfilesList() {
        return applicationfilesList;
    }

    public void setApplicationfilesList(List<Applicationfiles> applicationfilesList) {
        this.applicationfilesList = applicationfilesList;
    }

    public Electricconnapplication getElectricconnapplication() {
        return electricconnapplication;
    }

    public void setElectricconnapplication(Electricconnapplication electricconnapplication) {
        this.electricconnapplication = electricconnapplication;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    public Licenseapplication getLicenseapplication() {
        return licenseapplication;
    }

    public void setLicenseapplication(Licenseapplication licenseapplication) {
        this.licenseapplication = licenseapplication;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (applicationid != null ? applicationid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Onlineapplication)) {
            return false;
        }
        Onlineapplication other = (Onlineapplication) object;
        if ((this.applicationid == null && other.applicationid != null) || (this.applicationid != null && !this.applicationid.equals(other.applicationid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Onlineapplication[ applicationid=" + applicationid + " ]";
    }

}
