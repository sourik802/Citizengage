/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sourik
 */
@Entity
@Table(name = "complains")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Complains.findAll", query = "SELECT c FROM Complains c"),
    @NamedQuery(name = "Complains.findByComplainID", query = "SELECT c FROM Complains c WHERE c.complainID = :complainID"),
    @NamedQuery(name = "Complains.findBySelection", query = "SELECT c FROM Complains c WHERE c.selection = :selection"),
    @NamedQuery(name = "Complains.findByRaiseDt", query = "SELECT c FROM Complains c WHERE c.raiseDt = :raiseDt"),
    @NamedQuery(name = "Complains.findByStatus", query = "SELECT c FROM Complains c WHERE c.status = :status"),
    @NamedQuery(name = "Complains.findByIsActive", query = "SELECT c FROM Complains c WHERE c.isActive = :isActive"),
    @NamedQuery(name = "Complains.findByClosingDt", query = "SELECT c FROM Complains c WHERE c.closingDt = :closingDt"),
    @NamedQuery(name = "Complains.findByDetails", query = "SELECT c FROM Complains c WHERE c.details = :details"),
    @NamedQuery(name = "Complains.findByAssignee", query = "SELECT c FROM Complains c WHERE c.assignee = :assignee"),
    @NamedQuery(name = "Complains.findByAssignedDept", query = "SELECT c FROM Complains c WHERE c.assignedDept = :assignedDept")})
public class Complains implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "complainID")
    private Integer complainID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "selection")
    private String selection;
    @Column(name = "raiseDt")
    @Temporal(TemporalType.DATE)
    private Date raiseDt;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "status")
    private String status;
    @Column(name = "isActive")
    private Boolean isActive;
    @Column(name = "closingDt")
    @Temporal(TemporalType.DATE)
    private Date closingDt;
    @Size(max = 500)
    @Column(name = "details")
    private String details;
    @Size(max = 30)
    @Column(name = "assignee")
    private String assignee;
    @Size(max = 25)
    @Column(name = "assignedDept")
    private String assignedDept;
    @JoinColumn(name = "userId", referencedColumnName = "userId")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Userinfo userId;

    public Complains() {
    }

    public Complains(Integer complainID) {
        this.complainID = complainID;
    }

    public Complains(Integer complainID, String selection, String status) {
        this.complainID = complainID;
        this.selection = selection;
        this.status = status;
    }

    public Integer getComplainID() {
        return complainID;
    }

    public void setComplainID(Integer complainID) {
        this.complainID = complainID;
    }

    public String getSelection() {
        return selection;
    }

    public void setSelection(String selection) {
        this.selection = selection;
    }

    public Date getRaiseDt() {
        return raiseDt;
    }

    public void setRaiseDt(Date raiseDt) {
        this.raiseDt = raiseDt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Date getClosingDt() {
        return closingDt;
    }

    public void setClosingDt(Date closingDt) {
        this.closingDt = closingDt;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getAssignedDept() {
        return assignedDept;
    }

    public void setAssignedDept(String assignedDept) {
        this.assignedDept = assignedDept;
    }

    public Userinfo getUserId() {
        return userId;
    }

    public void setUserId(Userinfo userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (complainID != null ? complainID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Complains)) {
            return false;
        }
        Complains other = (Complains) object;
        if ((this.complainID == null && other.complainID != null) || (this.complainID != null && !this.complainID.equals(other.complainID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.citizengage.entity.Complains[ complainID=" + complainID + " ]";
    }

}
