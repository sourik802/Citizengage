/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.utility;

import com.citizengage.entity.Userinfo;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import org.primefaces.model.DefaultUploadedFile;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author Sourik
 */
public class ImageUpload {

    @PersistenceContext(name = "CitizengagePU", unitName = "CitizengagePU", type = PersistenceContextType.EXTENDED)
    static EntityManager em;

    public void uploadImage() {
        UploadedFile file = new DefaultUploadedFile();
        try {
            InputStream is = file.getInputstream();

        } catch (IOException ex) {
            Logger.getLogger(ImageUpload.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {
        try {

            em.getTransaction().begin();
            Userinfo user = em.find(Userinfo.class, 1);
            if (user != null) {
                System.out.println("user found " + user.getFirstname());
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            System.err.println("error occurred " + e);
        }
    }
}
