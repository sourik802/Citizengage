/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.utility;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import org.primefaces.component.fileupload.FileUploadRenderer;

/**
 *
 * @author 258290
 */
public class CEFileUploadRenderer extends FileUploadRenderer{
     @Override
    public void decode(FacesContext context, UIComponent component) {
        System.out.println("within decode of CEFileUploadRenderer");
        if (context.getExternalContext().getRequestContentType().toLowerCase().startsWith("multipart/")) {
            super.decode(context, component);
        }
    }
}
