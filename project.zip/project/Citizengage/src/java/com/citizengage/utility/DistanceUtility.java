/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citizengage.utility;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;

/**
 *
 * @author 258290
 */
public class DistanceUtility {

    public Double getDistance(String userPin, String destinationPin) {
        Double distance = 0.0;
        try {
            Double latLongs[] = getLatLongPositions(userPin);
            System.out.println("User Latitude: " + latLongs[0] + " and Longitude: " + latLongs[1]);
            Double latLongs1[] = getLatLongPositions(destinationPin);
            System.out.println("Destination Latitude: " + latLongs1[0] + " and Longitude: " + latLongs1[1]);
            distance = getDistance(latLongs, latLongs1);
        } catch (Exception ex) {
            Logger.getLogger(DistanceUtility.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return distance;
        }
    }

    public static Double[] getLatLongPositions(String address) throws Exception {
        int responseCode = 0;
        System.setProperty("http.proxyHost", "proxy.cognizant.com");
        System.setProperty("http.proxyPort", "6050");

        String api = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + URLEncoder.encode(address, "UTF-8") + "&sensor=true";
        URL url = new URL(api);
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
        httpConnection.connect();
        responseCode = httpConnection.getResponseCode();
        if (responseCode == 200) {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();;
            Document document = builder.parse(httpConnection.getInputStream());
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile("/GeocodeResponse/status");
            String status = (String) expr.evaluate(document, XPathConstants.STRING);
            if (status.equals("OK")) {
                expr = xpath.compile("//geometry/location/lat");
                Double latitude = (Double) expr.evaluate(document, XPathConstants.NUMBER);
                expr = xpath.compile("//geometry/location/lng");
                Double longitude = (Double) expr.evaluate(document, XPathConstants.NUMBER);
                return new Double[]{latitude, longitude};
            } else {
                throw new Exception("Error from the API - response status: " + status);
            }
        }
        return null;
    }

    public static void sortAddr(Double src[], Double trgt[]) {
        Location loc1 = new Location(src[0], src[1]);
        Location loc2 = new Location(trgt[0], trgt[1]);

        List<Location> loc = Arrays.asList(loc1, loc2);

        Collections.sort(loc, (a, b) -> a.lat < b.lat ? -1 : a.lat.equals(b.lat) ? 0 : 1);
        System.out.println("sorted locations ");
        loc.stream().map((o) -> (Location) o).forEach((l) -> {
            System.out.println(l.getLat() + " " + l.getLng());
        });
    }

    private static class Location {

        Double lat;
        Double lng;

        Location(Double l1, Double l2) {
            this.lat = l1;
            this.lng = l2;
        }

        public Double getLat() {
            return lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Double getLng() {
            return lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }
    }

    private static double getDistance(Double srcLatLng[], Double targetLatLng[]) {
        double lat1 = srcLatLng[0];
        double lon1 = srcLatLng[1];
        double lat2 = targetLatLng[0];
        double lon2 = targetLatLng[1];
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        dist = dist * 1.609344;
        return (dist);
    }

    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
 /*::	This function converts decimal degrees to radians						 :*/
 /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
 /*::	This function converts radians to decimal degrees						 :*/
 /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    private static double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
}
