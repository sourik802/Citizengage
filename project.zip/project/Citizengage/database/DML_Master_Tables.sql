INSERT INTO citizengagedb.userinfo (firstname, lastname, password, gender, age, dob, `homePhone`, mobile, email, `identityDocType`, `identityNo`, created_at, changed_at) 
	VALUES ('khh', 'kjhg', 'kjhkjh', 'M', 0, '2016-06-07', '878768', 87786, 'asds@sdfsdf.com', 'R', '876786', '2016-06-18 21:09:45.0', '2016-06-18 21:09:45.0');
INSERT INTO citizengagedb.userinfo (firstname, lastname, password, gender, age, dob, `homePhone`, mobile, email, `identityDocType`, `identityNo`, created_at, changed_at) 
	VALUES ('dfg', 'sdfd', 'dgd', 'T', 0, '2016-06-13', '333', 33333, 'dvdf@sdfdsf.com', 'A', '435345', '2016-06-18 21:49:08.0', '2016-06-18 21:49:08.0');
INSERT INTO citizengagedb.userinfo (firstname, lastname, password, gender, age, dob, `homePhone`, mobile, email, `identityDocType`, `identityNo`, created_at, changed_at) 
	VALUES ('sdf', 'dfgg', 'dsfsf', 'F', 0, '2016-06-07', '', 34323, 'sddfsdf@sdfd.com', 'V', '324324', '2016-06-18 22:09:28.0', '2016-06-18 22:09:28.0');
INSERT INTO citizengagedb.userinfo (firstname, lastname, password, gender, age, dob, `homePhone`, mobile, email, `identityDocType`, `identityNo`, created_at, changed_at) 
	VALUES ('cvbc', 'sdsd', 'asd', 'F', 0, '2016-06-07', '', 0, 'sdfs@dwwwd.com', 'V', '45345', '2016-06-18 22:25:23.0', '2016-06-18 22:25:23.0');



INSERT INTO citizengagedb.address (`userId`, `houseNo`, building, `streetNo`, `streetName`, locality, city, district, pin, rstate, `addrType`, created_at, changed_at) 
	VALUES (6, '876', 'Own Housing', '78', 'A Lane', 'Smart town', 'Kolkata', 'Kolkata', 767336, 'WB', 'R', '2016-06-18 21:09:45.0', '2016-06-19 12:18:40.0');
INSERT INTO citizengagedb.address (`userId`, `houseNo`, building, `streetNo`, `streetName`, locality, city, district, pin, rstate, `addrType`, created_at, changed_at) 
	VALUES (7, '432', 'D Villa', '12', 'PP Road', 'Salt Lake', 'Salt Lake', 'Bidhannagar', 786786, 'WB', 'R', '2016-06-18 21:49:08.0', '2016-06-19 12:20:33.0');
INSERT INTO citizengagedb.address (`userId`, `houseNo`, building, `streetNo`, `streetName`, locality, city, district, pin, rstate, `addrType`, created_at, changed_at) 
	VALUES (8, '345', 'Q Apartment', 'A22', 'St 64', 'Action Area I', 'Rajarhat', '24 PGN (N)', 700156, 'WB', 'R', '2016-06-18 22:09:28.0', '2016-06-19 12:22:22.0');
INSERT INTO citizengagedb.address (`userId`, `houseNo`, building, `streetNo`, `streetName`, locality, city, district, pin, rstate, `addrType`, created_at, changed_at) 
	VALUES (9, '8', 'khk', '8787', '', 'hjkhjk', 'hjkhjk', 'jkh', 77676, 'jkhjh', 'R', '2016-06-18 22:25:23.0', '2016-06-18 22:25:23.0');


INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('AAA NNNN', 'A12345', 'MBBS', 'Dentist', 5, false, 'ABC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('BBBB ASASA', 'A22345', 'MD', 'Gynecologist', 6, false, 'eee  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('QWERTY', 'A32345', 'MBBS MD', 'Dermatologist', 7, false, 'AC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('STRANGE', 'A42345', 'MBBS QR', 'Dermatologist', 5, false, 'C  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('POIUYT', 'A14345', 'MBBS PP', 'Cardiologist', 5, false, 'A  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('AAA MMMM', 'A52345', 'MBBS MD UIUI', 'Dentist', 5, false, 'ABCD  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('NNNN GGGG', 'A62345', 'MBBS BMS', 'Gynecologist', 5, false, 'ABCEEEE  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('BGTYHB', 'A12375', 'MBBS AR', 'Cardiologist', 6, false, 'EOE  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('MZMBCMN', 'A12845', 'MBBSQ', 'Neurologist', 5, false, 'WOW  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('USUSUSUS', 'A19345', 'MBBS OIT', 'Dermatologist', 9, false, 'APPPPOLLO  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('ASDAS', 'A12340', 'MBBS', 'ENT', 8, false, 'MRI  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('ZDXZC', 'A123411', 'MBBS', 'Cardiologist', 6, false, 'BMRI  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('POIIUYUITV HFHGF', 'R12345', 'MBBS', 'Neurologist', 5, false, 'ABC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('CXCXCAZA', '322345', 'MBBS', 'Urologist', 5, false, 'ABC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('VVVV', 'A12345999', 'MBBS', 'Dentist', 5, false, 'ABC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('GOOD', '012345', 'MBBS', 'Orthopedist', 7, false, 'ABC  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('BETTER', 'AB12345', 'MBBS', 'Urologist', 8, false, 'MMM  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('BEST', 'V12345', 'MBBS', 'Orthopedist', 5, false, 'ZZZ  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('GOD FATHER', 'TWO12345', 'MBBS', 'Urologist', 5, false, 'ALOPATH  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);
INSERT INTO citizengagedb.doctor (docname, registration, qualification, specialization, `addrId`, isfromhospital, assochospital, experience, phone, timings, created_at, changed_at) 
	VALUES ('WONDER', 'A9912345', 'MBBS', 'Orthopedist', 9, false, 'AYUR  Hospital', 12.0, '111111', '10 AM - 9 PM', DEFAULT, DEFAULT);




INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Encroachment', 'Footpath', NULL, '2016-06-19 19:31:51.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Encroachment', 'Road', NULL, '2016-06-19 19:31:51.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Encroachment', 'Ground', NULL, '2016-06-19 19:31:51.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Encroachment', 'Open Space', NULL, '2016-06-19 19:31:51.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Garbage', 'Collection not done', NULL, '2016-06-19 19:41:32.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Garbage', 'disposed improperly', NULL, '2016-06-19 19:41:32.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Garbage', 'wet and dry not segregated', NULL, '2016-06-19 19:41:32.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Sound pollution', 'outside limit', NULL, '2016-06-19 19:41:32.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Sound pollution', 'outside allowable time', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Pollution', 'air pollution in locality', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Pollution', 'Open Defecation', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Water Supply', 'scarcity of supply', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Water Supply', 'duration', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Water Supply', 'contaminated', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Water Supply', 'leakage', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Drainage', 'Uncovered drain', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Drainage', 'clogged drain', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Drainage', 'overflown', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Road and Footpath', 'potholes', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Road and Footpath', 'blocked', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Road and Footpath', 'encroached', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Hospital', 'No Service', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Hospital', 'Doctor unavailable', NULL, '2016-06-19 19:41:33.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Hospital', 'Medicine unavailable', NULL, '2016-06-19 19:50:28.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Health and Hygiene', 'Improper waste disposal', NULL, '2016-06-19 19:50:28.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Health and Hygiene', 'Pesticide spray', NULL, '2016-06-19 19:50:28.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Health and Hygiene', 'Garbage dump', NULL, '2016-06-19 19:50:28.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Health and Hygiene', 'Animal dead body', NULL, '2016-06-19 19:50:28.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Health and Hygiene', 'Area not cleaned', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Construction', 'Illegal construction', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Construction', 'Material dumped', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Construction', 'Blockage through scrap', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Animal Cruelty', 'Stray killing', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Animal Cruelty', 'Unauthorised capture', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Animal Cruelty', 'Deposition', NULL, '2016-06-19 19:50:29.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Gov Office', 'No response and service', NULL, '2016-06-19 19:51:05.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Gov Office', 'Delay in service', NULL, '2016-06-19 19:51:05.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Gov Office', 'Wrong file handling', NULL, '2016-06-19 19:51:05.0');
INSERT INTO citizengagedb.citycomplaints (`Category`, `SubCategory`, `Description`, created_at) 
	VALUES ('Others', 'Others', NULL, '2016-06-19 19:51:05.0');



