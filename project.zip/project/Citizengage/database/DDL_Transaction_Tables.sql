SET GLOBAL max_allowed_packet = 1024 * 1024 * 25;


CREATE TABLE userinfo (
     userId INT NOT NULL AUTO_INCREMENT,
     firstname varchar(30) NOT NULL,
     lastname varchar(30) NOT NULL,    
     password varchar(8) NOT NULL,
     gender varchar(1) NOT NULL,
     age int NOT NULL,
     dob date,
     homePhone varchar(15),
     mobile int NOT NULL,
     email varchar(25) NOT NULL,
     identityDocType varchar(1) NOT NULL,
     identityNo varchar(25) NOT NULL,     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (userId),
   CONSTRAINT email_unique UNIQUE (email)
) ;


CREATE TABLE userimage (
  imageid int(10) unsigned NOT NULL auto_increment,
  userId INT NOT NULL,
  image_name varchar(45) NOT NULL,
  image longblob NOT NULL,  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (imageid),
FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
);



CREATE TABLE address (
     addrID INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     houseNo varchar(25) NOT NULL,
     building varchar(25) NOT NULL,
     streetNo varchar(10),
     streetName varchar(30),
     locality varchar(30),
     city varchar(25) NOT NULL,
     district varchar(25) NOT NULL,
     pin int not null,
     rstate varchar(30) NOT NULL,
     addrType varchar(1),     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (addrID),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;


CREATE TABLE clubmembership (
     membershipID INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     memberOf varchar(10) NOT NULL,
     startDt date NOT NULL,
     validUpto date,
     membershipCd varchar(25) NOT NULL,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (membershipID),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;


CREATE TABLE complains (
     complainID INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     selection varchar(20) NOT NULL,
     raiseDt date,
     status varchar(1) not null,
     isActive bit,
     closingDt date,
     details varchar(500),
     assignee varchar(30),
     assignedDept varchar(25),
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (complainID),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;



CREATE TABLE legalcomplains (
     complainID INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     complainType varchar(10) NOT NULL default 'GD',
     policeStn varchar(20),
     summary varchar(30),
     raiseDt date,
     status varchar(1) not null,
     isActive bit,
     closingDt date,
     details varchar(500), 
     occurencelatitude float,
     occurencelongitude float,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (complainID),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;

CREATE TABLE complainimage (
    imageid int(10) unsigned NOT NULL auto_increment,  
    complainID INT NOT NULL,
    image_name varchar(45) NOT NULL,
    image longblob NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY  (imageid),
  FOREIGN KEY (complainID) REFERENCES legalcomplains(complainID) ON DELETE CASCADE  
);


CREATE TABLE doctor (
     docId INT NOT NULL AUTO_INCREMENT,     
     docname varchar(50) NOT NULL,
     registration varchar(50) NOT NULL,
     qualification varchar(50) NOT NULL,
     specialization varchar(50) NOT NULL,
     addrId INT NOT NULL,
     isfromhospital bit,
     assochospital varchar(50) NOT NULL,
     experience float,
     phone varchar(20) NOT NULL,
     timings varchar(50) NOT NULL,     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
     PRIMARY KEY (docId),
     CONSTRAINT registration_unique UNIQUE (registration),
   FOREIGN KEY (addrId) REFERENCES address(addrID) ON DELETE CASCADE
) ;



CREATE TABLE hospital (
     hospitalId INT NOT NULL AUTO_INCREMENT,     
     hospitalname varchar(50) NOT NULL,
     registration varchar(50) NOT NULL,     
     addrId INT NOT NULL,
     hosptype varchar(20) not null,
     ambulanceAvailable bit not null,
     emergencyAvailable bit not null,
     phone varchar(20) NOT NULL,
     timings varchar(50) NOT NULL,
     specialities varchar(50) NOT NULL,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
     PRIMARY KEY (hospitalId),
     CONSTRAINT registration_unique UNIQUE (registration),
   FOREIGN KEY (addrId) REFERENCES address(addrID) ON DELETE CASCADE
) ;



CREATE TABLE doctorhospital_ref (
     seqID INT NOT NULL AUTO_INCREMENT,     
     hospitalid INT NOT NULL,
     docId INT NOT NULL,          
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
     PRIMARY KEY (seqID),
   FOREIGN KEY (hospitalid) REFERENCES hospital(hospitalId) ON DELETE CASCADE,
   FOREIGN KEY (docId) REFERENCES doctor(docId) ON DELETE CASCADE
) ;



CREATE TABLE medicalappointment (
     appointId INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     ishospialappointment bit,
     docId INT,
     hospitalId INT,     
     bookingDt date,
     appointmenttime timestamp,     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (appointId),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;



CREATE TABLE bloodorganrequest (
     requestID INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     requestorName varchar(30) NOT NULL,
     ailment varchar(30),
     reqGender varchar(1) NOT NULL,
     reqAge int,
     docName varchar(30) NOT NULL,
     hospName varchar(30) NOT NULL,
     reqBloodGrp varchar(5) NOT NULL,
     requestedItem varchar(10) NOT NULL,
     specification varchar(100) NOT NULL,      
     isActive bit,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (requestID),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;



CREATE TABLE payment (
     paymentId INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     amount float NOT NULL,
     payfor varchar(30) NOT NULL,     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (paymentId),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;



CREATE TABLE skilledperson (
     spid INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,     
     skilltype varchar(30) NOT NULL, 
     rating int,    
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (spid),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;



CREATE TABLE seniorcitizen (
     scid INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,         
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (scid),
  FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;




CREATE TABLE event (
     eventID INT NOT NULL AUTO_INCREMENT,     
     legend varchar(50) NOT NULL,
     arrangedDt date,
     location varchar(50) NOT NULL,
     isActive  bit,
     details varchar(300) NOT NULL,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,     
     PRIMARY KEY (eventID)
) ;


--table per class
CREATE TABLE onlineapplication (
     applicationid INT NOT NULL AUTO_INCREMENT,
     userId INT NOT NULL,
     applicantname varchar(30) NOT NULL,
     addrid INT NOT NULL,     
     applicationtype varchar(10),
     submitdate timestamp not null,
     status varchar(5),
     isactive bit,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (applicationid),
   FOREIGN KEY (userId) REFERENCES userinfo(userId) ON DELETE CASCADE
) ;


CREATE TABLE applicationfiles (
    imageid int(10) unsigned NOT NULL auto_increment,
    applicationid INT NOT NULL,
    image_name varchar(45) NOT NULL,
    image longblob NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY  (imageid),
  FOREIGN KEY (applicationid) REFERENCES onlineapplication(applicationid) ON DELETE CASCADE
);



CREATE TABLE electricconnapplication (
     applicationid INT NOT NULL AUTO_INCREMENT,
     applicationtype varchar(10),
     ward varchar(10) NOT NULL,
     issueAuthority varchar(15) NOT NULL,
     tenant bit, 
     ownerName varchar(20) NOT NULL,
     ownerAddress varchar(50) NOT NULL,
     voltage float,
     totalload float,
     noOfOutlets INT,
     noOfpoints5A INT,
     noOfpoints15A INT,
     subMeterReqd bit,
     identityNo varchar(25) NOT NULL,
     allotmentLtr longblob,
     saleDeed longblob,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (applicationid),
  FOREIGN KEY (applicationid) REFERENCES onlineapplication(applicationid) ON DELETE CASCADE
) ;



CREATE TABLE waterconnapplication (
     applicationid INT NOT NULL AUTO_INCREMENT,
     applicationtype varchar(10),
     ward varchar(45) NOT NULL,
     tenant bit, 
     ownerName varchar(45) NOT NULL,
     ownerAddress varchar(45) NOT NULL,
     conntype varchar(45) NOT NULL,
     watersize int,
     seweragesize int,
     identityNo varchar(45) NOT NULL,
     allotmentLtr longblob,
     saleDeed longblob,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (applicationid),
  FOREIGN KEY (applicationid) REFERENCES onlineapplication(applicationid) ON DELETE CASCADE
) ;


CREATE TABLE licenseapplication (
     applicationid INT NOT NULL AUTO_INCREMENT,
     applicationtype varchar(10),
     licenseType varchar(45) NOT NULL,
     applicationNo varchar(45) NOT NULL,
     rto varchar(45) NOT NULL,
     gender varchar(45) NOT NULL,
     dob date,
     guardianname varchar(45) NOT NULL,
     citizenstatus varchar(45) NOT NULL,
     qualification varchar(45) NOT NULL,
     identification varchar(45) NOT NULL,
     bloodgrp varchar(45) NOT NULL,
     vehicletype varchar(45) NOT NULL,
     addrproof longblob,
     qualcert longblob,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (applicationid),
  FOREIGN KEY (applicationid) REFERENCES onlineapplication(applicationid) ON DELETE CASCADE
) ;


--single table per class hierarchy
CREATE TABLE property (
     propid INT NOT NULL AUTO_INCREMENT,
     userid INT NOT NULL,
     propertypin varchar(45) NOT NULL,
     taxid INT NOT NULL,
     ownerName varchar(45) NOT NULL,
     ownerPhone varchar(45) NOT NULL,
     addrid INT NOT NULL,
     ward varchar(45) NOT NULL,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (propid),
  FOREIGN KEY (userid) REFERENCES userinfo(userid) ON DELETE CASCADE
) ;



CREATE TABLE tax (
     taxid INT NOT NULL AUTO_INCREMENT,
     userid INT NOT NULL,
     taxFor varchar(10) NOT NULL,
     billId varchar(25) NOT NULL,
     consumerNo varchar(20) NOT NULL,
     taxAmt float NOT NULL,
     fine float NOT NULL,
     assessStartDt date,
     assessEndDt date,
     dueDt date,
     paymentStatus varchar(10) NOT NULL,     
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     PRIMARY KEY (taxid),
  FOREIGN KEY (userid) REFERENCES userinfo(userid) ON DELETE CASCADE
) ;



CREATE TABLE keyvalueholder 
(
    `CodeID` INT NOT NULL auto_increment, 
    `Code` VARCHAR(10) NOT NULL,
    `UICode` CHAR(2) NOT NULL,
    `Value` VARCHAR(50) NOT NULL,
    `Description` VARCHAR(100),    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`CodeID`)
);



CREATE TABLE citycomplaints 
(
    `ComplainID` INT NOT NULL auto_increment, 
    `Category` VARCHAR(20) NOT NULL,
    `SubCategory` CHAR(40) NOT NULL,    
    `Description` VARCHAR(100),    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`ComplainID`),
   CONSTRAINT subCategory_unique UNIQUE (SubCategory)
);