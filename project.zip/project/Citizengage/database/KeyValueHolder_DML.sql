
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('Gender', 'M', 'Male', NULL, '2016-06-18 03:33:39.0');
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('Gender', 'F', 'Female', NULL, '2016-06-18 03:33:39.0');
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('Gender', 'T', 'Transgender', NULL, '2016-06-18 03:33:39.0');



INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('IdDocTyp', 'A', 'Aadhaar', NULL, '2016-06-18 03:54:07.0');
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('IdDocTyp', 'V', 'Voter ID', NULL, '2016-06-18 03:54:07.0');
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('IdDocTyp', 'R', 'Ration Card', NULL, '2016-06-18 03:54:07.0');



INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('LegalComTp', 'G', 'General Diary', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('LegalComTp', 'F', 'Fast Information Report', NULL, DEFAULT);



INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('PolStn', 'P1', 'Police Station 1', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('PolStn', 'P2', 'Police Station 2', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('PolStn', 'P3', 'ABC Area PS', NULL, DEFAULT);



INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'A', 'All', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'D', 'Dentist', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'G', 'Gynecologist', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'DE', 'Dermatologist', NULL, DEFAULT)
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'C', 'Cardiologist', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'N', 'Neurologist', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'E', 'ENT', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'O', 'Orthopedist', NULL, DEFAULT);
INSERT INTO citizengagedb.keyvalueholder (`Code`, `UICode`, `Value`, `Description`, created_at) 
	VALUES ('DocSplty', 'U', 'Urologist', NULL, DEFAULT);



